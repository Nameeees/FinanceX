
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Eye, EyeOff, Wallet, ArrowUpRight, ArrowDownRight, RefreshCw, Cloud, Check, Loader2, AlertCircle, Menu } from 'lucide-react';

interface BalanceHeaderProps {
  totalBalance: number;
  income: number;
  expense: number;
  baseCurrencyCode: string;
  displayCurrencyCode: string;
  currencies: Array<{ code: string; name: string; symbol: string; flag: string; rate: number }>;
  onOpenConverter: () => void;
  cloudStatus: 'disconnected' | 'syncing' | 'synced' | 'error';
  lastSyncTime?: string;
  userName?: string;
  onOpenMenu: () => void;
}

export const BalanceHeader: React.FC<BalanceHeaderProps> = ({ 
  totalBalance, 
  income, 
  expense, 
  baseCurrencyCode, 
  displayCurrencyCode, 
  currencies, 
  onOpenConverter,
  cloudStatus,
  lastSyncTime,
  userName = "Usuario",
  onOpenMenu
}) => {
  const [showBalance, setShowBalance] = useState(true);

  const baseCurrency = currencies.find(c => c.code === baseCurrencyCode) || currencies[0];
  const displayCurrency = currencies.find(c => c.code === displayCurrencyCode) || baseCurrency;

  const convert = (amount: number) => {
    if (baseCurrencyCode === displayCurrencyCode) return amount;
    const valueInUSD = amount / baseCurrency.rate;
    return valueInUSD * displayCurrency.rate;
  };

  const displayBalance = convert(totalBalance);
  const displayIncome = convert(income);
  const displayExpense = convert(expense);

  const getCloudIcon = () => {
      switch(cloudStatus) {
          case 'syncing': return <Loader2 size={14} className="animate-spin text-blue-400" />;
          case 'synced': return <Check size={14} className="text-emerald-400" />;
          case 'error': return <AlertCircle size={14} className="text-red-400" />;
          default: return <Cloud size={14} className="text-neutral-600" />;
      }
  };

  const getCloudText = () => {
      switch(cloudStatus) {
          case 'syncing': return 'Guardando...';
          case 'synced': return 'Guardado';
          case 'error': return 'Error al guardar';
          default: return 'Sin respaldo';
      }
  };

  return (
    <div className="relative w-full pt-6 pb-4 px-5 z-10">
      {/* Header Row */}
      <div className="flex justify-between items-start mb-6 pl-1">
        <div className="flex items-center gap-3">
            <button 
                onClick={onOpenMenu}
                className="p-2 -ml-2 rounded-full hover:bg-white/10 text-white transition-colors active:scale-95"
            >
                <Menu size={24} />
            </button>
            <div>
              <h2 className="text-white font-semibold text-lg leading-tight">Hola, {userName.split(' ')[0]}</h2>
              <div className="flex items-center gap-1.5 mt-0.5">
                 {getCloudIcon()}
                 <span className={`text-[10px] font-medium ${cloudStatus === 'error' ? 'text-red-400' : 'text-neutral-500'}`}>
                     {getCloudText()}
                 </span>
              </div>
            </div>
        </div>
        
        {/* Currency Converter Pill */}
        <button 
            onClick={onOpenConverter}
            className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 transition-colors active:scale-95 backdrop-blur-sm"
        >
             <span className="text-lg">{displayCurrency.flag}</span>
             <span className="text-xs font-bold text-white">{displayCurrency.code}</span>
             <RefreshCw size={12} className="text-neutral-400" />
        </button>
      </div>

      {/* Main Hero Card */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.5, type: "spring" }}
        className="relative overflow-hidden rounded-[2rem] border border-white/10 shadow-2xl shadow-black/20"
      >
        <div className="absolute inset-0 bg-[#121212]/80 backdrop-blur-xl z-0" />
        <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent z-0 pointer-events-none" />

        <div className="relative z-10 p-6 flex flex-col gap-6">
          {/* Top Section: Total Balance */}
          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between text-neutral-400">
              <span className="flex items-center gap-2 text-sm font-medium tracking-wide uppercase text-neutral-500">
                <Wallet size={14} className="text-neutral-400" />
                Balance Total
              </span>
              <button onClick={() => setShowBalance(!showBalance)} className="p-1.5 rounded-full hover:bg-white/5 transition-colors text-neutral-500">
                  {showBalance ? <Eye size={16} /> : <EyeOff size={16} />}
              </button>
            </div>
            
            <motion.div 
              className="relative"
              key={displayCurrencyCode + showBalance} // Re-animate on currency change
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <h1 className="text-[2.75rem] leading-none font-bold text-white tracking-tight drop-shadow-lg break-words">
                {showBalance ? (
                  <>
                    <span className="text-2xl text-neutral-500 font-medium mr-1 align-top relative top-1">{displayCurrency.symbol}</span>
                    {displayBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </>
                ) : (
                  <span className="tracking-widest text-4xl py-2 inline-block">••••••</span>
                )}
              </h1>
            </motion.div>
          </div>

          <div className="h-px w-full bg-white/5" />

          {/* Bottom Section: Income vs Expense Grid */}
          <div className="grid grid-cols-2 gap-4">
            <div className="flex flex-col gap-1 group">
              <div className="flex items-center gap-2 mb-1">
                <div className="w-5 h-5 rounded-full bg-emerald-500/10 flex items-center justify-center">
                  <ArrowUpRight size={12} className="text-emerald-400" />
                </div>
                <span className="text-neutral-500 text-xs font-medium uppercase tracking-wider">Ingresos</span>
              </div>
              <p className="text-emerald-400 font-mono font-semibold text-lg tracking-wide group-hover:text-emerald-300 transition-colors">
                 +{displayCurrency.symbol}{displayIncome.toLocaleString(undefined, { maximumFractionDigits: 0 })}
              </p>
            </div>

            <div className="flex flex-col gap-1 items-end group">
              <div className="flex items-center gap-2 mb-1 flex-row-reverse">
                <div className="w-5 h-5 rounded-full bg-rose-500/10 flex items-center justify-center">
                  <ArrowDownRight size={12} className="text-rose-400" />
                </div>
                <span className="text-neutral-500 text-xs font-medium uppercase tracking-wider">Gastos</span>
              </div>
              <p className="text-rose-400 font-mono font-semibold text-lg tracking-wide group-hover:text-rose-300 transition-colors">
                 -{displayCurrency.symbol}{displayExpense.toLocaleString(undefined, { maximumFractionDigits: 0 })}
              </p>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
