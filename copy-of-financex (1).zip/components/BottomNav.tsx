import React from 'react';
import { Home, Calendar, Plus, Handshake, User } from 'lucide-react';
import { motion } from 'framer-motion';

interface BottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onFabClick: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, setActiveTab, onFabClick }) => {
  return (
    <div className="fixed bottom-0 left-0 w-full z-50">
      {/* Gradient fade at bottom to blend with content scrolling */}
      <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-black via-black/90 to-transparent pointer-events-none" />

      <div className="relative px-6 pb-6 pt-2">
        <div className="bg-surface/80 backdrop-blur-lg border border-white/10 rounded-[2.5rem] h-[4.5rem] px-6 flex items-center justify-between shadow-2xl shadow-black/50">
          
          {/* Left Icons */}
          <button 
            onClick={() => setActiveTab('home')}
            className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'home' ? 'text-white' : 'text-neutral-500'}`}
          >
            <Home size={24} strokeWidth={activeTab === 'home' ? 2.5 : 2} />
          </button>

           <button 
             onClick={() => setActiveTab('calendar')}
             className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'calendar' ? 'text-white' : 'text-neutral-500'}`}
          >
            <Calendar size={24} strokeWidth={activeTab === 'calendar' ? 2.5 : 2} />
          </button>

          {/* Spacer for Floating Button */}
          <div className="w-12" />

          {/* Right Icons */}
          <button 
             onClick={() => setActiveTab('debts')}
             className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'debts' ? 'text-white' : 'text-neutral-500'}`}
          >
            <Handshake size={24} strokeWidth={activeTab === 'debts' ? 2.5 : 2} />
          </button>

           <button 
             onClick={() => setActiveTab('profile')}
             className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'profile' ? 'text-white' : 'text-neutral-500'}`}
          >
            <User size={24} strokeWidth={activeTab === 'profile' ? 2.5 : 2} />
          </button>
        </div>

        {/* Central Floating Action Button */}
        <div className="absolute left-1/2 -top-6 -translate-x-1/2">
            <motion.button 
                onClick={onFabClick}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="w-16 h-16 rounded-full bg-gradient-to-tr from-primary to-primaryGlow shadow-[0_0_20px_rgba(139,92,246,0.5)] flex items-center justify-center text-white border-4 border-background"
            >
                <Plus size={32} strokeWidth={3} />
            </motion.button>
        </div>
      </div>
    </div>
  );
};