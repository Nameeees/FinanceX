

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, ArrowLeft, ArrowUpRight, ArrowDownRight, Calendar as CalendarIcon } from 'lucide-react';
import { Transaction, TransactionType } from '../types';
import { TransactionList } from './TransactionList';

interface CalendarViewProps {
  transactions: Transaction[];
  onTransactionClick: (t: Transaction) => void;
  onBack: () => void;
}

const DAYS_OF_WEEK = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
const MONTH_NAMES = [
  'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
  'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
];

// Helper to get local YYYY-MM-DD string
const getLocalTodayString = () => {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

export const CalendarView: React.FC<CalendarViewProps> = ({ transactions, onTransactionClick, onBack }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<string>(getLocalTodayString());
  const [direction, setDirection] = useState(0);

  // Helper to get days in month
  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  // Helper to get first day of week (0-6)
  const getFirstDayOfMonth = (year: number, month: number) => {
    return new Date(year, month, 1).getDay();
  };

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const daysInMonth = getDaysInMonth(year, month);
  const firstDay = getFirstDayOfMonth(year, month);

  // Generate calendar grid
  const daysArray = [];
  for (let i = 0; i < firstDay; i++) daysArray.push(null);
  for (let i = 1; i <= daysInMonth; i++) daysArray.push(i);

  const changeMonth = (dir: number) => {
    setDirection(dir);
    setCurrentDate(new Date(year, month + dir, 1));
  };

  const handleDayClick = (day: number) => {
    const m = (month + 1).toString().padStart(2, '0');
    const d = day.toString().padStart(2, '0');
    const dateStr = `${year}-${m}-${d}`;
    setSelectedDate(dateStr);
  };

  // Data processing
  const selectedDateTransactions = transactions.filter(t => t.date === selectedDate);
  
  const dailyIncome = selectedDateTransactions
    .filter(t => t.type === TransactionType.INCOME)
    .reduce((acc, curr) => acc + curr.amount, 0);
  const dailyExpense = selectedDateTransactions
    .filter(t => t.type === TransactionType.EXPENSE)
    .reduce((acc, curr) => acc + curr.amount, 0);

  const variants = {
    enter: (dir: number) => ({ x: dir > 0 ? 50 : -50, opacity: 0 }),
    center: { x: 0, opacity: 1 },
    exit: (dir: number) => ({ x: dir > 0 ? -50 : 50, opacity: 0 }),
  };

  return (
    <div className="flex flex-col h-full pt-4 pb-24">
       {/* Header with Back Button */}
       <div className="px-6 mb-6 flex items-center gap-4">
         <button 
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-surface border border-white/5 flex items-center justify-center text-neutral-400 hover:text-white hover:bg-surfaceHighlight transition-colors"
         >
            <ArrowLeft size={20} />
         </button>
         <div>
            <h1 className="text-2xl font-bold text-white leading-none">Calendario</h1>
            <p className="text-neutral-500 text-xs mt-1">Gestión de tiempo</p>
         </div>
       </div>

       {/* Calendar Card */}
       <div className="px-4 mb-2 shrink-0">
         <div className="bg-[#121212]/80 backdrop-blur-xl border border-white/10 rounded-[2.5rem] p-5 shadow-2xl relative overflow-hidden">
             {/* Decorative gradients */}
             <div className="absolute top-0 right-0 w-40 h-40 bg-primary/10 blur-[60px] rounded-full pointer-events-none" />
             <div className="absolute bottom-0 left-0 w-40 h-40 bg-blue-500/10 blur-[60px] rounded-full pointer-events-none" />

            {/* Month Navigation */}
            <div className="flex items-center justify-between mb-8 px-2 relative z-10">
                <button 
                  onClick={() => changeMonth(-1)}
                  className="p-2 rounded-full hover:bg-white/5 text-neutral-400 hover:text-white transition-colors active:scale-90"
                >
                    <ChevronLeft size={24} />
                </button>
                <motion.div 
                    key={month}
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center"
                >
                    <h2 className="text-lg font-bold text-white tracking-wide capitalize">
                        {MONTH_NAMES[month]}
                    </h2>
                    <span className="text-neutral-500 text-xs font-mono">{year}</span>
                </motion.div>
                <button 
                  onClick={() => changeMonth(1)}
                  className="p-2 rounded-full hover:bg-white/5 text-neutral-400 hover:text-white transition-colors active:scale-90"
                >
                    <ChevronRight size={24} />
                </button>
            </div>

            {/* Days of Week */}
            <div className="grid grid-cols-7 mb-4 relative z-10">
                {DAYS_OF_WEEK.map(day => (
                    <div key={day} className="text-center text-[10px] uppercase font-bold text-neutral-600 tracking-wider">
                        {day}
                    </div>
                ))}
            </div>

            {/* Days Grid with Animation */}
            <AnimatePresence mode="popLayout" custom={direction} initial={false}>
                <motion.div 
                    key={`${month}-${year}`}
                    custom={direction}
                    variants={variants}
                    initial="enter"
                    animate="center"
                    exit="exit"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                    className="grid grid-cols-7 gap-y-4 gap-x-2 relative z-10"
                >
                    {daysArray.map((day, index) => {
                        if (day === null) return <div key={`empty-${index}`} />;

                        const m = (month + 1).toString().padStart(2, '0');
                        const d = day.toString().padStart(2, '0');
                        const dateStr = `${year}-${m}-${d}`;
                        
                        const isSelected = selectedDate === dateStr;
                        const isToday = getLocalTodayString() === dateStr;
                        
                        const dayTrans = transactions.filter(t => t.date === dateStr);
                        const hasIncome = dayTrans.some(t => t.type === TransactionType.INCOME);
                        const hasExpense = dayTrans.some(t => t.type === TransactionType.EXPENSE);

                        return (
                            <button
                                key={day}
                                onClick={() => handleDayClick(day)}
                                className={`relative flex items-center justify-center w-full aspect-square rounded-2xl transition-all duration-300 overflow-hidden group ${
                                    isSelected 
                                      ? 'ring-2 ring-primary/50 shadow-[0_0_15px_rgba(139,92,246,0.3)] bg-surfaceHighlight scale-105 z-20' 
                                      : 'hover:bg-white/5 active:scale-95'
                                }`}
                            >
                                {/* Dynamic Background Tint for Activity */}
                                {!isSelected && (hasIncome || hasExpense) && (
                                    <div className={`absolute inset-0 opacity-20 transition-opacity duration-500 ${
                                        hasIncome && hasExpense 
                                            ? 'bg-gradient-to-br from-emerald-500 via-transparent to-rose-500' 
                                            : hasIncome 
                                                ? 'bg-gradient-to-b from-emerald-500 to-transparent' 
                                                : 'bg-gradient-to-t from-rose-500 to-transparent'
                                    }`} />
                                )}

                                {/* Neon Brackets Indicators - Revised Positioning */}
                                {hasIncome && (
                                    <div className={`absolute left-0 top-1/2 -translate-y-1/2 h-[60%] w-[4px] rounded-r-full bg-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.8)] transition-all ${isSelected ? 'opacity-100' : 'opacity-70'}`} />
                                )}
                                {hasExpense && (
                                    <div className={`absolute right-0 top-1/2 -translate-y-1/2 h-[60%] w-[4px] rounded-l-full bg-rose-500 shadow-[0_0_12px_rgba(244,63,94,0.8)] transition-all ${isSelected ? 'opacity-100' : 'opacity-70'}`} />
                                )}

                                {/* Number */}
                                <span className={`relative z-10 text-sm font-medium transition-colors ${
                                    isSelected 
                                        ? 'text-white font-bold' 
                                        : isToday 
                                            ? 'text-primary' 
                                            : hasIncome || hasExpense ? 'text-neutral-200' : 'text-neutral-500'
                                }`}>
                                    {day}
                                </span>

                                {/* Today Dot (if no other indicators or selected) */}
                                {isToday && !isSelected && !hasIncome && !hasExpense && (
                                    <div className="absolute bottom-1 w-1 h-1 rounded-full bg-primary" />
                                )}
                            </button>
                        );
                    })}
                </motion.div>
            </AnimatePresence>
         </div>
       </div>

       {/* Daily Summary Cards */}
       <div className="px-6 mb-4 grid grid-cols-2 gap-3">
            <motion.div 
                layout
                className="bg-surface/50 rounded-2xl p-3 flex items-center gap-3 border border-emerald-500/10"
            >
                <div className="w-10 h-10 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                    <ArrowUpRight size={20} />
                </div>
                <div>
                    <span className="text-[10px] uppercase tracking-wider text-neutral-500 block">Ingresos</span>
                    <span className="font-mono font-bold text-emerald-400 text-sm">
                        +${dailyIncome.toLocaleString()}
                    </span>
                </div>
            </motion.div>

            <motion.div 
                layout
                className="bg-surface/50 rounded-2xl p-3 flex items-center gap-3 border border-rose-500/10"
            >
                <div className="w-10 h-10 rounded-full bg-rose-500/10 flex items-center justify-center text-rose-400">
                    <ArrowDownRight size={20} />
                </div>
                <div>
                    <span className="text-[10px] uppercase tracking-wider text-neutral-500 block">Gastos</span>
                    <span className="font-mono font-bold text-rose-400 text-sm">
                        -${dailyExpense.toLocaleString()}
                    </span>
                </div>
            </motion.div>
       </div>

       {/* List for Selected Day */}
       <div className="flex-1 overflow-y-auto no-scrollbar">
            <TransactionList 
                transactions={selectedDateTransactions} 
                title={`Movimientos del ${selectedDate.split('-')[2]}`}
                showViewAll={false}
                onTransactionClick={onTransactionClick}
            />
       </div>
    </div>
  );
};