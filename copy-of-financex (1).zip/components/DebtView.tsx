
import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, ArrowUpRight, ArrowDownRight, Plus, CheckCircle2, Filter, Trophy, X, Search, Calendar, DollarSign, Wallet, AlertCircle, Clock, ChevronRight, Check, AlertTriangle } from 'lucide-react';
import { Debt, DebtType } from '../types';

interface DebtViewProps {
  debts: Debt[];
  onBack: () => void;
  onAddDebt: () => void;
  onDebtClick: (debt: Debt) => void;
}

type SortOption = 'DATE_ASC' | 'DATE_DESC' | 'AMOUNT_ASC' | 'AMOUNT_DESC';
type StatusFilter = 'ALL' | 'PENDING' | 'OVERDUE' | 'PAID';

export const DebtView: React.FC<DebtViewProps> = ({ debts, onBack, onAddDebt, onDebtClick }) => {
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  
  // --- FILTER STATES ---
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOption, setSortOption] = useState<SortOption>('DATE_ASC');
  const [activeTab, setActiveTab] = useState<'ALL' | 'LENT' | 'BORROWED'>('ALL');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('ALL');

  const filteredDebts = useMemo(() => {
    const today = new Date();
    today.setHours(0,0,0,0);

    return debts.filter(d => {
        // 1. Search
        const query = searchQuery.toLowerCase();
        const matchesSearch = d.person.toLowerCase().includes(query) || 
                              (d.description && d.description.toLowerCase().includes(query));
        if (!matchesSearch) return false;

        // 2. Tab Filter (Type)
        if (activeTab === 'LENT' && d.type !== DebtType.LENT) return false;
        if (activeTab === 'BORROWED' && d.type !== DebtType.BORROWED) return false;

        // 3. Status Filter
        const isPaid = d.paidAmount >= d.amount;
        
        let isOverdue = false;
        if (!isPaid && d.dueDate) {
             const due = new Date(d.dueDate + 'T00:00:00');
             isOverdue = due < today;
        }

        if (statusFilter === 'PAID' && !isPaid) return false;
        if (statusFilter === 'PENDING' && isPaid) return false;
        if (statusFilter === 'OVERDUE' && (!isOverdue || isPaid)) return false;

        return true;
    }).sort((a, b) => {
        // Sort logic
        const isPaidA = a.paidAmount >= a.amount;
        const isPaidB = b.paidAmount >= b.amount;
        
        // Always push paid to bottom unless sorting by specific criteria that requires otherwise
        if (isPaidA && !isPaidB) return 1;
        if (!isPaidA && isPaidB) return -1;

        switch (sortOption) {
            case 'DATE_ASC': 
                if (!a.dueDate) return 1;
                if (!b.dueDate) return -1;
                return a.dueDate.localeCompare(b.dueDate);
            case 'DATE_DESC': 
                 if (!a.dueDate) return 1;
                 if (!b.dueDate) return -1;
                 return b.dueDate.localeCompare(a.dueDate);
            case 'AMOUNT_DESC': return a.amount - b.amount;
            case 'AMOUNT_ASC': return b.amount - a.amount;
            default: return 0;
        }
    });
  }, [debts, searchQuery, sortOption, activeTab, statusFilter]);
  
  // Totals Calculation
  const totalLentRemaining = debts.filter(d => d.type === DebtType.LENT).reduce((acc, curr) => acc + (curr.amount - curr.paidAmount), 0);
  const totalBorrowedRemaining = debts.filter(d => d.type === DebtType.BORROWED).reduce((acc, curr) => acc + (curr.amount - curr.paidAmount), 0);
  const netBalance = totalLentRemaining - totalBorrowedRemaining;

  // Helper for Date Status
  const getDateStatus = (dateStr?: string) => {
      if (!dateStr) return { text: 'Sin fecha', color: 'text-neutral-500', bg: 'bg-neutral-500/10' };
      const today = new Date();
      today.setHours(0,0,0,0);
      const due = new Date(dateStr + 'T00:00:00'); // Fix timezone roughly
      
      const diffTime = due.getTime() - today.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 

      if (diffDays < 0) return { text: `Venció hace ${Math.abs(diffDays)}d`, color: 'text-red-400', bg: 'bg-red-500/10' };
      if (diffDays === 0) return { text: 'Vence hoy', color: 'text-orange-400', bg: 'bg-orange-500/10' };
      if (diffDays === 1) return { text: 'Mañana', color: 'text-yellow-400', bg: 'bg-yellow-500/10' };
      if (diffDays <= 7) return { text: `En ${diffDays} días`, color: 'text-blue-400', bg: 'bg-blue-500/10' };
      return { text: dateStr, color: 'text-neutral-400', bg: 'bg-white/5' };
  };

  return (
    <div className="flex flex-col h-full pt-4 pb-24 bg-[#0a0a0a]">
      {/* Header */}
      <div className="px-6 mb-6 flex items-center justify-between">
         <div className="flex items-center gap-4">
            <button 
                onClick={onBack}
                className="w-10 h-10 rounded-full bg-surface border border-white/5 flex items-center justify-center text-neutral-400 hover:text-white hover:bg-surfaceHighlight transition-colors"
            >
                <ArrowLeft size={20} />
            </button>
            <h1 className="text-2xl font-bold text-white leading-none">Gestión de Deudas</h1>
         </div>
         <button 
            onClick={onAddDebt}
            className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center shadow-lg shadow-primary/30 hover:scale-105 transition-transform"
         >
            <Plus size={22} />
         </button>
      </div>

      {/* Net Balance Card */}
      <div className="px-6 mb-6">
          <div className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-[#121212] p-6 shadow-2xl">
              <div className={`absolute top-0 right-0 w-64 h-64 rounded-full blur-[80px] opacity-20 pointer-events-none ${netBalance >= 0 ? 'bg-emerald-500' : 'bg-rose-500'}`} />
              
              <div className="relative z-10 flex justify-between items-end">
                  <div>
                      <span className="text-neutral-400 text-xs font-bold uppercase tracking-wider block mb-1">Balance Neto</span>
                      <div className={`text-3xl font-bold font-mono ${netBalance >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {netBalance > 0 ? '+' : ''}${netBalance.toLocaleString()}
                      </div>
                      <p className="text-xs text-neutral-500 mt-1">
                          {netBalance >= 0 ? 'Te deben más de lo que debes' : 'Debes más de lo que te deben'}
                      </p>
                  </div>
                  
                  <div className="flex gap-4">
                      <div className="text-right">
                          <div className="flex items-center justify-end gap-1 text-[10px] text-emerald-400 font-bold uppercase mb-0.5">
                              <ArrowUpRight size={12} /> Cobrar
                          </div>
                          <div className="text-white font-mono font-medium">${totalLentRemaining.toLocaleString()}</div>
                      </div>
                      <div className="text-right">
                          <div className="flex items-center justify-end gap-1 text-[10px] text-rose-400 font-bold uppercase mb-0.5">
                              <ArrowDownRight size={12} /> Pagar
                          </div>
                          <div className="text-white font-mono font-medium">${totalBorrowedRemaining.toLocaleString()}</div>
                      </div>
                  </div>
              </div>
          </div>
      </div>

      {/* Main Filter Section */}
      <div className="px-6 mb-4 space-y-3">
          {/* Main Tabs (Type) */}
          <div className="bg-surface p-1 rounded-2xl flex border border-white/5 relative">
              {(['ALL', 'LENT', 'BORROWED'] as const).map((tab) => {
                  const isActive = activeTab === tab;
                  return (
                      <button
                          key={tab}
                          onClick={() => setActiveTab(tab)}
                          className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all relative z-10 ${isActive ? 'text-white' : 'text-neutral-500 hover:text-neutral-300'}`}
                      >
                          {tab === 'ALL' && 'Todas'}
                          {tab === 'LENT' && 'Por Cobrar'}
                          {tab === 'BORROWED' && 'Por Pagar'}
                          {isActive && (
                              <motion.div 
                                  layoutId="activeTabDebt"
                                  className="absolute inset-0 bg-surfaceHighlight border border-white/10 rounded-xl -z-10 shadow-sm"
                              />
                          )}
                      </button>
                  );
              })}
          </div>

          {/* Search Row */}
          <div className="flex gap-2">
             <div className="flex-1 bg-surface rounded-xl flex items-center px-4 py-3 border border-white/5 focus-within:border-white/20 transition-colors">
                  <Search size={18} className="text-neutral-500 mr-3 shrink-0" />
                  <input 
                      type="text" 
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Buscar persona o nota..."
                      className="bg-transparent border-none outline-none text-white w-full placeholder:text-neutral-600 font-medium text-sm"
                  />
                  {searchQuery && (
                      <button onClick={() => setSearchQuery('')} className="p-1 bg-white/10 rounded-full text-neutral-400">
                          <X size={12} />
                      </button>
                  )}
             </div>
             <button 
                  onClick={() => setIsFilterOpen(!isFilterOpen)}
                  className={`w-12 rounded-xl border flex items-center justify-center transition-all ${isFilterOpen ? 'bg-primary text-white border-primary' : 'bg-surface text-neutral-400 border-white/5'}`}
             >
                <Filter size={18} />
             </button>
          </div>

          {/* Expanded Filters Panel */}
          <AnimatePresence>
             {isFilterOpen && (
                 <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden bg-[#121212] rounded-2xl border border-white/5"
                 >
                    <div className="p-4 flex flex-col gap-4">
                        {/* Status Chips */}
                        <div>
                             <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider block mb-2">Estado</span>
                             <div className="flex gap-2 flex-wrap">
                                 {[
                                     { id: 'ALL', label: 'Todos' },
                                     { id: 'PENDING', label: 'Pendientes', color: 'text-blue-400 bg-blue-500/10 border-blue-500/20' },
                                     { id: 'OVERDUE', label: 'Vencidas', color: 'text-red-400 bg-red-500/10 border-red-500/20' },
                                     { id: 'PAID', label: 'Pagadas', color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' }
                                 ].map((chip) => (
                                     <button
                                         key={chip.id}
                                         onClick={() => setStatusFilter(chip.id as StatusFilter)}
                                         className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                                             statusFilter === chip.id 
                                                ? (chip.color || 'bg-white text-black border-white')
                                                : 'bg-surface border-white/5 text-neutral-500 hover:border-white/20'
                                         }`}
                                     >
                                         {chip.label}
                                     </button>
                                 ))}
                             </div>
                        </div>

                        {/* Sorting */}
                        <div>
                            <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider block mb-2">Ordenar por</span>
                            <div className="grid grid-cols-2 gap-2">
                                 <button onClick={() => setSortOption(sortOption === 'DATE_ASC' ? 'DATE_DESC' : 'DATE_ASC')} className={`py-2 px-3 rounded-lg text-xs font-medium border text-left flex justify-between ${sortOption.includes('DATE') ? 'bg-surfaceHighlight border-white/20 text-white' : 'bg-surface border-white/5 text-neutral-400'}`}>
                                     Fecha {sortOption === 'DATE_ASC' ? '(Próxima)' : '(Lejana)'}
                                 </button>
                                 <button onClick={() => setSortOption(sortOption === 'AMOUNT_DESC' ? 'AMOUNT_ASC' : 'AMOUNT_DESC')} className={`py-2 px-3 rounded-lg text-xs font-medium border text-left flex justify-between ${sortOption.includes('AMOUNT') ? 'bg-surfaceHighlight border-white/20 text-white' : 'bg-surface border-white/5 text-neutral-400'}`}>
                                     Monto {sortOption === 'AMOUNT_DESC' ? '(Mayor)' : '(Menor)'}
                                 </button>
                            </div>
                        </div>
                    </div>
                 </motion.div>
             )}
          </AnimatePresence>
      </div>

      {/* Debt List */}
      <div className="flex-1 px-6 overflow-y-auto no-scrollbar space-y-3">
            <AnimatePresence mode="popLayout">
                {filteredDebts.length > 0 ? (
                    filteredDebts.map((debt) => {
                        const isPaid = debt.paidAmount >= debt.amount;
                        const isLent = debt.type === DebtType.LENT;
                        const remaining = debt.amount - debt.paidAmount;
                        const percent = Math.min((debt.paidAmount / debt.amount) * 100, 100);
                        const dateInfo = getDateStatus(debt.dueDate);
                        
                        // Theme Colors
                        const textAccent = isLent ? 'text-emerald-400' : 'text-rose-400';
                        const bgAccent = isLent ? 'bg-emerald-500' : 'bg-rose-500';
                        const borderAccent = isLent ? 'border-emerald-500/30' : 'border-rose-500/30';

                        return (
                            <motion.button
                                key={debt.id}
                                layout
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0, scale: 0.95 }}
                                onClick={() => onDebtClick(debt)}
                                className={`w-full text-left rounded-[1.5rem] p-5 relative overflow-hidden group transition-all active:scale-[0.98] border 
                                    ${isPaid 
                                        ? 'bg-[#121212] border-white/5 opacity-80' 
                                        : `bg-[#151515] hover:bg-[#1a1a1a] shadow-lg ${borderAccent}`
                                    }`}
                            >
                                 {/* PAID STAMP EFFECT */}
                                 {isPaid && (
                                     <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 border-4 border-neutral-700 text-neutral-700 px-4 py-1 text-3xl font-black opacity-30 -rotate-12 pointer-events-none select-none z-0">
                                         PAGADO
                                     </div>
                                 )}

                                 {/* Background Glow */}
                                 {!isPaid && (
                                     <div className={`absolute top-0 right-0 w-32 h-32 ${bgAccent} opacity-5 blur-[50px] pointer-events-none group-hover:opacity-10 transition-opacity`} />
                                 )}

                                 <div className="flex justify-between items-start mb-4 relative z-10">
                                    <div className="flex items-center gap-3">
                                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg font-bold shadow-inner ${isPaid ? 'bg-neutral-800 text-neutral-500' : (isLent ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400')}`}>
                                            {isPaid ? <Check size={20} /> : debt.person.charAt(0)}
                                        </div>
                                        <div>
                                            <h4 className={`font-bold text-base leading-tight ${isPaid ? 'text-neutral-500' : 'text-white'}`}>{debt.person}</h4>
                                            <span className={`text-[10px] font-bold uppercase tracking-wide ${isPaid ? 'text-neutral-600' : (isLent ? 'text-emerald-500' : 'text-rose-500')}`}>
                                                {isLent ? 'Te debe' : 'Debes'}
                                            </span>
                                        </div>
                                    </div>

                                    {!isPaid ? (
                                        <div className={`px-2 py-1 rounded-lg text-[10px] font-bold flex items-center gap-1.5 ${dateInfo.bg} ${dateInfo.color}`}>
                                            <Clock size={10} /> {dateInfo.text}
                                        </div>
                                    ) : (
                                        <div className="px-2 py-1 rounded-lg bg-white/5 text-neutral-500 text-[10px] font-bold flex items-center gap-1">
                                            {new Date(debt.payments[debt.payments.length - 1]?.date || new Date()).toLocaleDateString()}
                                        </div>
                                    )}
                                 </div>

                                 <div className="flex justify-between items-end mb-2 relative z-10">
                                     <div className="flex flex-col">
                                         <span className="text-[10px] text-neutral-500 uppercase font-medium">Restante</span>
                                         <span className={`text-2xl font-mono font-bold tracking-tight ${isPaid ? 'text-neutral-600 decoration-neutral-700 decoration-2' : textAccent}`}>
                                             ${remaining.toLocaleString()}
                                         </span>
                                     </div>
                                     <div className="text-right">
                                         <span className="text-xs text-neutral-400 font-medium">Total: ${debt.amount.toLocaleString()}</span>
                                     </div>
                                 </div>

                                 {/* Progress Bar */}
                                 <div className="w-full h-2 bg-neutral-800 rounded-full overflow-hidden relative z-10">
                                     <motion.div 
                                        initial={{ width: 0 }}
                                        animate={{ width: `${percent}%` }}
                                        className={`h-full rounded-full ${isPaid ? 'bg-neutral-600' : bgAccent}`}
                                     />
                                 </div>
                                 
                                 {/* Dashed Line for Paid Effect */}
                                 {isPaid && (
                                     <div className="absolute bottom-0 left-0 w-full h-1 bg-[linear-gradient(90deg,transparent_50%,#262626_50%)] bg-[length:10px_100%] opacity-50" />
                                 )}

                                 {debt.description && !isPaid && (
                                     <p className="mt-3 text-xs text-neutral-500 truncate relative z-10 pl-1 border-l-2 border-white/5">
                                         {debt.description}
                                     </p>
                                 )}
                            </motion.button>
                        );
                    })
                ) : (
                    <div className="flex flex-col items-center justify-center py-16 opacity-50">
                        <div className="w-20 h-20 bg-surface rounded-full flex items-center justify-center mb-4 border border-white/5">
                            <Wallet size={32} className="text-neutral-600" />
                        </div>
                        <p className="text-neutral-400 font-medium text-center">No hay deudas con<br/>estos filtros.</p>
                        <button onClick={() => {setActiveTab('ALL'); setSearchQuery(''); setStatusFilter('ALL');}} className="mt-2 text-primary text-xs font-bold hover:underline">
                            Limpiar filtros
                        </button>
                    </div>
                )}
            </AnimatePresence>
      </div>
    </div>
  );
};
