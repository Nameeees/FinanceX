

import React, { useRef, useState } from 'react';
import { UserProfile, Transaction, Debt, TransactionType, SecurityMethod } from '../types';
import { Settings, Shield, Bell, LogOut, ChevronRight, Wallet, Target, CreditCard, Download, Upload, ArrowLeft, Plus, Check, Lock, Smartphone, FileText, Edit2, Camera, Mail, User, Grid3X3, Type, Hash, Cloud, CloudLightning, RefreshCw, HelpCircle, X, ExternalLink, Github, FileSpreadsheet, FileJson, CalendarRange, Table2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { AppLockOverlay } from './ui/AppLockOverlay';

interface ProfileViewProps {
  user: UserProfile;
  transactions?: Transaction[];
  debts?: Debt[];
  customCategories?: {id: string, name: string, icon: string, type: TransactionType}[];
  onUpdateProfile?: (user: UserProfile) => void;
  onImportData?: (data: any) => void;
  onLogout?: () => void;
  onCloudSync?: () => Promise<void>;
  onCloudRestore?: () => Promise<void>;
  onCloudConnect?: (key: string) => Promise<void>;
  isSyncing?: boolean;
  onOpenSpreadsheet?: () => void;
}

// Sub-components for cleaner code
const EditProfileView = ({ user, onSave, onBack }: { user: UserProfile, onSave: (u: UserProfile) => void, onBack: () => void }) => {
    const [name, setName] = useState(user.name);
    const [email, setEmail] = useState(user.email);
    const [avatarUrl, setAvatarUrl] = useState(user.avatarUrl);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            // Compress image logic
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = (event) => {
                const img = new Image();
                img.src = event.target?.result as string;
                img.onload = () => {
                    const canvas = document.createElement('canvas');
                    // Resize to max 300px width to keep JSON size small
                    const MAX_WIDTH = 300;
                    const scaleSize = MAX_WIDTH / img.width;
                    
                    // Only resize if bigger than max width
                    if (img.width > MAX_WIDTH) {
                        canvas.width = MAX_WIDTH;
                        canvas.height = img.height * scaleSize;
                    } else {
                        canvas.width = img.width;
                        canvas.height = img.height;
                    }

                    const ctx = canvas.getContext('2d');
                    ctx?.drawImage(img, 0, 0, canvas.width, canvas.height);
                    
                    // Compress to JPEG with 0.7 quality
                    const compressedBase64 = canvas.toDataURL('image/jpeg', 0.7);
                    setAvatarUrl(compressedBase64);
                }
            }
        }
    };

    const handleSave = () => {
        onSave({ ...user, name, email, avatarUrl });
        onBack();
    };

    return (
        <div className="flex flex-col h-full">
            <div className="px-6 mb-6 flex items-center justify-between">
                <button onClick={onBack} className="w-10 h-10 rounded-full bg-surface border border-white/5 flex items-center justify-center text-neutral-400 hover:text-white transition-colors">
                    <ArrowLeft size={20} />
                </button>
                <h2 className="text-xl font-bold text-white">Editar Perfil</h2>
                <div className="w-10" />
            </div>

            <div className="px-6 flex flex-col items-center flex-1">
                {/* Avatar Edit */}
                <div className="relative mb-8 group">
                    <div className="w-32 h-32 rounded-full p-1 bg-gradient-to-br from-primary via-purple-500 to-blue-500">
                         <img src={avatarUrl} alt="Avatar" className="w-full h-full rounded-full object-cover border-4 border-[#121212]" />
                    </div>
                    <button 
                        onClick={() => fileInputRef.current?.click()}
                        className="absolute bottom-1 right-1 p-2 rounded-full bg-surfaceHighlight border border-white/10 text-white shadow-lg active:scale-95 transition-transform"
                    >
                        <Camera size={18} />
                    </button>
                    <input 
                        type="file" 
                        ref={fileInputRef} 
                        onChange={handleImageChange} 
                        accept="image/*" 
                        className="hidden" 
                    />
                </div>

                {/* Form Inputs */}
                <div className="w-full space-y-4">
                    <div>
                        <label className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-2 block ml-1">Nombre</label>
                        <div className="bg-surface rounded-xl flex items-center px-4 py-3 border border-white/5 focus-within:border-primary/50 transition-colors">
                            <User size={18} className="text-neutral-500 mr-3" />
                            <input 
                                type="text" 
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                className="bg-transparent border-none outline-none text-white w-full placeholder:text-neutral-600 font-medium"
                            />
                        </div>
                    </div>

                    <div>
                        <label className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-2 block ml-1">Correo Electrónico</label>
                        <div className="bg-surface rounded-xl flex items-center px-4 py-3 border border-white/5 focus-within:border-primary/50 transition-colors">
                            <Mail size={18} className="text-neutral-500 mr-3" />
                            <input 
                                type="email" 
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="bg-transparent border-none outline-none text-white w-full placeholder:text-neutral-600 font-medium"
                            />
                        </div>
                    </div>
                </div>

                <div className="mt-auto pb-4 w-full">
                    <button 
                        onClick={handleSave}
                        className="w-full py-4 rounded-2xl bg-primary text-white font-bold text-lg shadow-lg shadow-primary/20 active:scale-95 transition-all flex items-center justify-center gap-2"
                    >
                        <Check size={20} />
                        Guardar Cambios
                    </button>
                </div>
            </div>
        </div>
    );
};

const AccountsView = ({ onBack }: { onBack: () => void }) => {
    return (
        <div className="flex flex-col h-full">
            <div className="px-6 mb-6 flex items-center gap-4">
                <button onClick={onBack} className="w-10 h-10 rounded-full bg-surface border border-white/5 flex items-center justify-center text-neutral-400 hover:text-white transition-colors">
                    <ArrowLeft size={20} />
                </button>
                <h2 className="text-xl font-bold text-white">Cuentas y Tarjetas</h2>
            </div>
            
            <div className="px-6 space-y-4">
                {/* Visual Card Representation */}
                <div className="w-full aspect-video rounded-3xl bg-gradient-to-br from-primary to-purple-800 p-6 relative overflow-hidden shadow-2xl">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl -translate-y-1/2 translate-x-1/2"></div>
                    <div className="flex justify-between items-start mb-8">
                        <span className="font-mono text-white/70 tracking-widest">Nexo Card</span>
                        <div className="flex gap-2">
                             <div className="w-8 h-5 bg-white/20 rounded-md"></div>
                        </div>
                    </div>
                    <div className="mt-auto">
                        <p className="text-white font-mono text-lg tracking-widest mb-1">**** **** **** 4242</p>
                        <div className="flex justify-between text-xs text-white/70">
                            <span>ALEX MORGAN</span>
                            <span>12/26</span>
                        </div>
                    </div>
                </div>

                <div className="p-4 bg-surface rounded-2xl border border-white/5 flex justify-between items-center">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-6 bg-blue-600 rounded flex items-center justify-center text-[8px] font-bold text-white italic">VISA</div>
                        <div className="flex flex-col">
                            <span className="text-white font-medium text-sm">Visa Débito</span>
                            <span className="text-neutral-500 text-xs">Termina en 8834</span>
                        </div>
                    </div>
                    <div className="px-2 py-1 bg-surfaceHighlight rounded text-[10px] text-neutral-400">Predeterminada</div>
                </div>

                <button className="w-full py-4 border-2 border-dashed border-white/10 rounded-2xl text-neutral-500 hover:text-white hover:border-white/30 hover:bg-white/5 transition-all flex items-center justify-center gap-2">
                    <Plus size={20} />
                    <span>Agregar nueva tarjeta</span>
                </button>
            </div>
        </div>
    );
};

const ToggleItem = ({ label, icon: Icon, color, checked, onChange }: any) => (
    <div className="w-full flex items-center justify-between p-4 bg-surface rounded-2xl border border-white/5">
        <div className="flex items-center gap-3">
            <div className={`p-2 rounded-xl bg-${color}-500/10 text-${color}-400`}>
                <Icon size={20} />
            </div>
            <span className="text-neutral-200 font-medium">{label}</span>
        </div>
        <button 
            onClick={() => onChange(!checked)}
            className={`w-12 h-6 rounded-full p-1 transition-colors ${checked ? 'bg-primary' : 'bg-neutral-800'}`}
        >
            <motion.div 
                layout 
                className="w-4 h-4 bg-white rounded-full shadow-sm"
                animate={{ x: checked ? 24 : 0 }}
                transition={{ type: "spring", stiffness: 500, damping: 30 }}
            />
        </button>
    </div>
);

const NotificationsView = ({ onBack }: { onBack: () => void }) => {
    const [toggles, setToggles] = useState({ expense: true, budget: true, news: false });
    return (
        <div className="flex flex-col h-full">
            <div className="px-6 mb-6 flex items-center gap-4">
                <button onClick={onBack} className="w-10 h-10 rounded-full bg-surface border border-white/5 flex items-center justify-center text-neutral-400 hover:text-white transition-colors">
                    <ArrowLeft size={20} />
                </button>
                <h2 className="text-xl font-bold text-white">Notificaciones</h2>
            </div>
            <div className="px-6 space-y-3">
                <ToggleItem 
                    label="Alerta de Gastos" 
                    icon={CreditCard} 
                    color="orange" 
                    checked={toggles.expense} 
                    onChange={(v: boolean) => setToggles({...toggles, expense: v})} 
                />
                 <ToggleItem 
                    label="Límite de Presupuesto" 
                    icon={Target} 
                    color="blue" 
                    checked={toggles.budget} 
                    onChange={(v: boolean) => setToggles({...toggles, budget: v})} 
                />
                 <ToggleItem 
                    label="Novedades y Tips" 
                    icon={Bell} 
                    color="purple" 
                    checked={toggles.news} 
                    onChange={(v: boolean) => setToggles({...toggles, news: v})} 
                />
            </div>
        </div>
    );
};

const SecurityView = ({ user, onBack, onUpdateSecurity }: { user: UserProfile, onBack: () => void, onUpdateSecurity: (enabled: boolean, method?: SecurityMethod, value?: string) => void }) => {
    const [isVerifyOpen, setIsVerifyOpen] = useState(false);
    const [isSetupOpen, setIsSetupOpen] = useState(false);
    const [pendingAction, setPendingAction] = useState<'DISABLE' | 'CHANGE_METHOD' | null>(null);
    const [targetMethod, setTargetMethod] = useState<SecurityMethod>('PIN');

    const handleMethodClick = (method: SecurityMethod) => {
        setTargetMethod(method);
        if (user.security.enabled) {
            setPendingAction('CHANGE_METHOD');
            setIsVerifyOpen(true);
        } else {
            setIsSetupOpen(true);
        }
    };

    const handleDisableClick = () => {
        if (!user.security.enabled) return;
        setPendingAction('DISABLE');
        setIsVerifyOpen(true);
    };

    const handleVerifySuccess = (value: string) => {
        setIsVerifyOpen(false);
        if (pendingAction === 'DISABLE') {
            onUpdateSecurity(false);
            setPendingAction(null);
        } else if (pendingAction === 'CHANGE_METHOD') {
            setIsSetupOpen(true);
        }
    };

    const handleSetupSuccess = (value: string) => {
        onUpdateSecurity(true, targetMethod, value);
        setIsSetupOpen(false);
        setPendingAction(null);
    };

    return (
        <div className="flex flex-col h-full">
            <div className="px-6 mb-6 flex items-center gap-4">
                <button onClick={onBack} className="w-10 h-10 rounded-full bg-surface border border-white/5 flex items-center justify-center text-neutral-400 hover:text-white transition-colors">
                    <ArrowLeft size={20} />
                </button>
                <h2 className="text-xl font-bold text-white">Seguridad</h2>
            </div>
            
            <div className="px-6 space-y-6">
                <div className="p-4 bg-surface rounded-2xl border border-white/5">
                    <div className="flex justify-between items-center mb-4">
                        <span className="text-neutral-200 font-medium">Bloqueo de App</span>
                        {user.security.enabled ? (
                            <button 
                                onClick={handleDisableClick} 
                                className="text-xs font-bold text-red-400 bg-red-500/10 px-3 py-1 rounded-lg hover:bg-red-500/20 transition-colors"
                            >
                                Desactivar
                            </button>
                        ) : (
                            <span className="text-xs font-bold text-neutral-500">Desactivado</span>
                        )}
                    </div>
                    
                    <div className="space-y-2">
                        <button 
                            onClick={() => handleMethodClick('PIN')}
                            className={`w-full p-3 rounded-xl flex items-center justify-between border transition-all ${user.security.enabled && user.security.method === 'PIN' ? 'bg-primary/20 border-primary text-white' : 'bg-black/20 border-transparent text-neutral-400 hover:bg-white/5'}`}
                        >
                            <div className="flex items-center gap-3">
                                <Hash size={18} />
                                <span className="text-sm font-medium">PIN Numérico</span>
                            </div>
                            {user.security.enabled && user.security.method === 'PIN' && <Check size={16} />}
                        </button>

                         <button 
                            onClick={() => handleMethodClick('PASSWORD')}
                            className={`w-full p-3 rounded-xl flex items-center justify-between border transition-all ${user.security.enabled && user.security.method === 'PASSWORD' ? 'bg-primary/20 border-primary text-white' : 'bg-black/20 border-transparent text-neutral-400 hover:bg-white/5'}`}
                        >
                            <div className="flex items-center gap-3">
                                <Type size={18} />
                                <span className="text-sm font-medium">Contraseña</span>
                            </div>
                             {user.security.enabled && user.security.method === 'PASSWORD' && <Check size={16} />}
                        </button>

                         <button 
                            onClick={() => handleMethodClick('PATTERN')}
                            className={`w-full p-3 rounded-xl flex items-center justify-between border transition-all ${user.security.enabled && user.security.method === 'PATTERN' ? 'bg-primary/20 border-primary text-white' : 'bg-black/20 border-transparent text-neutral-400 hover:bg-white/5'}`}
                        >
                            <div className="flex items-center gap-3">
                                <Grid3X3 size={18} />
                                <span className="text-sm font-medium">Patrón</span>
                            </div>
                             {user.security.enabled && user.security.method === 'PATTERN' && <Check size={16} />}
                        </button>
                    </div>
                </div>
            </div>

            <AppLockOverlay isOpen={isVerifyOpen} mode="unlock" method={user.security.method} savedValue={user.security.value} onSuccess={handleVerifySuccess} title="Verifica tu identidad" description="Ingresa tu clave actual para continuar" />
            <AppLockOverlay isOpen={isSetupOpen} mode="setup" method={targetMethod} onSuccess={handleSetupSuccess} onClose={() => setIsSetupOpen(false)} />
        </div>
    );
};

const ExportCenterView = ({ user, transactions, debts, customCategories, onImportData, onBack, onOpenSpreadsheet }: any) => {
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleExportJSON = () => {
        // Capture latest Spreadsheet Data for manual export
        let sheets = [];
        try {
            const sheetStr = localStorage.getItem('nexo_sheets');
            if (sheetStr) sheets = JSON.parse(sheetStr);
        } catch(e) {}

        const dataToExport = {
            userProfile: user, 
            transactions,
            debts,
            customCategories,
            quickActions: JSON.parse(localStorage.getItem('nexo_quick_actions') || '[]'),
            userCurrency: localStorage.getItem('nexo_currency') || 'USD',
            sheets, // Include multi-sheet data
            exportDate: new Date().toISOString()
        };
        const blob = new Blob([JSON.stringify(dataToExport, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `nexo-backup-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    const handleExportCSV = (period: 'ALL' | 'MONTH') => {
        let dataToExport = [...transactions];

        if (period === 'MONTH') {
            const now = new Date();
            const currentMonth = now.toISOString().slice(0, 7); // YYYY-MM
            dataToExport = dataToExport.filter(t => t.date.startsWith(currentMonth));
        }

        // CSV Header
        const headers = ['Fecha', 'Título', 'Categoría', 'Tipo', 'Monto', 'Nota'];
        
        // CSV Rows
        const rows = dataToExport.map(t => [
            t.date,
            `"${t.title.replace(/"/g, '""')}"`, // Escape quotes
            t.category,
            t.type === 'INCOME' ? 'Ingreso' : 'Gasto',
            t.amount,
            `"${(t.description || '').replace(/"/g, '""')}"`
        ]);

        // Add Summary Section
        const totalIncome = dataToExport.filter(t => t.type === 'INCOME').reduce((a, b) => a + b.amount, 0);
        const totalExpense = dataToExport.filter(t => t.type === 'EXPENSE').reduce((a, b) => a + b.amount, 0);
        
        rows.push([]);
        rows.push(['RESUMEN FINANCIERO', '', '', '', '']);
        rows.push(['Total Ingresos', '', '', '', totalIncome]);
        rows.push(['Total Gastos', '', '', '', totalExpense]);
        rows.push(['Balance Final', '', '', '', totalIncome - totalExpense]);

        // Combine with BOM for Excel UTF-8 support
        const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
        
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `nexo-reporte-${period === 'ALL' ? 'completo' : 'mensual'}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    const handleImportClick = () => fileInputRef.current?.click();

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (event) => {
            try {
                const json = JSON.parse(event.target?.result as string);
                if (onImportData) onImportData(json);
                alert('Datos importados correctamente');
            } catch (error) {
                alert('El archivo no es válido');
            }
        };
        reader.readAsText(file);
        if (fileInputRef.current) fileInputRef.current.value = '';
    };

    return (
        <div className="flex flex-col h-full">
            <div className="px-6 mb-6 flex items-center gap-4">
                <button onClick={onBack} className="w-10 h-10 rounded-full bg-surface border border-white/5 flex items-center justify-center text-neutral-400 hover:text-white transition-colors">
                    <ArrowLeft size={20} />
                </button>
                <h2 className="text-xl font-bold text-white">Centro de Exportación</h2>
            </div>

            <div className="px-6 space-y-6">
                
                {/* NEXO SHEETS SECTION */}
                <div>
                     <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-3 px-1 flex items-center gap-2">
                        <Table2 size={14} className="text-primary"/> Nexo Sheets
                    </h3>
                    <button onClick={onOpenSpreadsheet} className="w-full flex items-center justify-between p-4 bg-surface rounded-2xl border border-white/5 hover:bg-surfaceHighlight active:scale-[0.98] transition-all group">
                         <div className="flex items-center gap-3">
                             <div className="p-2 rounded-xl bg-primary/10 text-primary group-hover:bg-primary group-hover:text-white transition-colors"><FileSpreadsheet size={20} /></div>
                             <div className="text-left">
                                 <span className="text-neutral-200 font-bold block text-sm">Abrir Nexo Sheets</span>
                                 <span className="text-neutral-500 text-xs block">Hoja de cálculo integrada</span>
                             </div>
                         </div>
                         <ExternalLink size={18} className="text-neutral-600 group-hover:text-white"/>
                    </button>
                </div>

                {/* EXCEL SECTION */}
                <div>
                    <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-3 px-1 flex items-center gap-2">
                        <FileSpreadsheet size={14} className="text-emerald-500"/> Excel & Reportes
                    </h3>
                    <div className="grid grid-cols-1 gap-3">
                        <button onClick={() => handleExportCSV('ALL')} className="flex items-center justify-between p-4 bg-surface rounded-2xl border border-white/5 hover:bg-surfaceHighlight active:scale-[0.98] transition-all group">
                             <div className="flex items-center gap-3">
                                 <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 group-hover:bg-emerald-500 group-hover:text-black transition-colors"><FileSpreadsheet size={20} /></div>
                                 <div className="text-left">
                                     <span className="text-neutral-200 font-bold block text-sm">Exportar Todo (CSV)</span>
                                     <span className="text-neutral-500 text-xs block">Historial completo para Excel</span>
                                 </div>
                             </div>
                             <Download size={18} className="text-neutral-600 group-hover:text-white"/>
                        </button>

                        <button onClick={() => handleExportCSV('MONTH')} className="flex items-center justify-between p-4 bg-surface rounded-2xl border border-white/5 hover:bg-surfaceHighlight active:scale-[0.98] transition-all group">
                             <div className="flex items-center gap-3">
                                 <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 group-hover:bg-emerald-500 group-hover:text-black transition-colors"><CalendarRange size={20} /></div>
                                 <div className="text-left">
                                     <span className="text-neutral-200 font-bold block text-sm">Solo este Mes (CSV)</span>
                                     <span className="text-neutral-500 text-xs block">Reporte del mes actual</span>
                                 </div>
                             </div>
                             <Download size={18} className="text-neutral-600 group-hover:text-white"/>
                        </button>
                    </div>
                </div>

                {/* JSON BACKUP SECTION */}
                <div>
                    <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-3 px-1 flex items-center gap-2">
                        <FileJson size={14} className="text-blue-500"/> Copia de Seguridad (Nexo)
                    </h3>
                    <input type="file" ref={fileInputRef} onChange={handleFileChange} accept=".json" className="hidden" />
                    
                    <div className="grid grid-cols-2 gap-3">
                        <button onClick={handleExportJSON} className="flex flex-col items-center justify-center p-4 bg-surface rounded-2xl border border-white/5 hover:bg-surfaceHighlight active:scale-[0.98] transition-all">
                            <div className="p-2 rounded-xl bg-blue-500/10 text-blue-400 mb-2"><Download size={24} /></div>
                            <span className="text-neutral-200 text-xs font-medium">Backup JSON</span>
                        </button>
                        <button onClick={handleImportClick} className="flex flex-col items-center justify-center p-4 bg-surface rounded-2xl border border-white/5 hover:bg-surfaceHighlight active:scale-[0.98] transition-all">
                            <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400 mb-2"><Upload size={24} /></div>
                            <span className="text-neutral-200 text-xs font-medium">Restaurar JSON</span>
                        </button>
                    </div>
                    <p className="text-[10px] text-neutral-600 mt-2 text-center px-4">
                        El formato JSON es para restaurar tus datos en otro dispositivo con la app Nexo instalada.
                    </p>
                </div>

            </div>
        </div>
    );
};

const CloudSetupModal = ({ isOpen, onClose, onSave, isSyncing }: { isOpen: boolean, onClose: () => void, onSave: (key: string) => void, isSyncing?: boolean }) => {
    const [key, setKey] = useState('');
    
    // Auto-clean input on change
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const cleaned = e.target.value.replace(/[\s\n\r"']/g, '');
        setKey(cleaned);
    };

    if (!isOpen) return null;
    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-sm px-6">
            <div className="bg-surface border border-white/10 rounded-3xl p-6 w-full max-w-sm">
                <div className="flex justify-between items-start mb-4">
                    <h3 className="text-lg font-bold text-white flex items-center gap-2"><Github size={20}/> Nube GitHub</h3>
                    <button onClick={onClose} disabled={isSyncing} className="text-neutral-500 disabled:opacity-50"><X size={20}/></button>
                </div>
                <p className="text-neutral-400 text-xs mb-4">
                    Usa <b>GitHub Gists</b> para guardar tus datos de forma <b>gratuita, segura y con historial</b> ilimitado.
                </p>
                <ol className="text-neutral-500 text-xs list-decimal pl-4 space-y-2 mb-6">
                    <li>Inicia sesión en GitHub.</li>
                    <li>Ve a <a href="https://github.com/settings/tokens/new" target="_blank" className="text-primary underline font-bold">Crear Token (Classic)</a>.</li>
                    <li>En "Note" pon <b>Nexo App</b>.</li>
                    <li>En "Expiration" selecciona <b>No expiration</b> (Recomendado) o 1 año.</li>
                    <li>Marca la casilla <b>gist</b> (Crear gists).</li>
                    <li>Genera el token. <i>(Ignora la alerta roja de GitHub, es normal)</i>.</li>
                </ol>
                <input 
                    type="text" 
                    value={key}
                    onChange={handleChange}
                    placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                    className="w-full bg-surfaceHighlight border border-white/10 rounded-xl p-3 text-white text-sm mb-4 outline-none focus:border-primary font-mono"
                    disabled={isSyncing}
                />
                <button 
                    onClick={() => onSave(key)}
                    disabled={key.length < 10 || isSyncing}
                    className="w-full py-3 bg-primary rounded-xl text-white font-bold disabled:opacity-50 flex items-center justify-center gap-2"
                >
                    {isSyncing ? (
                        <>
                            <RefreshCw className="animate-spin" size={18} /> Conectando...
                        </>
                    ) : (
                        'Conectar GitHub'
                    )}
                </button>
            </div>
        </div>
    );
};

export const ProfileView: React.FC<ProfileViewProps> = ({ 
    user, 
    transactions = [], 
    debts = [], 
    customCategories = [],
    onUpdateProfile,
    onImportData,
    onLogout,
    onCloudSync,
    onCloudRestore,
    onCloudConnect,
    isSyncing = false,
    onOpenSpreadsheet
}) => {
  const [subView, setSubView] = useState<'main' | 'edit' | 'accounts' | 'notifications' | 'security' | 'export'>('main');
  const [isCloudSetupOpen, setIsCloudSetupOpen] = useState(false);
  
  const handleUpdateSecurity = (enabled: boolean, method?: SecurityMethod, value?: string) => {
      if (onUpdateProfile) {
          onUpdateProfile({ ...user, security: { enabled, method: method || 'PIN', value: value || '' } });
      }
      // Trigger auto-backup when security settings change for immediate protection
      if (onCloudSync) {
          setTimeout(() => onCloudSync(), 500);
      }
  };

  const handleCloudSetup = async (key: string) => {
      if (onCloudConnect) {
          await onCloudConnect(key);
      }
      setIsCloudSetupOpen(false);
  };

  // Render Subviews
  if (subView === 'edit') return <EditProfileView user={user} onSave={(u) => onUpdateProfile && onUpdateProfile(u)} onBack={() => setSubView('main')} />;
  if (subView === 'accounts') return <AccountsView onBack={() => setSubView('main')} />;
  if (subView === 'notifications') return <NotificationsView onBack={() => setSubView('main')} />;
  if (subView === 'security') return <SecurityView user={user} onUpdateSecurity={handleUpdateSecurity} onBack={() => setSubView('main')} />;
  if (subView === 'export') return <ExportCenterView user={user} transactions={transactions} debts={debts} customCategories={customCategories} onImportData={onImportData} onBack={() => setSubView('main')} onOpenSpreadsheet={onOpenSpreadsheet} />;

  const isCloudConfigured = !!user.cloudConfig?.apiKey;

  return (
    <div className="flex flex-col h-full pt-4 pb-24 overflow-y-auto no-scrollbar">
       <div className="px-6 mb-6 flex items-center justify-between">
            <h1 className="text-2xl font-bold text-white">Perfil</h1>
            <button className="p-2 bg-surface rounded-full text-neutral-400 hover:text-white transition-colors">
                <Settings size={20} />
            </button>
       </div>

       <div className="px-4 mb-6">
           <div className="bg-surface/50 border border-white/5 rounded-[2rem] p-6 relative overflow-hidden flex flex-col items-center text-center">
                <div className="absolute top-[-50%] left-1/2 -translate-x-1/2 w-40 h-40 bg-primary/30 blur-[80px] rounded-full pointer-events-none" />
                <button onClick={() => setSubView('edit')} className="absolute top-4 right-4 p-2 rounded-full bg-white/5 hover:bg-white/10 text-white transition-colors">
                    <Edit2 size={16} />
                </button>
                <div className="relative mb-4">
                    <div className="w-28 h-28 rounded-full p-1 bg-gradient-to-br from-primary via-purple-500 to-blue-500">
                        <img src={user.avatarUrl} alt={user.name} className="w-full h-full rounded-full object-cover border-4 border-[#121212]" />
                    </div>
                </div>
                <h2 className="text-xl font-bold text-white mb-1">{user.name}</h2>
                <p className="text-neutral-400 text-sm mb-4">{user.email}</p>
           </div>
       </div>

       <div className="px-6 grid grid-cols-2 gap-3 mb-6">
            <div className="bg-surface rounded-2xl p-4 border border-white/5">
                <div className="flex items-center gap-2 mb-2 text-neutral-400"><Target size={16} /><span className="text-xs uppercase font-bold">Meta</span></div>
                <div className="flex items-end gap-1"><span className="text-xl font-bold text-white">75%</span></div>
                <div className="w-full h-1.5 bg-neutral-800 rounded-full mt-2 overflow-hidden"><div className="w-[75%] h-full bg-gradient-to-r from-blue-500 to-purple-500" /></div>
            </div>
            <div className="bg-surface rounded-2xl p-4 border border-white/5">
                <div className="flex items-center gap-2 mb-2 text-neutral-400"><CreditCard size={16} /><span className="text-xs uppercase font-bold">Score</span></div>
                <div className="flex items-end gap-1"><span className="text-xl font-bold text-emerald-400">850</span></div>
            </div>
       </div>

       {/* CLOUD SYNC SECTION */}
       <div className="px-6 space-y-2 mb-6">
           <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-2 px-2 flex items-center gap-2">
               <Github size={12} className="text-white"/> Nube GitHub
           </h3>
           <div className="bg-surface rounded-2xl border border-white/5 p-4">
               {!isCloudConfigured ? (
                   <div className="text-center">
                       <p className="text-sm text-neutral-400 mb-3">Conecta tu cuenta de GitHub para guardar tus datos gratis.</p>
                       <button onClick={() => setIsCloudSetupOpen(true)} className="w-full py-3 bg-surfaceHighlight border border-white/10 rounded-xl text-white font-bold flex items-center justify-center gap-2 hover:bg-white/5">
                           <Cloud size={16} /> Conectar GitHub
                       </button>
                   </div>
               ) : (
                   <div className="space-y-3">
                       <div className="flex justify-between items-center text-xs text-neutral-500 mb-2">
                           <span>Estado: Conectado</span>
                           <span className="font-mono">Gist: {user.cloudConfig?.binId ? 'Activo' : 'Pendiente'}</span>
                       </div>
                       <div className="grid grid-cols-2 gap-3">
                           <button onClick={onCloudSync} disabled={isSyncing} className="py-3 bg-primary rounded-xl text-white font-bold flex items-center justify-center gap-2 disabled:opacity-50">
                               {isSyncing ? <RefreshCw className="animate-spin" size={16}/> : <Upload size={16}/>} Sincronizar
                           </button>
                           <button onClick={onCloudRestore} disabled={isSyncing} className="py-3 bg-surfaceHighlight border border-white/10 rounded-xl text-white font-medium flex items-center justify-center gap-2 disabled:opacity-50">
                               {isSyncing ? <RefreshCw className="animate-spin" size={16}/> : <Download size={16}/>} Restaurar
                           </button>
                       </div>
                       {user.cloudConfig?.lastSync && <p className="text-[10px] text-center text-neutral-600 mt-2">Última copia: {new Date(user.cloudConfig.lastSync).toLocaleString()}</p>}
                   </div>
               )}
           </div>
       </div>

       <div className="px-6 space-y-2 mb-6">
           <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-2 px-2">Gestión de Datos</h3>
           
           {/* New Export Center Button */}
           <button onClick={() => setSubView('export')} className="w-full flex items-center justify-between p-4 bg-surface rounded-2xl border border-white/5 active:scale-[0.98] transition-all group">
                <div className="flex items-center gap-3">
                    <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 group-hover:bg-emerald-500 group-hover:text-black transition-colors">
                        <FileSpreadsheet size={20} />
                    </div>
                    <div className="text-left">
                        <span className="text-neutral-200 font-medium block">Excel & Reportes</span>
                        <span className="text-neutral-500 text-xs block">Exportar CSV, Backup JSON</span>
                    </div>
                </div>
                <ChevronRight size={18} className="text-neutral-600" />
           </button>
       </div>

       <div className="px-6 space-y-2">
           <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-2 px-2">General</h3>
           <button onClick={() => setSubView('accounts')} className="w-full flex items-center justify-between p-4 bg-surface rounded-2xl border border-white/5 active:scale-[0.98] transition-all">
                <div className="flex items-center gap-3"><div className="p-2 rounded-xl bg-blue-500/10 text-blue-400"><Wallet size={20} /></div><span className="text-neutral-200 font-medium">Cuentas</span></div><ChevronRight size={18} className="text-neutral-600" />
           </button>
           <button onClick={() => setSubView('notifications')} className="w-full flex items-center justify-between p-4 bg-surface rounded-2xl border border-white/5 active:scale-[0.98] transition-all">
                <div className="flex items-center gap-3"><div className="p-2 rounded-xl bg-orange-500/10 text-orange-400"><Bell size={20} /></div><span className="text-neutral-200 font-medium">Notificaciones</span></div>
           </button>
           <button onClick={() => setSubView('security')} className="w-full flex items-center justify-between p-4 bg-surface rounded-2xl border border-white/5 active:scale-[0.98] transition-all">
                <div className="flex items-center gap-3"><div className="p-2 rounded-xl bg-purple-500/10 text-purple-400"><Shield size={20} /></div><span className="text-neutral-200 font-medium">Seguridad</span></div><ChevronRight size={18} className="text-neutral-600" />
           </button>
           <button onClick={onLogout} className="w-full flex items-center justify-between p-4 bg-surface rounded-2xl border border-white/5 active:scale-[0.98] transition-all mt-4 hover:bg-red-500/10 hover:border-red-500/20">
                <div className="flex items-center gap-3"><div className="p-2 rounded-xl bg-red-500/10 text-red-400"><LogOut size={20} /></div><span className="text-red-400 font-medium">Cerrar Sesión</span></div>
           </button>
       </div>
       
       <CloudSetupModal isOpen={isCloudSetupOpen} onClose={() => setIsCloudSetupOpen(false)} onSave={handleCloudSetup} isSyncing={isSyncing} />
    </div>
  );
};
