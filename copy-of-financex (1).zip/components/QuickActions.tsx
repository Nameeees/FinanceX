

import React from 'react';
import { motion } from 'framer-motion';
import { Plus, Coffee, ShoppingBag, Car, Film, Zap, Home, Briefcase, TrendingUp, Gift, Award, Star, Heart, Smile, Tag, ShoppingCart, Music, Book, Wrench } from 'lucide-react';
import { QuickAction, TransactionType } from '../types';

interface QuickActionsProps {
  actions: QuickAction[];
  onExecute: (action: QuickAction) => void;
  onAdd: () => void;
  onEdit: (action: QuickAction) => void;
}

const ICON_MAP: Record<string, any> = {
  'Coffee': Coffee, 'ShoppingBag': ShoppingBag, 'Car': Car, 'Film': Film, 'Zap': Zap,
  'Home': Home, 'Briefcase': Briefcase, 'TrendingUp': TrendingUp,
  'Gift': Gift, 'Award': Award, 'Star': Star, 'Heart': Heart, 'Smile': Smile,
  'Tag': Tag, 'ShoppingCart': ShoppingCart, 'Music': Music, 'Book': Book, 'Tool': Wrench
};

export const QuickActions: React.FC<QuickActionsProps> = ({ actions, onExecute, onAdd, onEdit }) => {
  return (
    <div className="w-full mb-2">
      <div className="flex justify-between items-center px-6 mb-3">
          <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider">Accesos Rápidos</h3>
      </div>
      
      <div className="flex gap-3 overflow-x-auto no-scrollbar px-6 pb-2 fade-r-mask">
        {/* Add Button */}
        <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={onAdd}
            className="flex flex-col items-center justify-center gap-1 min-w-[80px] h-[90px] rounded-2xl bg-surface border border-white/5 border-dashed hover:bg-surfaceHighlight hover:border-white/20 transition-all shrink-0"
        >
            <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-neutral-400">
                <Plus size={18} />
            </div>
            <span className="text-[10px] font-medium text-neutral-500">Nuevo</span>
        </motion.button>

        {/* Action List */}
        {actions.map((action) => {
            const Icon = ICON_MAP[action.icon] || Star;
            const isExpense = action.type === TransactionType.EXPENSE;
            
            return (
                <motion.button
                    key={action.id}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => onExecute(action)}
                    onContextMenu={(e) => {
                        e.preventDefault();
                        onEdit(action);
                    }}
                    className={`flex flex-col items-center justify-between py-3 min-w-[80px] h-[90px] rounded-2xl border backdrop-blur-md shrink-0 relative overflow-hidden group transition-all ${
                        isExpense 
                        ? 'bg-rose-500/5 border-rose-500/10 hover:bg-rose-500/10' 
                        : 'bg-emerald-500/5 border-emerald-500/10 hover:bg-emerald-500/10'
                    }`}
                >
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white ${isExpense ? 'bg-rose-500/20 text-rose-400' : 'bg-emerald-500/20 text-emerald-400'}`}>
                        <Icon size={16} />
                    </div>
                    
                    <div className="flex flex-col items-center gap-0.5">
                        <span className="text-[10px] font-bold text-neutral-300 truncate w-[70px] text-center">{action.title}</span>
                        <span className={`text-xs font-bold font-mono ${isExpense ? 'text-rose-400' : 'text-emerald-400'}`}>${action.amount}</span>
                    </div>
                </motion.button>
            );
        })}
      </div>
    </div>
  );
};
