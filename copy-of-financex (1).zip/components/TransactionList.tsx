
import React from 'react';
import { motion } from 'framer-motion';
import { Transaction, TransactionType } from '../types';
import { CATEGORY_COLORS } from '../constants';
import { ShoppingBag, Coffee, Home, Car, Zap, Briefcase, Film, ArrowRight, TrendingUp, Gift, Award, Smartphone, ChevronRight, CalendarClock, DollarSign } from 'lucide-react';

interface TransactionListProps {
  transactions: Transaction[];
  limit?: number;
  title?: string;
  showViewAll?: boolean;
  onViewAllClick?: () => void;
  onTransactionClick?: (transaction: Transaction) => void;
}

const getIcon = (category: string) => {
  switch (category.toLowerCase()) {
    case 'comida': return <Coffee size={20} />;
    case 'supermercado': return <ShoppingBag size={20} />;
    case 'salario': return <Briefcase size={20} />;
    case 'transporte': return <Car size={20} />;
    case 'entretenimiento': case 'ocio': return <Film size={20} />;
    case 'servicios': return <Zap size={20} />;
    case 'negocios': return <TrendingUp size={20} />;
    case 'regalo': return <Gift size={20} />;
    case 'inversion': return <Award size={20} />;
    case 'tecnologia': case 'tech': return <Smartphone size={20} />;
    default: return <Home size={20} />;
  }
};

// Función auxiliar para formatear fecha relativa
const formatDate = (dateStr: string) => {
    const date = new Date(dateStr + 'T00:00:00'); // Fix timezone offset issues roughly
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);

    const isToday = date.toDateString() === today.toDateString();
    const isYesterday = date.toDateString() === yesterday.toDateString();

    if (isToday) return 'Hoy';
    if (isYesterday) return 'Ayer';
    
    // Format: 12 Oct
    return date.toLocaleDateString('es-ES', { day: 'numeric', month: 'short' });
};

export const TransactionList: React.FC<TransactionListProps> = ({ 
  transactions, 
  limit, 
  title = "Recientes",
  showViewAll = true,
  onViewAllClick,
  onTransactionClick
}) => {
  const displayedTransactions = limit ? transactions.slice(0, limit) : transactions;

  return (
    <div className="px-6 pb-24">
      {/* Section Header */}
      {(title || showViewAll) && (
        <div className="flex justify-between items-end mb-5 px-1">
          {title && <h2 className="text-lg font-bold text-white tracking-wide">{title}</h2>}
          {showViewAll && (
            <button 
              onClick={onViewAllClick}
              className="group flex items-center gap-1 text-primary text-xs font-bold uppercase tracking-wider hover:text-primaryGlow transition-colors bg-primary/10 px-3 py-1.5 rounded-full"
            >
                Ver todo 
                <ArrowRight size={12} className="group-hover:translate-x-1 transition-transform" />
            </button>
          )}
        </div>
      )}

      <div className="flex flex-col gap-3">
        {displayedTransactions.length === 0 ? (
           <div className="flex flex-col items-center justify-center py-12 text-neutral-600 bg-surface/30 rounded-[2rem] border border-dashed border-white/5">
              <div className="w-12 h-12 rounded-full bg-surface mb-3 flex items-center justify-center text-neutral-700">
                  <DollarSign size={20} />
              </div>
              <span className="text-sm font-medium">No hay movimientos</span>
           </div>
        ) : (
          displayedTransactions.map((t, index) => {
            const isIncome = t.type === TransactionType.INCOME;
            
            // Resolve styles
            const categoryKey = Object.keys(CATEGORY_COLORS).find(k => k.toLowerCase() === t.category.toLowerCase()) || 'Default';
            // Extract colors roughly from the class string or default
            const rawColorClass = CATEGORY_COLORS[categoryKey] || CATEGORY_COLORS['Default'];
            
            // Custom styling based on type
            const accentColor = isIncome ? 'bg-emerald-500' : 'bg-rose-500';
            const accentText = isIncome ? 'text-emerald-400' : 'text-neutral-200';
            const shadowColor = isIncome ? 'shadow-emerald-500/10' : 'shadow-rose-500/10';

            return (
              <motion.button
                key={t.id}
                onClick={() => onTransactionClick && onTransactionClick(t)}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05, type: "spring", stiffness: 300, damping: 20 }}
                whileTap={{ scale: 0.98 }}
                className={`group relative w-full flex items-center justify-between p-4 rounded-[1.5rem] bg-[#121212] hover:bg-[#181818] border border-white/5 hover:border-white/10 transition-all duration-300 shadow-lg ${shadowColor}`}
              >
                {/* Side Accent Line (Glow) */}
                <div className={`absolute left-0 top-4 bottom-4 w-1 rounded-r-full opacity-60 group-hover:opacity-100 transition-opacity ${accentColor} shadow-[0_0_10px_rgba(0,0,0,0.5)]`} />

                <div className="flex items-center gap-4 pl-3">
                  {/* Icon Container */}
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110 ${rawColorClass} shadow-inner`}>
                    {getIcon(t.category)}
                  </div>
                  
                  {/* Text Info */}
                  <div className="flex flex-col items-start gap-1">
                    <span className="font-bold text-white text-base leading-none tracking-tight">{t.title}</span>
                    
                    <div className="flex items-center gap-2">
                        {/* Category Pill */}
                        <div className="px-2 py-0.5 rounded-md bg-white/5 border border-white/5 text-[10px] font-medium text-neutral-400 capitalize">
                            {t.category}
                        </div>
                        {/* Date */}
                        <div className="flex items-center gap-1 text-[10px] text-neutral-500 font-medium">
                            <CalendarClock size={10} />
                            {formatDate(t.date)}
                        </div>
                    </div>
                  </div>
                </div>
                
                {/* Amount & Arrow */}
                <div className="flex items-center gap-3">
                    <div className="text-right">
                        <span className={`block font-bold font-mono text-base ${isIncome ? 'text-emerald-400' : 'text-white'}`}>
                            {isIncome ? '+' : '-'}${t.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                    </div>
                    <ChevronRight size={16} className="text-neutral-700 group-hover:text-neutral-400 transition-colors" />
                </div>
              </motion.button>
            );
          })
        )}
      </div>
    </div>
  );
};
