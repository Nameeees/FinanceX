

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Check, Delete, ArrowUpCircle, ArrowDownCircle, ShoppingBag, Coffee, Car, Film, Zap, Home, Briefcase, Gift, Award, TrendingUp, Smartphone, Star, Heart, Smile, Tag, ShoppingCart, Music, Book, Wrench, Zap as ZapIcon, Trash2 } from 'lucide-react';
import { TransactionType, QuickAction } from '../../types';

interface AddQuickActionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (action: Omit<QuickAction, 'id'>, id?: string) => void;
  onDelete?: (id: string) => void;
  initialData?: QuickAction | null;
}

const ICON_MAP: Record<string, any> = {
  'Coffee': Coffee, 'ShoppingBag': ShoppingBag, 'Car': Car, 'Film': Film, 'Zap': Zap,
  'Home': Home, 'Briefcase': Briefcase, 'TrendingUp': TrendingUp,
  'Gift': Gift, 'Award': Award, 'Star': Star, 'Heart': Heart, 'Smile': Smile,
  'Tag': Tag, 'ShoppingCart': ShoppingCart, 'Music': Music, 'Book': Book, 'Tool': Wrench
};

export const AddQuickActionModal: React.FC<AddQuickActionModalProps> = ({ 
  isOpen, 
  onClose, 
  onSave, 
  onDelete,
  initialData 
}) => {
  const [amount, setAmount] = useState('0');
  const [title, setTitle] = useState('');
  const [type, setType] = useState<TransactionType>(TransactionType.EXPENSE);
  const [selectedIcon, setSelectedIcon] = useState('Star');
  const [selectedCategory, setSelectedCategory] = useState('otros');
  
  // State to track if user is typing to hide numeric keypad
  const [isInputFocused, setIsInputFocused] = useState(false);

  const isExpense = type === TransactionType.EXPENSE;
  const activeColor = isExpense ? 'text-expense' : 'text-income';
  const activeBg = isExpense ? 'bg-expense' : 'bg-income';

  const formatNumberString = (value: string) => {
    const parts = value.split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return parts.join('.');
  };

  useEffect(() => {
    if (isOpen) {
        if (initialData) {
            setAmount(formatNumberString(initialData.amount.toString()));
            setTitle(initialData.title);
            setType(initialData.type);
            setSelectedIcon(initialData.icon);
            setSelectedCategory(initialData.category);
        } else {
            setAmount('0');
            setTitle('');
            setType(TransactionType.EXPENSE);
            setSelectedIcon('Star');
            setSelectedCategory('otros');
        }
        setIsInputFocused(false);
    }
  }, [isOpen, initialData]);

  const handleNumberPress = (num: string) => {
    let rawValue = amount.replace(/,/g, '');
    if (num === '.') {
      if (rawValue.includes('.')) return;
      rawValue += '.';
    } else {
      if (rawValue === '0') rawValue = num;
      else {
        if (rawValue.replace('.', '').length >= 12) return;
        rawValue += num;
      }
    }
    setAmount(formatNumberString(rawValue));
  };

  const handleDelete = () => {
    let rawValue = amount.replace(/,/g, '');
    if (rawValue.length <= 1) setAmount('0');
    else {
      rawValue = rawValue.slice(0, -1);
      if (rawValue === '') rawValue = '0';
      setAmount(formatNumberString(rawValue));
    }
  };

  const handleSave = () => {
    const numericAmount = parseFloat(amount.replace(/,/g, ''));
    if (numericAmount <= 0 || !title.trim()) return;

    onSave({
      title,
      amount: numericAmount,
      type,
      category: selectedCategory,
      icon: selectedIcon
    }, initialData?.id);
    
    // Reset
    setAmount('0');
    setTitle('');
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[60]"
          />

          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed bottom-0 left-0 right-0 z-[70] bg-[#0f0f0f] rounded-t-[2.5rem] border-t border-white/10 overflow-hidden shadow-2xl h-[94vh] flex flex-col"
          >
            <div className="px-6 pt-6 pb-2 shrink-0">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-white font-medium text-lg tracking-tight">
                    {initialData ? 'Editar Acceso Rápido' : 'Nuevo Acceso Rápido'}
                </h3>
                
                <div className="flex gap-2">
                    {initialData && onDelete && (
                        <button 
                            onClick={() => onDelete(initialData.id)}
                            className="p-2 rounded-full bg-surface text-red-400 hover:bg-red-500/10 transition-colors"
                        >
                            <Trash2 size={20} />
                        </button>
                    )}
                    <button onClick={onClose} className="p-2 rounded-full bg-surface text-neutral-400 hover:text-white transition-colors">
                        <X size={20} />
                    </button>
                </div>
              </div>

              {/* Hide toggles when typing to save space */}
              {!isInputFocused && (
                <div className="grid grid-cols-2 gap-2 bg-surface p-1.5 rounded-2xl mb-4">
                    <button
                    onClick={() => setType(TransactionType.INCOME)}
                    className={`flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-semibold transition-all duration-300 ${!isExpense ? 'bg-surfaceHighlight text-income shadow-lg' : 'text-neutral-500'}`}
                    >
                    <ArrowUpCircle size={18} /> Ingreso
                    </button>
                    <button
                    onClick={() => setType(TransactionType.EXPENSE)}
                    className={`flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-semibold transition-all duration-300 ${isExpense ? 'bg-surfaceHighlight text-expense shadow-lg' : 'text-neutral-500'}`}
                    >
                    <ArrowDownCircle size={18} /> Gasto
                    </button>
                </div>
              )}
            </div>

            <div className="flex-1 overflow-y-auto no-scrollbar px-6 flex flex-col">
                {/* Amount Section */}
                <div className={`flex flex-col items-center justify-center mb-6 shrink-0 transition-all ${isInputFocused ? 'opacity-50 scale-90 hidden' : 'opacity-100'}`}>
                    <span className="text-neutral-500 mb-2 font-medium tracking-widest text-xs uppercase">Cantidad Fija</span>
                    <div className="flex items-baseline gap-1">
                        <span className={`text-3xl font-light ${activeColor}`}>$</span>
                        <span className={`text-6xl font-bold tracking-tighter ${activeColor} break-all text-center`}>{amount}</span>
                    </div>
                </div>

                {/* Input Section */}
                <div className={`bg-surfaceHighlight/50 rounded-xl flex items-center px-4 py-3 border border-white/5 focus-within:border-white/20 transition-all mb-4 shrink-0 ${isInputFocused ? 'ring-2 ring-primary/50 bg-surface' : ''}`}>
                    <ZapIcon size={18} className="text-neutral-500 mr-3" />
                    <input 
                        type="text" 
                        value={title}
                        onFocus={() => setIsInputFocused(true)}
                        onBlur={() => setIsInputFocused(false)}
                        onChange={(e) => setTitle(e.target.value)}
                        placeholder="Nombre (ej: Café, Pasaje)"
                        className="bg-transparent border-none outline-none text-white w-full placeholder:text-neutral-600 font-medium text-lg"
                    />
                </div>

                {/* Icons Section */}
                <div className="mb-4 shrink-0">
                    <label className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-2 block">Icono</label>
                    <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2">
                        {Object.keys(ICON_MAP).map(key => {
                            const Icon = ICON_MAP[key];
                            return (
                                <button 
                                    key={key}
                                    onClick={() => setSelectedIcon(key)}
                                    className={`p-3 rounded-xl border transition-all shrink-0 ${selectedIcon === key ? `bg-surfaceHighlight border-white text-white` : 'bg-surface border-white/5 text-neutral-500'}`}
                                >
                                    <Icon size={20} />
                                </button>
                            );
                        })}
                    </div>
                </div>
            </div>

            {/* Bottom Keypad / Save Area */}
            <div className="bg-surface/50 backdrop-blur-md pb-8 pt-4 px-6 rounded-t-[2.5rem] border-t border-white/5 transition-all flex flex-col justify-end flex-1 max-h-[45vh]">
                {/* Only show numeric keypad if NOT typing text */}
                {!isInputFocused && (
                    <motion.div 
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="grid grid-cols-3 gap-3 mb-4 flex-1 max-h-[220px]"
                    >
                        {[1, 2, 3, 4, 5, 6, 7, 8, 9, '.', 0].map((num) => (
                        <button
                            key={num}
                            onClick={() => handleNumberPress(num.toString())}
                            className="h-full rounded-2xl bg-surface active:bg-surfaceHighlight text-white text-2xl font-medium active:scale-95 flex items-center justify-center border border-white/5 outline-none"
                            style={{ WebkitTapHighlightColor: 'transparent' }}
                        >
                            {num}
                        </button>
                        ))}
                        <button
                            onClick={handleDelete}
                            className="h-full rounded-2xl bg-surface active:bg-red-500/20 text-neutral-300 active:text-red-400 active:scale-95 flex items-center justify-center border border-white/5 outline-none"
                            style={{ WebkitTapHighlightColor: 'transparent' }}
                        >
                            <Delete size={24} />
                        </button>
                    </motion.div>
                )}

                <button
                    onClick={handleSave}
                    // Prevent button from taking focus on tap which triggers keypad flash
                    onMouseDown={(e) => e.preventDefault()}
                    disabled={!title || amount === '0'}
                    className={`w-full h-14 shrink-0 rounded-2xl ${activeBg} text-white text-lg font-bold flex items-center justify-center gap-2 shadow-lg active:scale-95 outline-none disabled:opacity-50 transition-all`}
                >
                    <Check size={24} strokeWidth={3} />
                    {initialData ? 'Actualizar' : 'Crear'}
                </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
