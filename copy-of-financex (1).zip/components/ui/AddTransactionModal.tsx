
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Check, Delete, ArrowUpCircle, ArrowDownCircle, ShoppingBag, Coffee, Car, Film, Zap, Home, Briefcase, Gift, Award, TrendingUp, Smartphone, FileText, Plus, Star, Heart, Smile, Tag, ShoppingCart, Music, Book, Wrench } from 'lucide-react';
import { TransactionType, Transaction } from '../../types';

interface AddTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (amount: number, type: TransactionType, categoryId: string, categoryName: string, description: string, id?: string) => void;
  initialData?: Transaction | null;
  customCategories?: {id: string, name: string, icon: string, type: TransactionType}[];
  onCreateCategory?: (name: string, icon: string, type: TransactionType) => void;
}

const DEFAULT_EXPENSE_CATEGORIES = [
  { id: 'comida', name: 'Comida', icon: 'Coffee' },
  { id: 'supermercado', name: 'Súper', icon: 'ShoppingBag' },
  { id: 'transporte', name: 'Transporte', icon: 'Car' },
  { id: 'entretenimiento', name: 'Ocio', icon: 'Film' },
  { id: 'servicios', name: 'Servicios', icon: 'Zap' },
  { id: 'hogar', name: 'Hogar', icon: 'Home' },
  { id: 'tecnologia', name: 'Tech', icon: 'Smartphone' },
];

const DEFAULT_INCOME_CATEGORIES = [
  { id: 'salario', name: 'Salario', icon: 'Briefcase' },
  { id: 'negocios', name: 'Negocios', icon: 'TrendingUp' },
  { id: 'regalo', name: 'Regalo', icon: 'Gift' },
  { id: 'inversion', name: 'Inversión', icon: 'Award' },
  { id: 'otros', name: 'Otros', icon: 'Home' },
];

// Map string names to Lucide components
const ICON_MAP: Record<string, any> = {
  'Coffee': Coffee,
  'ShoppingBag': ShoppingBag,
  'Car': Car,
  'Film': Film,
  'Zap': Zap,
  'Home': Home,
  'Smartphone': Smartphone,
  'Briefcase': Briefcase,
  'TrendingUp': TrendingUp,
  'Gift': Gift,
  'Award': Award,
  'Star': Star,
  'Heart': Heart,
  'Smile': Smile,
  'Tag': Tag,
  'ShoppingCart': ShoppingCart,
  'Music': Music,
  'Book': Book,
  'Tool': Wrench
};

const AVAILABLE_ICONS = ['Star', 'Heart', 'Smile', 'Tag', 'ShoppingCart', 'Music', 'Book', 'Tool', 'Zap', 'Home'];

export const AddTransactionModal: React.FC<AddTransactionModalProps> = ({ 
  isOpen, 
  onClose, 
  onSave, 
  initialData, 
  customCategories = [], 
  onCreateCategory 
}) => {
  const [amount, setAmount] = useState('0');
  const [type, setType] = useState<TransactionType>(TransactionType.EXPENSE);
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [description, setDescription] = useState('');
  
  // Create Category Mode State
  const [isCreatingCategory, setIsCreatingCategory] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [newCategoryIcon, setNewCategoryIcon] = useState('Star');

  const isExpense = type === TransactionType.EXPENSE;
  const activeColor = isExpense ? 'text-expense' : 'text-income';
  const activeBg = isExpense ? 'bg-expense' : 'bg-income';
  
  // Merge default + custom categories
  const currentCategories = [
    ...(isExpense ? DEFAULT_EXPENSE_CATEGORIES : DEFAULT_INCOME_CATEGORIES),
    ...customCategories.filter(c => c.type === type)
  ];

  // Helper to format string with commas
  const formatNumberString = (value: string) => {
    const parts = value.split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return parts.join('.');
  };

  // Reset or Hydrate state when opening
  useEffect(() => {
    if (isOpen) {
      if (initialData) {
        // Edit Mode
        setAmount(formatNumberString(initialData.amount.toString()));
        setType(initialData.type);
        setSelectedCategory(initialData.category.toLowerCase());
        setDescription(initialData.description || '');
      } else {
        // Create Mode
        setAmount('0');
        setType(TransactionType.EXPENSE);
        setSelectedCategory(DEFAULT_EXPENSE_CATEGORIES[0].id);
        setDescription('');
      }
      setIsCreatingCategory(false);
      setNewCategoryName('');
    }
  }, [isOpen, initialData]);

  // Auto-switch default category when type changes
  useEffect(() => {
    if (!initialData && isOpen && !isCreatingCategory) {
        const list = [
            ...(isExpense ? DEFAULT_EXPENSE_CATEGORIES : DEFAULT_INCOME_CATEGORIES),
            ...customCategories.filter(c => c.type === (isExpense ? TransactionType.EXPENSE : TransactionType.INCOME))
        ];
        const isValid = list.find(c => c.id === selectedCategory);
        if (!isValid) {
            setSelectedCategory(list[0]?.id || 'default');
        }
    }
  }, [isExpense, isOpen, initialData, isCreatingCategory, customCategories]);


  const handleNumberPress = (num: string) => {
    let rawValue = amount.replace(/,/g, '');

    if (num === '.') {
      if (rawValue.includes('.')) return;
      rawValue += '.';
    } else {
      if (rawValue === '0') {
        rawValue = num;
      } else {
        if (rawValue.replace('.', '').length >= 12) return;
        rawValue += num;
      }
    }

    setAmount(formatNumberString(rawValue));
  };

  const handleDelete = () => {
    let rawValue = amount.replace(/,/g, '');
    
    if (rawValue.length <= 1) {
      setAmount('0');
    } else {
      rawValue = rawValue.slice(0, -1);
      if (rawValue === '') rawValue = '0';
      setAmount(formatNumberString(rawValue));
    }
  };

  const handleSave = () => {
    const numericAmount = parseFloat(amount.replace(/,/g, ''));
    if (numericAmount <= 0) return;

    const categoryObj = currentCategories.find(c => c.id === selectedCategory) 
        || currentCategories[0];
    
    onSave(
        numericAmount, 
        type, 
        selectedCategory, 
        categoryObj?.name || 'Varios', 
        description,
        initialData?.id 
    );
    onClose();
  };

  const handleSaveNewCategory = () => {
    if (!newCategoryName.trim()) return;
    if (onCreateCategory) {
        onCreateCategory(newCategoryName, newCategoryIcon, type);
        // Select the newly created category
        setSelectedCategory(newCategoryName.toLowerCase().replace(/\s+/g, '-'));
    }
    setIsCreatingCategory(false);
    setNewCategoryName('');
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[60]"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed bottom-0 left-0 right-0 z-[70] bg-[#0f0f0f] rounded-t-[2.5rem] border-t border-white/10 overflow-hidden shadow-2xl h-[94vh] flex flex-col"
          >
            {/* Header / Type Selector */}
            <div className="px-6 pt-6 pb-2 shrink-0">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-white font-medium text-lg tracking-tight">
                    {isCreatingCategory 
                        ? 'Crear Categoría' 
                        : (initialData ? 'Editar Transacción' : 'Nueva Transacción')}
                </h3>
                <button 
                  onClick={() => {
                    if (isCreatingCategory) {
                        setIsCreatingCategory(false);
                    } else {
                        onClose();
                    }
                  }}
                  className="p-2 rounded-full bg-surface text-neutral-400 hover:text-white transition-colors"
                >
                  <X size={20} />
                </button>
              </div>

              {/* Toggle Switch (Disabled when creating category to avoid confusion) */}
              <div className={`grid grid-cols-2 gap-2 bg-surface p-1.5 rounded-2xl mb-2 transition-opacity ${isCreatingCategory ? 'opacity-50 pointer-events-none' : ''}`}>
                <button
                  onClick={() => setType(TransactionType.INCOME)}
                  className={`flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-semibold transition-all duration-300 ${
                    !isExpense ? 'bg-surfaceHighlight text-income shadow-lg' : 'text-neutral-500 hover:text-neutral-300'
                  }`}
                >
                  <ArrowUpCircle size={18} />
                  Ingreso
                </button>
                <button
                  onClick={() => setType(TransactionType.EXPENSE)}
                  className={`flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-semibold transition-all duration-300 ${
                    isExpense ? 'bg-surfaceHighlight text-expense shadow-lg' : 'text-neutral-500 hover:text-neutral-300'
                  }`}
                >
                  <ArrowDownCircle size={18} />
                  Gasto
                </button>
              </div>
            </div>

            {/* Content Switcher */}
            <AnimatePresence mode="wait">
                {!isCreatingCategory ? (
                    <motion.div 
                        key="transaction-form"
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="flex flex-col flex-1 h-full"
                    >
                         {/* Amount Display */}
                        <div className="shrink-0 flex flex-col items-center justify-center py-2 min-h-[100px]">
                        <span className="text-neutral-500 mb-2 font-medium tracking-widest text-xs uppercase">Cantidad</span>
                        <div className="flex items-baseline gap-1 px-4">
                            <span className={`text-3xl font-light ${activeColor}`}>$</span>
                            <span className={`text-6xl font-bold tracking-tighter ${activeColor} transition-colors duration-300 break-all text-center`}>
                            {amount}
                            </span>
                        </div>
                        </div>

                        {/* Category Selector (Horizontal Scroll) */}
                        <div className="shrink-0 w-full mb-2">
                            <span className="text-neutral-500 text-xs font-medium tracking-wider uppercase mb-1 block px-6">Categoría</span>
                        
                            <div className="flex gap-4 overflow-x-auto no-scrollbar py-4 px-6 fade-r-mask items-center">
                                {currentCategories.map((cat) => {
                                    const isSelected = selectedCategory === cat.id;
                                    const IconComponent = ICON_MAP[cat.icon] || Home;
                                    return (
                                    <button
                                        key={cat.id}
                                        onClick={() => setSelectedCategory(cat.id)}
                                        className={`flex flex-col items-center gap-2 transition-all duration-300 ${isSelected ? 'scale-105' : 'opacity-60 scale-95'}`}
                                    >
                                        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all duration-300 border ${
                                        isSelected 
                                            ? `${activeBg}/20 ${activeColor} border-${isExpense ? 'expense' : 'income'}/50 shadow-[0_0_15px_rgba(0,0,0,0.3)]` 
                                            : 'bg-surface border-white/5 text-neutral-400'
                                        }`}>
                                            <IconComponent size={24} strokeWidth={isSelected ? 2.5 : 2} />
                                        </div>
                                        <span className={`text-xs font-medium whitespace-nowrap ${isSelected ? 'text-white' : 'text-neutral-500'}`}>
                                        {cat.name}
                                        </span>
                                    </button>
                                    )
                                })}
                                {/* Add Category Button */}
                                <button
                                    onClick={() => setIsCreatingCategory(true)}
                                    className="flex flex-col items-center gap-2 opacity-60 hover:opacity-100 scale-95 hover:scale-100 transition-all"
                                >
                                    <div className="w-14 h-14 rounded-2xl flex items-center justify-center bg-surface border border-white/5 text-neutral-400 hover:bg-surfaceHighlight hover:text-white">
                                        <Plus size={24} />
                                    </div>
                                    <span className="text-xs font-medium text-neutral-500">Crear</span>
                                </button>
                                <div className="w-2 shrink-0" />
                            </div>
                        </div>

                        {/* Description Input */}
                        <div className="px-6 mb-4 shrink-0">
                            <div className="bg-surfaceHighlight/50 rounded-xl flex items-center px-4 py-3 border border-white/5 focus-within:border-white/20 transition-colors">
                                <FileText size={18} className="text-neutral-500 mr-3" />
                                <input 
                                    type="text" 
                                    value={description}
                                    onChange={(e) => setDescription(e.target.value)}
                                    placeholder="Agregar nota (opcional)..."
                                    className="bg-transparent border-none outline-none text-white w-full placeholder:text-neutral-600 text-sm"
                                />
                            </div>
                        </div>

                        {/* Custom Keypad */}
                        <div className="flex-1 bg-surface/50 backdrop-blur-md pb-8 pt-4 px-6 rounded-t-[2.5rem] border-t border-white/5 flex flex-col justify-end">
                            <div className="grid grid-cols-3 gap-3 mb-4 h-full max-h-[220px]">
                                {[1, 2, 3, 4, 5, 6, 7, 8, 9, '.', 0].map((num) => (
                                <button
                                    key={num}
                                    onClick={() => handleNumberPress(num.toString())}
                                    className="h-full rounded-2xl bg-surface active:bg-surfaceHighlight text-white text-2xl font-medium transition-colors active:scale-95 flex items-center justify-center shadow-sm border border-white/5 outline-none touch-manipulation"
                                    style={{ WebkitTapHighlightColor: 'transparent' }}
                                >
                                    {num}
                                </button>
                                ))}
                                
                                <button
                                onClick={handleDelete}
                                className="h-full rounded-2xl bg-surface active:bg-red-500/20 text-neutral-300 active:text-red-400 transition-colors active:scale-95 flex items-center justify-center border border-white/5 outline-none touch-manipulation"
                                style={{ WebkitTapHighlightColor: 'transparent' }}
                                >
                                <Delete size={24} />
                                </button>
                            </div>

                            {/* Submit Button */}
                            <button
                                onClick={handleSave}
                                className={`w-full h-14 shrink-0 rounded-2xl ${activeBg} text-white text-lg font-bold flex items-center justify-center gap-2 shadow-[0_0_30px_-10px_rgba(0,0,0,0.5)] transition-all active:scale-95 outline-none`}
                            >
                                <Check size={24} strokeWidth={3} />
                                {initialData ? 'Actualizar' : 'Guardar'}
                            </button>
                        </div>
                    </motion.div>
                ) : (
                    <motion.div
                        key="create-category-form"
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 20 }}
                        className="flex flex-col flex-1 px-6 pt-4 h-full"
                    >
                        <div className="flex-1">
                             {/* Preview */}
                             <div className="flex flex-col items-center justify-center mb-8">
                                <div className={`w-20 h-20 rounded-3xl flex items-center justify-center text-3xl mb-4 ${activeBg} text-white shadow-2xl`}>
                                    {(() => {
                                        const Icon = ICON_MAP[newCategoryIcon] || Star;
                                        return <Icon size={40} />;
                                    })()}
                                </div>
                                <span className="text-neutral-500 text-sm">Vista previa</span>
                             </div>

                             {/* Name Input */}
                             <div className="mb-6">
                                <label className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-2 block">Nombre</label>
                                <input 
                                    type="text" 
                                    value={newCategoryName}
                                    onChange={(e) => setNewCategoryName(e.target.value)}
                                    placeholder="Ej. Gimnasio"
                                    autoFocus
                                    className="w-full bg-surface border border-white/10 rounded-xl p-4 text-white placeholder:text-neutral-600 outline-none focus:border-white/30 transition-colors font-medium text-lg"
                                />
                             </div>

                             {/* Icon Selector */}
                             <div>
                                <label className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-3 block">Icono</label>
                                <div className="grid grid-cols-5 gap-3">
                                    {AVAILABLE_ICONS.map(iconName => {
                                        const Icon = ICON_MAP[iconName === 'Tool' ? 'Tool' : iconName]; 
                                        const isSelected = newCategoryIcon === iconName;
                                        return (
                                            <button
                                                key={iconName}
                                                onClick={() => setNewCategoryIcon(iconName)}
                                                className={`aspect-square rounded-xl flex items-center justify-center border transition-all ${
                                                    isSelected 
                                                    ? `bg-surfaceHighlight border-white text-white` 
                                                    : 'bg-surface border-white/5 text-neutral-500 hover:bg-surfaceHighlight hover:text-neutral-300'
                                                }`}
                                            >
                                                <Icon size={24} />
                                            </button>
                                        )
                                    })}
                                </div>
                             </div>
                        </div>

                        {/* Actions */}
                        <div className="pb-8 pt-4">
                             <button
                                onClick={handleSaveNewCategory}
                                disabled={!newCategoryName.trim()}
                                className={`w-full h-14 rounded-2xl ${activeBg} text-white text-lg font-bold flex items-center justify-center gap-2 shadow-lg transition-all active:scale-95 outline-none disabled:opacity-50 disabled:scale-100`}
                            >
                                <Check size={24} strokeWidth={3} />
                                Crear Categoría
                            </button>
                            <button
                                onClick={() => setIsCreatingCategory(false)}
                                className="w-full py-4 text-neutral-500 font-medium text-sm mt-2 hover:text-white transition-colors"
                            >
                                Cancelar
                            </button>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
    