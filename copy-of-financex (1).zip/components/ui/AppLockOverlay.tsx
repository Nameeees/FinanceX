
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, Delete, Check, ShieldAlert, ArrowRight, X } from 'lucide-react';
import { SecurityMethod } from '../../types';

interface AppLockOverlayProps {
  isOpen: boolean;
  mode: 'unlock' | 'setup';
  method?: SecurityMethod; // The method to enforce (for unlock) or setup
  savedValue?: string; // The correct value to check against (for unlock)
  onSuccess: (value: string) => void;
  onClose?: () => void; // Only for setup mode cancel
  title?: string; // Custom title override
  description?: string; // Custom description override
}

export const AppLockOverlay: React.FC<AppLockOverlayProps> = ({ 
  isOpen, 
  mode, 
  method = 'PIN', 
  savedValue, 
  onSuccess, 
  onClose,
  title,
  description
}) => {
  const [input, setInput] = useState('');
  const [confirmInput, setConfirmInput] = useState('');
  const [step, setStep] = useState<'enter' | 'confirm'>('enter');
  const [error, setError] = useState(false);
  
  // Pattern state
  const [patternPath, setPatternPath] = useState<number[]>([]);
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (isOpen) {
        resetState();
    }
  }, [isOpen, mode]);

  const resetState = () => {
    setInput('');
    setConfirmInput('');
    setStep('enter');
    setError(false);
    setPatternPath([]);
  };

  const handleError = () => {
    setError(true);
    // Increased timeout to 2000ms (2 seconds) as requested
    setTimeout(() => {
        setError(false);
        setInput('');
        setPatternPath([]);
        if (mode === 'setup' && step === 'confirm') {
            setConfirmInput('');
        }
    }, 2000);
  };

  const handleVerify = (val: string) => {
      if (mode === 'unlock') {
          if (val === savedValue) {
              onSuccess(val);
          } else {
              handleError();
          }
      } else {
          // Setup Mode
          if (step === 'enter') {
              if (val.length < 3) {
                  // Small immediate feedback for short input, no full error lock needed
                  setPatternPath([]);
                  setInput('');
                  return;
              }
              setConfirmInput(val);
              setStep('confirm');
              setInput('');
              setPatternPath([]);
          } else {
              if (val === confirmInput) {
                  onSuccess(val);
              } else {
                  handleError(); // Use same error handler for mismatch
                  // After error clears, reset to enter step manually in timeout? 
                  // No, allow retry or keep logic simple. Let's reset step after timeout.
                  setTimeout(() => {
                      setStep('enter');
                      setConfirmInput('');
                  }, 2000);
              }
          }
      }
  };

  // --- PIN Logic ---
  const handlePinPress = (num: string) => {
      if (error) return; // Prevent input while error is showing
      if (input.length < 6) {
          const newVal = input + num;
          setInput(newVal);
      }
  };

  const handlePinDelete = () => {
      if (error) return;
      setInput(prev => prev.slice(0, -1));
  };

  const handlePinSubmit = () => {
      if (input.length > 0) handleVerify(input);
  };

  // --- Pattern Logic ---
  const getPointFromEvent = (e: React.TouchEvent | React.MouseEvent) => {
      if (!svgRef.current) return null;
      const rect = svgRef.current.getBoundingClientRect();
      const clientX = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : (e as React.MouseEvent).clientY;
      return { x: clientX - rect.left, y: clientY - rect.top };
  };

  const getNodeIndex = (x: number, y: number) => {
     // Grid is 3x3. Assume 300x300 area.
     // Nodes at approx 50, 150, 250
     const col = Math.floor(x / 100);
     const row = Math.floor(y / 100);
     if (col >= 0 && col < 3 && row >= 0 && row < 3) {
         // Check distance to center
         const cx = col * 100 + 50;
         const cy = row * 100 + 50;
         const dist = Math.sqrt((x-cx)**2 + (y-cy)**2);
         if (dist < 40) return row * 3 + col;
     }
     return -1;
  };

  const handlePatternStart = (e: React.TouchEvent | React.MouseEvent) => {
      if (error) return;
      const p = getPointFromEvent(e);
      if (p) {
          const idx = getNodeIndex(p.x, p.y);
          if (idx !== -1) setPatternPath([idx]);
      }
  };

  const handlePatternMove = (e: React.TouchEvent | React.MouseEvent) => {
      if (error) return;
      if (patternPath.length === 0) return;
      const p = getPointFromEvent(e);
      if (p) {
          const idx = getNodeIndex(p.x, p.y);
          if (idx !== -1 && !patternPath.includes(idx)) {
              setPatternPath([...patternPath, idx]);
          }
      }
  };

  const handlePatternEnd = () => {
      if (error) return;
      if (patternPath.length > 0) {
          const val = patternPath.join('-');
          handleVerify(val);
      }
  };

  // Renderers
  if (!isOpen) return null;

  // Determine display text
  const displayTitle = title || (mode === 'unlock' ? 'Nexo Finance' : (step === 'enter' ? 'Configurar Seguridad' : 'Confirma tu código'));
  const displayDesc = description || (mode === 'unlock' ? 'Ingresa tu clave para continuar' : (step === 'enter' ? `Ingresa tu ${method === 'PATTERN' ? 'patrón' : 'clave'} nueva` : 'Repite para confirmar'));

  return (
    <div className="fixed inset-0 bg-black z-[100] flex flex-col items-center justify-center p-6 select-none">
        {onClose && (
            <button onClick={onClose} className="absolute top-6 right-6 p-2 rounded-full bg-white/10 text-neutral-400 z-20">
                <X size={24} />
            </button>
        )}

        <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className={`w-full max-w-sm flex flex-col items-center ${error ? 'animate-shake' : ''}`}
        >
            <div className={`w-16 h-16 rounded-3xl flex items-center justify-center mb-6 transition-colors ${error ? 'bg-red-500/20 text-red-500' : 'bg-primary/20 text-primary'}`}>
                {error ? <ShieldAlert size={32} /> : <Lock size={32} />}
            </div>

            <h2 className="text-2xl font-bold text-white mb-2 text-center">
                {displayTitle}
            </h2>
            <p className="text-neutral-500 mb-8 text-sm text-center px-4">
                {displayDesc}
            </p>

            {/* ERROR MESSAGE (Floating) */}
            <AnimatePresence>
                {error && (
                    <motion.div 
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="absolute top-24 flex items-center gap-2 text-red-200 bg-red-500/20 border border-red-500/20 px-4 py-2 rounded-full text-sm font-bold backdrop-blur-md"
                    >
                        <span>Incorrecto. Intenta de nuevo.</span>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* INPUT METHODS */}
            {method === 'PIN' && (
                <div className="w-full">
                    {/* Visual Dots */}
                    <div className="flex gap-6 justify-center mb-10 h-4">
                        {[0, 1, 2, 3].map((_, i) => (
                             <motion.div 
                                  key={i}
                                  animate={{ 
                                      scale: i < input.length ? 1.2 : 1,
                                      backgroundColor: i < input.length ? (error ? '#ef4444' : '#6d28d9') : '#262626'
                                  }}
                                  className="w-4 h-4 rounded-full transition-colors"
                             />
                        ))}
                    </div>

                    <div className="grid grid-cols-3 gap-4 max-w-[280px] mx-auto">
                        {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                            <button
                                key={num}
                                onClick={() => handlePinPress(num.toString())}
                                className="w-20 h-20 rounded-full bg-surface hover:bg-surfaceHighlight text-2xl font-bold text-white transition-all active:scale-95 border border-white/5 outline-none touch-manipulation"
                            >
                                {num}
                            </button>
                        ))}
                        <div />
                        <button
                            onClick={() => handlePinPress('0')}
                            className="w-20 h-20 rounded-full bg-surface hover:bg-surfaceHighlight text-2xl font-bold text-white transition-all active:scale-95 border border-white/5 outline-none touch-manipulation"
                        >
                            0
                        </button>
                        <button
                            onClick={handlePinDelete}
                            className="w-20 h-20 rounded-full bg-transparent hover:bg-white/5 text-neutral-400 transition-all active:scale-95 flex items-center justify-center outline-none"
                        >
                            <Delete size={24} />
                        </button>
                    </div>
                    {input.length >= 4 && (
                        <button onClick={handlePinSubmit} className="mt-8 w-full max-w-[280px] mx-auto py-4 bg-primary rounded-2xl text-white font-bold flex items-center justify-center gap-2">
                            <Check size={20} /> Confirmar
                        </button>
                    )}
                </div>
            )}

            {method === 'PASSWORD' && (
                <div className="w-full">
                    <input
                        type="password"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        placeholder="Escribe aquí..."
                        className="w-full bg-surface border border-white/10 rounded-xl p-4 text-white text-center text-xl tracking-widest outline-none focus:border-primary/50 mb-6"
                        autoFocus
                    />
                    <button 
                        onClick={() => handleVerify(input)}
                        disabled={input.length === 0}
                        className="w-full py-4 bg-primary rounded-2xl text-white font-bold flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                        {mode === 'setup' && step === 'enter' ? <ArrowRight size={20}/> : <Check size={20}/>} 
                        {mode === 'setup' && step === 'enter' ? 'Siguiente' : 'Confirmar'}
                    </button>
                </div>
            )}

            {method === 'PATTERN' && (
                <div className="relative w-[300px] h-[300px] select-none touch-none">
                    <svg ref={svgRef} className="absolute inset-0 w-full h-full z-10 pointer-events-none">
                        {patternPath.length > 1 && (
                            <polyline 
                                points={patternPath.map(idx => {
                                    const col = idx % 3;
                                    const row = Math.floor(idx / 3);
                                    return `${col * 100 + 50},${row * 100 + 50}`;
                                }).join(' ')}
                                fill="none"
                                stroke={error ? "#ef4444" : "#6d28d9"}
                                strokeWidth="4"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                            />
                        )}
                    </svg>
                    
                    <div 
                        className="w-full h-full grid grid-cols-3 relative z-20"
                        onMouseDown={handlePatternStart}
                        onMouseMove={handlePatternMove}
                        onMouseUp={handlePatternEnd}
                        onTouchStart={handlePatternStart}
                        onTouchMove={handlePatternMove}
                        onTouchEnd={handlePatternEnd}
                    >
                        {[0, 1, 2, 3, 4, 5, 6, 7, 8].map(idx => {
                            const isActive = patternPath.includes(idx);
                            return (
                                <div key={idx} className="flex items-center justify-center">
                                    <div className={`w-4 h-4 rounded-full transition-all duration-300 ${isActive ? (error ? 'bg-red-500 scale-150 ring-4 ring-red-500/20' : 'bg-primary scale-150 ring-4 ring-primary/20') : 'bg-neutral-700'}`} />
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}
        </motion.div>
    </div>
  );
};
