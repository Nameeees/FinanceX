
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronLeft, ChevronRight, Calendar as CalendarIcon, Check } from 'lucide-react';

interface CalendarModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (date: string) => void;
  title?: string;
  initialDate?: string;
}

const DAYS_OF_WEEK = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
const MONTH_NAMES = [
  'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
  'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
];

export const CalendarModal: React.FC<CalendarModalProps> = ({ 
  isOpen, 
  onClose, 
  onSelect, 
  title = "Seleccionar Fecha",
  initialDate 
}) => {
  // Parse initial date or default to today (Local time)
  const getInitialDateObj = () => {
      if (initialDate) {
          const [y, m, d] = initialDate.split('-').map(Number);
          return new Date(y, m - 1, d);
      }
      return new Date();
  };

  const [viewDate, setViewDate] = useState(getInitialDateObj());
  const [selectedDate, setSelectedDate] = useState<string>(initialDate || '');
  const [direction, setDirection] = useState(0);

  // Reset view when opening
  React.useEffect(() => {
    if (isOpen) {
        setViewDate(getInitialDateObj());
        setSelectedDate(initialDate || '');
    }
  }, [isOpen, initialDate]);

  const year = viewDate.getFullYear();
  const month = viewDate.getMonth();

  const getDaysInMonth = (y: number, m: number) => new Date(y, m + 1, 0).getDate();
  const getFirstDayOfMonth = (y: number, m: number) => new Date(y, m, 1).getDay();

  const daysInMonth = getDaysInMonth(year, month);
  const firstDay = getFirstDayOfMonth(year, month);

  const daysArray = [];
  for (let i = 0; i < firstDay; i++) daysArray.push(null);
  for (let i = 1; i <= daysInMonth; i++) daysArray.push(i);

  const changeMonth = (dir: number) => {
    setDirection(dir);
    const newDate = new Date(year, month + dir, 1);
    setViewDate(newDate);
  };

  const handleDayClick = (day: number) => {
    const m = (month + 1).toString().padStart(2, '0');
    const d = day.toString().padStart(2, '0');
    const dateStr = `${year}-${m}-${d}`;
    setSelectedDate(dateStr);
    
    // Slight delay to show selection animation before closing
    setTimeout(() => {
        onSelect(dateStr);
        onClose();
    }, 150);
  };

  const variants = {
    enter: (dir: number) => ({ x: dir > 0 ? 50 : -50, opacity: 0 }),
    center: { x: 0, opacity: 1 },
    exit: (dir: number) => ({ x: dir > 0 ? -50 : 50, opacity: 0 }),
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[80]"
          />

          {/* Modal */}
          <motion.div
            initial={{ y: '100%', opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: '100%', opacity: 0 }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed bottom-0 left-0 right-0 z-[90] bg-[#0f0f0f] rounded-t-[2.5rem] border-t border-white/10 overflow-hidden shadow-2xl p-6 pb-12"
          >
            {/* Header */}
            <div className="flex justify-between items-center mb-6">
                <div>
                    <h3 className="text-white font-medium text-lg tracking-tight flex items-center gap-2">
                        <CalendarIcon size={20} className="text-primary" />
                        {title}
                    </h3>
                </div>
                <button onClick={onClose} className="p-2 rounded-full bg-surface text-neutral-400 hover:text-white transition-colors">
                    <X size={20} />
                </button>
            </div>

            {/* Calendar Controls */}
            <div className="bg-surface/50 border border-white/5 rounded-[2rem] p-4">
                <div className="flex items-center justify-between mb-6 px-2">
                    <button 
                        onClick={() => changeMonth(-1)}
                        className="p-2 rounded-full hover:bg-white/5 text-neutral-400 hover:text-white transition-colors active:scale-90"
                    >
                        <ChevronLeft size={24} />
                    </button>
                    <motion.div 
                        key={`${month}-${year}`}
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="text-center"
                    >
                        <h2 className="text-lg font-bold text-white tracking-wide capitalize">
                            {MONTH_NAMES[month]}
                        </h2>
                        <span className="text-neutral-500 text-xs font-mono">{year}</span>
                    </motion.div>
                    <button 
                        onClick={() => changeMonth(1)}
                        className="p-2 rounded-full hover:bg-white/5 text-neutral-400 hover:text-white transition-colors active:scale-90"
                    >
                        <ChevronRight size={24} />
                    </button>
                </div>

                {/* Days Header */}
                <div className="grid grid-cols-7 mb-4">
                    {DAYS_OF_WEEK.map(day => (
                        <div key={day} className="text-center text-[10px] uppercase font-bold text-neutral-600 tracking-wider">
                            {day}
                        </div>
                    ))}
                </div>

                {/* Grid */}
                <AnimatePresence mode="popLayout" custom={direction} initial={false}>
                    <motion.div 
                        key={`${month}-${year}`}
                        custom={direction}
                        variants={variants}
                        initial="enter"
                        animate="center"
                        exit="exit"
                        transition={{ type: "spring", stiffness: 300, damping: 30 }}
                        className="grid grid-cols-7 gap-y-4 gap-x-2"
                    >
                        {daysArray.map((day, index) => {
                            if (day === null) return <div key={`empty-${index}`} />;
                            
                            const mStr = (month + 1).toString().padStart(2, '0');
                            const dStr = day.toString().padStart(2, '0');
                            const currentLoopDate = `${year}-${mStr}-${dStr}`;
                            const isSelected = selectedDate === currentLoopDate;
                            const isToday = new Date().toISOString().split('T')[0] === currentLoopDate;

                            return (
                                <button
                                    key={day}
                                    onClick={() => handleDayClick(day)}
                                    className={`relative flex items-center justify-center w-full aspect-square rounded-xl transition-all duration-300 ${
                                        isSelected 
                                        ? 'bg-primary text-white shadow-[0_0_15px_rgba(109,40,217,0.5)] scale-110 z-10' 
                                        : 'text-neutral-300 hover:bg-white/5 active:scale-95'
                                    } ${isToday && !isSelected ? 'border border-primary/50 text-primary' : ''}`}
                                >
                                    <span className="text-sm font-medium relative z-10">{day}</span>
                                    {isSelected && (
                                        <motion.div 
                                            layoutId="selectedDay"
                                            className="absolute inset-0 bg-primary rounded-xl -z-0"
                                            transition={{ type: "spring" }}
                                        />
                                    )}
                                </button>
                            );
                        })}
                    </motion.div>
                </AnimatePresence>
            </div>

            {/* Clear/Today shortcuts */}
            <div className="flex justify-center mt-6 gap-4">
                <button 
                    onClick={() => {
                        const today = new Date();
                        const str = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
                        onSelect(str);
                        onClose();
                    }}
                    className="text-xs font-bold text-primary uppercase tracking-wider py-2 px-4 rounded-full hover:bg-primary/10 transition-colors"
                >
                    Hoy
                </button>
            </div>

          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
