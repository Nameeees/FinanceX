
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Check, Search } from 'lucide-react';

interface CurrencyConverterModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedCurrency: string;
  onSelect: (code: string) => void;
  currencies: Array<{ code: string; name: string; symbol: string; flag: string; rate: number }>;
}

export const CurrencyConverterModal: React.FC<CurrencyConverterModalProps> = ({ 
  isOpen, 
  onClose, 
  selectedCurrency, 
  onSelect,
  currencies
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  // Reset search when opening
  useEffect(() => {
      if (isOpen) setSearchTerm('');
  }, [isOpen]);

  const filteredCurrencies = currencies.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }}
              onClick={onClose}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[80]"
          />
          <motion.div 
              initial={{ y: '100%' }} 
              animate={{ y: 0 }} 
              exit={{ y: '100%' }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed bottom-0 left-0 right-0 bg-[#121212] rounded-t-[2rem] p-6 z-[90] border-t border-white/10 max-h-[85vh] flex flex-col"
          >
              <div className="flex justify-between items-center mb-6 shrink-0">
                  <h3 className="text-white font-bold text-lg">Convertir Moneda</h3>
                  <button onClick={onClose} className="p-2 bg-white/5 rounded-full text-neutral-400 hover:text-white"><X size={20}/></button>
              </div>

              <div className="mb-4 shrink-0">
                  <div className="relative">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-500" size={18} />
                        <input 
                            type="text"
                            placeholder="Buscar divisa..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full bg-surface border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white outline-none focus:border-primary/50 transition-colors placeholder:text-neutral-600 text-sm"
                            autoFocus
                        />
                  </div>
              </div>
              
              <div className="grid grid-cols-1 gap-2 overflow-y-auto no-scrollbar pb-8 flex-1">
                  {filteredCurrencies.length > 0 ? (
                      filteredCurrencies.map(curr => (
                          <button
                              key={curr.code}
                              onClick={() => {
                                  onSelect(curr.code);
                                  onClose();
                              }}
                              className={`flex items-center justify-between p-4 rounded-xl border transition-all ${
                                  selectedCurrency === curr.code 
                                  ? 'bg-surfaceHighlight border-primary/50' 
                                  : 'bg-surface border-white/5 hover:bg-white/5'
                              }`}
                          >
                              <div className="flex items-center gap-3">
                                  <span className="text-3xl">{curr.flag}</span>
                                  <div className="text-left">
                                      <div className="text-white font-bold text-sm">{curr.code}</div>
                                      <div className="text-neutral-500 text-xs">{curr.name}</div>
                                  </div>
                              </div>
                              {selectedCurrency === curr.code && (
                                  <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center shadow-lg">
                                      <Check size={14} className="text-white"/>
                                  </div>
                              )}
                          </button>
                      ))
                  ) : (
                      <div className="text-center py-8 text-neutral-600 text-sm">
                          No se encontraron divisas.
                      </div>
                  )}
              </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
