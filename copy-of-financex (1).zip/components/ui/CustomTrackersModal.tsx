
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
    X, Trash2, BoxSelect, Cpu, ArrowLeft, Save, 
    Play, Activity, Calculator, Split, Hash, Type,
    Zap, MousePointer2, Smartphone, Edit2, Percent, 
    Shuffle, CalendarClock, Clock, MessageSquare, CheckCheck, MoveHorizontal
} from 'lucide-react';
import { CustomTracker, Transaction, TrackerType, ResetFrequency, WidgetLayout, Blueprint, BlueprintNode, BlueprintConnection, BlueprintPort } from '../../types';

interface CustomTrackersModalProps {
  isOpen: boolean;
  onClose: () => void;
  trackers: CustomTracker[];
  transactions: Transaction[]; 
  onAddTracker: (name: string, type: TrackerType, config: any, icon: string, color: string, target: number, unit: string, resetSchedule: ResetFrequency, layout: WidgetLayout, blueprint?: Blueprint) => void;
  onUpdateTracker: (id: string, updates: Partial<CustomTracker>) => void;
  onDeleteTracker: (id: string) => void;
  onAddLog: (id: string, value: number, note?: string) => void;
  onReset: (id: string) => void;
}

// --- NODE DEFINITIONS ---
const NODE_TYPES: Record<string, { title: string, category: string, inputs: BlueprintPort[], outputs: BlueprintPort[], color: string, icon: any }> = {
    // DISPARADORES
    'EVENT_TAP': { 
        title: 'Al Tocar', category: 'Eventos',
        inputs: [], 
        outputs: [{id: 'exec', name: '▶ Ejecutar', type: 'EXEC'}], 
        color: 'border-red-500', icon: MousePointer2
    },
    
    // ACCIONES
    'ACTION_LOG': { 
        title: 'Guardar Registro', category: 'Acciones',
        inputs: [{id: 'exec', name: '▶ Activar', type: 'EXEC'}, {id: 'val', name: 'Valor', type: 'NUMBER'}], 
        outputs: [{id: 'out', name: '▶ Fin', type: 'EXEC'}], 
        color: 'border-purple-500', icon: Save
    },
    'ACTION_VIBRATE': { 
        title: 'Vibrar', category: 'Acciones',
        inputs: [{id: 'exec', name: '▶ Activar', type: 'EXEC'}], 
        outputs: [{id: 'out', name: '▶ Fin', type: 'EXEC'}], 
        color: 'border-purple-500', icon: Smartphone
    },
    'ACTION_ALERT': { 
        title: 'Mostrar Alerta', category: 'Acciones',
        inputs: [{id: 'exec', name: '▶ Activar', type: 'EXEC'}, {id: 'msg', name: 'Mensaje (Num)', type: 'NUMBER'}], 
        outputs: [{id: 'out', name: '▶ Fin', type: 'EXEC'}], 
        color: 'border-purple-500', icon: MessageSquare
    },

    // DATOS
    'VAL_NUMBER': { 
        title: 'Número Fijo', category: 'Datos',
        inputs: [], 
        outputs: [{id: 'val', name: '#', type: 'NUMBER'}], 
        color: 'border-green-500', icon: Hash
    },
    'VAL_CURRENT': { 
        title: 'Valor Actual', category: 'Datos',
        inputs: [], 
        outputs: [{id: 'val', name: '#', type: 'NUMBER'}], 
        color: 'border-green-500', icon: Activity
    },
    'VAL_RANDOM': { 
        title: 'Aleatorio', category: 'Datos',
        inputs: [{id: 'min', name: 'Min', type: 'NUMBER'}, {id: 'max', name: 'Max', type: 'NUMBER'}], 
        outputs: [{id: 'val', name: '#', type: 'NUMBER'}], 
        color: 'border-green-500', icon: Shuffle
    },
    'VAL_WEEKDAY': { 
        title: 'Día Semana (0-6)', category: 'Datos',
        inputs: [], 
        outputs: [{id: 'val', name: '#', type: 'NUMBER'}], 
        color: 'border-green-500', icon: CalendarClock
    },
    'VAL_HOUR': { 
        title: 'Hora Actual (0-23)', category: 'Datos',
        inputs: [], 
        outputs: [{id: 'val', name: '#', type: 'NUMBER'}], 
        color: 'border-green-500', icon: Clock
    },

    // MATEMÁTICAS
    'LOGIC_ADD': { 
        title: 'Sumar (+)', category: 'Matemáticas',
        inputs: [{id: 'a', name: 'A', type: 'NUMBER'}, {id: 'b', name: 'B', type: 'NUMBER'}], 
        outputs: [{id: 'res', name: '=', type: 'NUMBER'}], 
        color: 'border-blue-500', icon: Calculator
    },
    'LOGIC_SUB': { 
        title: 'Restar (-)', category: 'Matemáticas',
        inputs: [{id: 'a', name: 'A', type: 'NUMBER'}, {id: 'b', name: 'B', type: 'NUMBER'}], 
        outputs: [{id: 'res', name: '=', type: 'NUMBER'}], 
        color: 'border-blue-500', icon: Calculator
    },
    'LOGIC_MUL': { 
        title: 'Multiplicar (*)', category: 'Matemáticas',
        inputs: [{id: 'a', name: 'A', type: 'NUMBER'}, {id: 'b', name: 'B', type: 'NUMBER'}], 
        outputs: [{id: 'res', name: '=', type: 'NUMBER'}], 
        color: 'border-blue-500', icon: X
    },
    'LOGIC_DIV': { 
        title: 'Dividir (/)', category: 'Matemáticas',
        inputs: [{id: 'a', name: 'A', type: 'NUMBER'}, {id: 'b', name: 'B', type: 'NUMBER'}], 
        outputs: [{id: 'res', name: '=', type: 'NUMBER'}], 
        color: 'border-blue-500', icon: Percent
    },

    // LÓGICA Y CONTROL
    'LOGIC_GREATER': { 
        title: 'Mayor Que (>)', category: 'Lógica',
        inputs: [{id: 'a', name: 'A', type: 'NUMBER'}, {id: 'b', name: 'B', type: 'NUMBER'}], 
        outputs: [{id: 'res', name: '?', type: 'BOOLEAN'}], 
        color: 'border-orange-500', icon: Split
    },
    'LOGIC_LESS': { 
        title: 'Menor Que (<)', category: 'Lógica',
        inputs: [{id: 'a', name: 'A', type: 'NUMBER'}, {id: 'b', name: 'B', type: 'NUMBER'}], 
        outputs: [{id: 'res', name: '?', type: 'BOOLEAN'}], 
        color: 'border-orange-500', icon: Split
    },
    'LOGIC_EQUAL': { 
        title: 'Igual A (==)', category: 'Lógica',
        inputs: [{id: 'a', name: 'A', type: 'NUMBER'}, {id: 'b', name: 'B', type: 'NUMBER'}], 
        outputs: [{id: 'res', name: '?', type: 'BOOLEAN'}], 
        color: 'border-orange-500', icon: MoveHorizontal
    },
    'LOGIC_AND': { 
        title: 'Y (AND)', category: 'Lógica',
        inputs: [{id: 'a', name: 'A', type: 'BOOLEAN'}, {id: 'b', name: 'B', type: 'BOOLEAN'}], 
        outputs: [{id: 'res', name: '?', type: 'BOOLEAN'}], 
        color: 'border-orange-500', icon: CheckCheck
    },
    'LOGIC_OR': { 
        title: 'O (OR)', category: 'Lógica',
        inputs: [{id: 'a', name: 'A', type: 'BOOLEAN'}, {id: 'b', name: 'B', type: 'BOOLEAN'}], 
        outputs: [{id: 'res', name: '?', type: 'BOOLEAN'}], 
        color: 'border-orange-500', icon: Split
    },
    'LOGIC_IF': { 
        title: 'Condición SI', category: 'Control',
        inputs: [{id: 'exec', name: '▶', type: 'EXEC'}, {id: 'cond', name: '¿Verdad?', type: 'BOOLEAN'}], 
        outputs: [{id: 'true', name: '▶ Verdadero', type: 'EXEC'}, {id: 'false', name: '▶ Falso', type: 'EXEC'}], 
        color: 'border-yellow-500', icon: Split
    },
};

const GRADIENTS = [
    { id: 'emerald', class: 'from-emerald-500 to-teal-500' },
    { id: 'blue', class: 'from-blue-600 to-indigo-600' },
    { id: 'purple', class: 'from-purple-600 to-fuchsia-600' },
    { id: 'orange', class: 'from-orange-500 to-red-500' },
    { id: 'pink', class: 'from-pink-500 to-rose-500' },
];

export const CustomTrackersModal: React.FC<CustomTrackersModalProps> = ({ 
    isOpen, onClose, trackers, onAddTracker, onUpdateTracker, onDeleteTracker, onAddLog 
}) => {
    const [mode, setMode] = useState<'LIST' | 'BLUEPRINT'>('LIST');
    
    // --- BLUEPRINT STATE ---
    const [editingId, setEditingId] = useState<string | null>(null);
    const [nodes, setNodes] = useState<BlueprintNode[]>([]);
    const [connections, setConnections] = useState<BlueprintConnection[]>([]);
    const [viewport, setViewport] = useState({ x: 0, y: 0, zoom: 1 });
    const [trackerName, setTrackerName] = useState('Nuevo Widget');
    const [trackerColor, setTrackerColor] = useState(GRADIENTS[1].class);
    
    // Interaction Refs
    const dragRef = useRef({
        isPanning: false,
        draggingNodeId: null as string | null,
        lastX: 0,
        lastY: 0
    });

    const [connecting, setConnecting] = useState<{ nodeId: string, portId: string, x: number, y: number } | null>(null);
    const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
    const canvasRef = useRef<HTMLDivElement>(null);

    // Initial Setup
    useEffect(() => {
        if (mode === 'BLUEPRINT') {
            if (editingId) {
                // LOAD EXISTING TRACKER
                const existing = trackers.find(t => t.id === editingId);
                if (existing && existing.blueprint) {
                    setNodes(existing.blueprint.nodes);
                    setConnections(existing.blueprint.connections);
                    setViewport(existing.blueprint.viewport);
                    setTrackerName(existing.name);
                    setTrackerColor(existing.color);
                } else if (existing) {
                    // Fallback if no blueprint
                    setNodes([]);
                    setConnections([]);
                    setTrackerName(existing.name);
                }
            } else {
                // RESET FOR NEW TRACKER
                setNodes([
                    { id: 'n1', type: 'EVENT_TAP', title: 'Al Tocar', position: { x: 50, y: 100 }, data: {}, inputs: [], outputs: NODE_TYPES['EVENT_TAP'].outputs },
                    { id: 'n2', type: 'ACTION_LOG', title: 'Guardar Registro', position: { x: 400, y: 100 }, data: {}, inputs: NODE_TYPES['ACTION_LOG'].inputs, outputs: NODE_TYPES['ACTION_LOG'].outputs },
                    { id: 'n3', type: 'VAL_NUMBER', title: 'Número (+1)', position: { x: 200, y: 300 }, data: { value: 1 }, inputs: [], outputs: NODE_TYPES['VAL_NUMBER'].outputs }
                ]);
                setConnections([
                    { id: 'c1', sourceNodeId: 'n1', sourcePortId: 'exec', targetNodeId: 'n2', targetPortId: 'exec' },
                    { id: 'c2', sourceNodeId: 'n3', sourcePortId: 'val', targetNodeId: 'n2', targetPortId: 'val' }
                ]);
                setViewport({ x: 0, y: 0, zoom: 1 });
                setTrackerName('Nuevo Widget');
                setTrackerColor(GRADIENTS[1].class);
            }
        }
    }, [mode, editingId]);

    // --- BLUEPRINT ENGINE (THE BRAIN) ---
    const executeBlueprint = (tracker: CustomTracker) => {
        if (!tracker.blueprint) {
            onAddLog(tracker.id, 1); // Fallback for simple trackers
            return;
        }

        const { nodes: bpNodes, connections: bpConns } = tracker.blueprint;

        // Recursive function to get data from input ports
        const getValue = (targetNodeId: string, targetPortId: string): any => {
            const conn = bpConns.find(c => c.targetNodeId === targetNodeId && c.targetPortId === targetPortId);
            if (!conn) return 0; // Default value if unconnected

            const sourceNode = bpNodes.find(n => n.id === conn.sourceNodeId);
            if (!sourceNode) return 0;

            // Resolve based on source type
            switch (sourceNode.type) {
                // DATA
                case 'VAL_NUMBER': return parseFloat(sourceNode.data.value) || 0;
                case 'VAL_CURRENT': return tracker.currentValue;
                case 'VAL_RANDOM': {
                     const min = getValue(sourceNode.id, 'min');
                     const max = getValue(sourceNode.id, 'max');
                     return Math.floor(Math.random() * (max - min + 1)) + min;
                }
                case 'VAL_WEEKDAY': return new Date().getDay();
                case 'VAL_HOUR': return new Date().getHours();
                
                // MATH
                case 'LOGIC_ADD': return getValue(sourceNode.id, 'a') + getValue(sourceNode.id, 'b');
                case 'LOGIC_SUB': return getValue(sourceNode.id, 'a') - getValue(sourceNode.id, 'b');
                case 'LOGIC_MUL': return getValue(sourceNode.id, 'a') * getValue(sourceNode.id, 'b');
                case 'LOGIC_DIV': {
                    const b = getValue(sourceNode.id, 'b');
                    return b === 0 ? 0 : getValue(sourceNode.id, 'a') / b;
                }

                // LOGIC
                case 'LOGIC_GREATER': return getValue(sourceNode.id, 'a') > getValue(sourceNode.id, 'b');
                case 'LOGIC_LESS': return getValue(sourceNode.id, 'a') < getValue(sourceNode.id, 'b');
                case 'LOGIC_EQUAL': return getValue(sourceNode.id, 'a') === getValue(sourceNode.id, 'b');
                case 'LOGIC_AND': return getValue(sourceNode.id, 'a') && getValue(sourceNode.id, 'b');
                case 'LOGIC_OR': return getValue(sourceNode.id, 'a') || getValue(sourceNode.id, 'b');

                default: return 0;
            }
        };

        // Execution Flow
        const runFlow = (nodeId: string) => {
            const node = bpNodes.find(n => n.id === nodeId);
            if (!node) return;

            if (node.type === 'ACTION_LOG') {
                const value = getValue(node.id, 'val');
                onAddLog(tracker.id, value);
                followFlow(node.id, 'out');
            } 
            else if (node.type === 'ACTION_VIBRATE') {
                if (navigator.vibrate) navigator.vibrate(50);
                followFlow(node.id, 'out');
            }
            else if (node.type === 'ACTION_ALERT') {
                const msg = getValue(node.id, 'msg');
                alert(`Mensaje del Widget: ${msg}`);
                followFlow(node.id, 'out');
            }
            else if (node.type === 'LOGIC_IF') {
                const condition = getValue(node.id, 'cond');
                if (condition) {
                    followFlow(node.id, 'true');
                } else {
                    followFlow(node.id, 'false');
                }
            }
        };

        const followFlow = (sourceNodeId: string, sourcePortId: string) => {
            const outgoing = bpConns.filter(c => c.sourceNodeId === sourceNodeId && c.sourcePortId === sourcePortId);
            outgoing.forEach(conn => runFlow(conn.targetNodeId));
        };

        // Start Execution at EVENT_TAP
        const startNode = bpNodes.find(n => n.type === 'EVENT_TAP');
        if (startNode) {
            followFlow(startNode.id, 'exec');
        }
    };

    // --- INTERACTION HANDLERS ---
    const getPointerPos = (e: any) => {
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        return { x: clientX, y: clientY };
    };

    const handleStart = (e: any, nodeId?: string) => {
        const pos = getPointerPos(e);
        dragRef.current.lastX = pos.x;
        dragRef.current.lastY = pos.y;
        
        if (nodeId) {
            e.stopPropagation();
            dragRef.current.draggingNodeId = nodeId;
            dragRef.current.isPanning = false;
        } else {
            dragRef.current.isPanning = true;
            dragRef.current.draggingNodeId = null;
        }
    };

    const handleMove = (e: any) => {
        const pos = getPointerPos(e);
        const dx = pos.x - dragRef.current.lastX;
        const dy = pos.y - dragRef.current.lastY;

        if (canvasRef.current) {
            const rect = canvasRef.current.getBoundingClientRect();
            setMousePos({ 
                x: (pos.x - rect.left - viewport.x) / viewport.zoom, 
                y: (pos.y - rect.top - viewport.y) / viewport.zoom 
            });
        }

        if (dragRef.current.isPanning) {
            setViewport(prev => ({ ...prev, x: prev.x + dx, y: prev.y + dy }));
        } else if (dragRef.current.draggingNodeId) {
            setNodes(prev => prev.map(n => 
                n.id === dragRef.current.draggingNodeId 
                ? { ...n, position: { x: n.position.x + dx / viewport.zoom, y: n.position.y + dy / viewport.zoom } } 
                : n
            ));
        }

        dragRef.current.lastX = pos.x;
        dragRef.current.lastY = pos.y;
    };

    const handleEnd = (e: any) => {
        if (connecting) {
            const clientX = e.changedTouches ? e.changedTouches[0].clientX : e.clientX;
            const clientY = e.changedTouches ? e.changedTouches[0].clientY : e.clientY;

            const elem = document.elementFromPoint(clientX, clientY);
            const portElem = elem?.closest('[data-port-id]');

            if (portElem) {
                const targetNodeId = portElem.getAttribute('data-node-id');
                const targetPortId = portElem.getAttribute('data-port-id');
                const isInput = portElem.getAttribute('data-is-input') === 'true';

                if (isInput && targetNodeId && targetPortId && targetNodeId !== connecting.nodeId) {
                     const exists = connections.some(c => 
                        c.targetNodeId === targetNodeId && c.targetPortId === targetPortId && 
                        c.sourceNodeId === connecting.nodeId && c.sourcePortId === connecting.portId
                     );

                     const targetNode = nodes.find(n => n.id === targetNodeId);
                     const targetPort = targetNode?.inputs.find(p => p.id === targetPortId);
                     const isSingleValue = targetPort?.type !== 'EXEC';

                     let newConns = [...connections];
                     if (isSingleValue) {
                         newConns = newConns.filter(c => !(c.targetNodeId === targetNodeId && c.targetPortId === targetPortId));
                     }

                     if (!exists) {
                        newConns.push({
                            id: Math.random().toString(36).substr(2, 9),
                            sourceNodeId: connecting.nodeId,
                            sourcePortId: connecting.portId,
                            targetNodeId: targetNodeId,
                            targetPortId: targetPortId
                        });
                        setConnections(newConns);
                     }
                }
            }
            setConnecting(null);
        }

        dragRef.current.isPanning = false;
        dragRef.current.draggingNodeId = null;
    };

    const handlePortStart = (nodeId: string, portId: string, isInput: boolean, e: any) => {
        e.stopPropagation();
        if (!isInput) {
            const targetEl = e.currentTarget as HTMLElement;
            const rect = targetEl.getBoundingClientRect();
            const canvasRect = canvasRef.current?.getBoundingClientRect();

            if (canvasRect) {
                setConnecting({
                    nodeId,
                    portId,
                    x: (rect.left + rect.width/2 - canvasRect.left - viewport.x) / viewport.zoom,
                    y: (rect.top + rect.height/2 - canvasRect.top - viewport.y) / viewport.zoom
                });
            }
        }
    };

    const addNode = (type: string) => {
        const def = NODE_TYPES[type];
        const newNode: BlueprintNode = {
            id: Math.random().toString(36).substr(2, 9),
            type,
            title: def.title,
            position: { x: -viewport.x/viewport.zoom + 100, y: -viewport.y/viewport.zoom + 150 },
            data: type === 'VAL_NUMBER' ? { value: 1 } : {},
            inputs: def.inputs,
            outputs: def.outputs
        };
        setNodes(prev => [...prev, newNode]);
    };

    const handleSaveTracker = () => {
        if (!trackerName) return;
        const blueprint = { nodes, connections, viewport };
        
        if (editingId) {
            onUpdateTracker(editingId, { 
                name: trackerName, 
                color: trackerColor,
                blueprint: blueprint
            });
        } else {
            onAddTracker(trackerName, 'BLUEPRINT', {}, 'Cpu', trackerColor, 0, '', 'NEVER', 'SQUARE', blueprint);
        }
        
        setMode('LIST');
        setEditingId(null);
    };

    const handleEditTracker = (id: string, e: React.MouseEvent) => {
        e.stopPropagation();
        setEditingId(id);
        setMode('BLUEPRINT');
    };

    return (
        <AnimatePresence>
            {isOpen && (
                <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="fixed inset-0 z-[100] bg-[#0a0a0a] flex flex-col overflow-hidden"
                >
                    {mode === 'LIST' ? (
                        <>
                             <div className="p-6 border-b border-white/10 flex justify-between items-center bg-[#121212]">
                                <div>
                                    <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                                        <BoxSelect className="text-primary"/> Widget Studio
                                    </h2>
                                    <p className="text-neutral-500 text-xs mt-1">Automatiza tu vida financiera</p>
                                </div>
                                <button onClick={onClose} className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white">
                                    <X size={24} />
                                </button>
                            </div>

                            <div className="flex-1 overflow-y-auto p-6 bg-[#0a0a0a] no-scrollbar">
                                <div className="grid grid-cols-2 gap-4 pb-12">
                                    <motion.button 
                                        onClick={() => { setEditingId(null); setMode('BLUEPRINT'); }}
                                        whileHover={{ scale: 1.02 }}
                                        whileTap={{ scale: 0.98 }}
                                        className="col-span-2 h-[120px] rounded-[2rem] border-2 border-dashed border-white/10 hover:border-primary/50 hover:bg-white/5 flex flex-col items-center justify-center gap-2 transition-all group"
                                    >
                                        <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center group-hover:scale-110 transition-transform">
                                            <Cpu size={24} strokeWidth={2} />
                                        </div>
                                        <div className="text-center">
                                            <span className="block text-base font-bold text-neutral-300 group-hover:text-white">Crear Nuevo Widget</span>
                                            <span className="text-xs text-neutral-500">Editor visual de lógica</span>
                                        </div>
                                    </motion.button>

                                    {trackers.map(tracker => (
                                        <motion.div
                                            key={tracker.id}
                                            onClick={() => executeBlueprint(tracker)}
                                            whileTap={{ scale: 0.95 }}
                                            className={`${tracker.layout === 'WIDE' ? 'col-span-2 aspect-[2.5/1]' : 'col-span-1 aspect-[4/5]'} bg-[#151515] border border-white/5 rounded-[2rem] p-5 relative overflow-hidden group cursor-pointer shadow-lg flex flex-col justify-between hover:border-white/20 transition-all`}
                                        >
                                            <div className="relative z-10 flex justify-between items-start">
                                                <div className="flex items-center gap-3">
                                                    <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${tracker.color} flex items-center justify-center text-white shadow-lg`}>
                                                        <Cpu size={20} />
                                                    </div>
                                                </div>
                                                <div className="flex gap-2">
                                                    <button 
                                                        onClick={(e) => handleEditTracker(tracker.id, e)}
                                                        className="p-2 bg-white/5 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 z-20"
                                                    >
                                                        <Edit2 size={16} />
                                                    </button>
                                                    <button 
                                                        onClick={(e) => { e.stopPropagation(); onDeleteTracker(tracker.id); }}
                                                        className="p-2 bg-white/5 rounded-lg text-neutral-400 hover:text-red-400 hover:bg-red-500/10 z-20"
                                                    >
                                                        <Trash2 size={16} />
                                                    </button>
                                                </div>
                                            </div>

                                            <div className="relative z-10 pt-2 mt-auto">
                                                <h3 className="text-white font-bold text-lg leading-tight line-clamp-1 mb-1">{tracker.name}</h3>
                                                <div className="flex items-baseline gap-1">
                                                    <span className="text-3xl font-mono font-bold text-white tracking-tighter">
                                                        {tracker.currentValue}
                                                    </span>
                                                    <span className="text-xs text-neutral-500 font-bold">{tracker.unit}</span>
                                                </div>
                                            </div>
                                            <div className={`absolute -right-10 -bottom-10 w-32 h-32 bg-gradient-to-br ${tracker.color} opacity-10 blur-2xl group-hover:opacity-20 transition-opacity`} />
                                        </motion.div>
                                    ))}
                                </div>
                            </div>
                        </>
                    ) : (
                        // --- BLUEPRINT EDITOR UI ---
                        <div className="flex flex-col h-full bg-[#050505] touch-none select-none">
                            {/* Toolbar */}
                            <div className="h-16 border-b border-white/10 bg-[#121212] flex items-center justify-between px-4 z-20 shrink-0">
                                <div className="flex items-center gap-4">
                                    <button onClick={() => { setMode('LIST'); setEditingId(null); }} className="p-2 rounded-full hover:bg-white/10 text-neutral-400">
                                        <ArrowLeft size={20} />
                                    </button>
                                    <input 
                                        value={trackerName}
                                        onChange={(e) => setTrackerName(e.target.value)}
                                        className="bg-transparent text-white font-bold outline-none border-b border-transparent focus:border-primary w-32 sm:w-40"
                                        placeholder="Nombre..."
                                    />
                                    <div className="flex gap-1">
                                        {GRADIENTS.slice(0, 3).map(g => (
                                            <button 
                                                key={g.id}
                                                onClick={() => setTrackerColor(g.class)}
                                                className={`w-6 h-6 rounded-full bg-gradient-to-br ${g.class} ${trackerColor === g.class ? 'ring-2 ring-white' : 'opacity-30'}`}
                                            />
                                        ))}
                                    </div>
                                </div>
                                <button onClick={handleSaveTracker} className="px-4 py-2 bg-primary text-white rounded-lg font-bold text-sm flex items-center gap-2 hover:bg-primary/80 active:scale-95">
                                    <Save size={16} /> <span className="hidden sm:inline">{editingId ? 'Actualizar' : 'Guardar'}</span>
                                </button>
                            </div>

                            <div className="flex-1 flex overflow-hidden relative">
                                {/* Sidebar */}
                                <div className="w-16 sm:w-48 bg-[#0f0f0f] border-r border-white/5 flex flex-col z-10 overflow-y-auto no-scrollbar items-center sm:items-stretch">
                                    {['Eventos', 'Acciones', 'Datos', 'Matemáticas', 'Lógica', 'Control'].map(cat => {
                                        const nodesInCat = Object.entries(NODE_TYPES).filter(([_, def]) => def.category === cat);
                                        if (nodesInCat.length === 0) return null;
                                        return (
                                            <div key={cat} className="mb-2">
                                                <div className="hidden sm:block p-4 pb-2 text-[10px] font-bold text-neutral-500 uppercase tracking-wider">{cat}</div>
                                                <div className="px-1 sm:px-2 space-y-2 pb-2 flex flex-col items-center sm:block">
                                                    {nodesInCat.map(([type, def]) => {
                                                        const Icon = def.icon;
                                                        return (
                                                            <button 
                                                                key={type}
                                                                onClick={() => addNode(type)}
                                                                className={`w-10 h-10 sm:w-full sm:h-auto sm:p-3 rounded-xl border ${def.color} bg-white/5 hover:bg-white/10 flex items-center justify-center sm:justify-start gap-2 transition-all active:scale-95`}
                                                            >
                                                                <Icon size={16} className="text-white" />
                                                                <span className="hidden sm:block text-white text-xs font-bold">{def.title}</span>
                                                            </button>
                                                        );
                                                    })}
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>

                                {/* Canvas */}
                                <div 
                                    className="flex-1 relative cursor-grab active:cursor-grabbing overflow-hidden bg-[#050505]"
                                    ref={canvasRef}
                                    onMouseDown={(e) => handleStart(e)}
                                    onTouchStart={(e) => handleStart(e)}
                                    onMouseMove={(e) => handleMove(e)}
                                    onTouchMove={(e) => handleMove(e)}
                                    onMouseUp={handleEnd}
                                    onTouchEnd={handleEnd}
                                >
                                    {/* Grid */}
                                    <div className="absolute inset-0 opacity-20 pointer-events-none" 
                                        style={{ 
                                            backgroundImage: 'radial-gradient(#333 1px, transparent 1px)', 
                                            backgroundSize: `${20 * viewport.zoom}px ${20 * viewport.zoom}px`,
                                            backgroundPosition: `${viewport.x}px ${viewport.y}px`
                                        }} 
                                    />

                                    <div style={{ transform: `translate(${viewport.x}px, ${viewport.y}px) scale(${viewport.zoom})`, transformOrigin: '0 0', width: '100%', height: '100%' }}>
                                        
                                        {/* Wires */}
                                        <svg className="absolute top-0 left-0 w-[5000px] h-[5000px] pointer-events-none overflow-visible">
                                            {connections.map(conn => {
                                                const source = nodes.find(n => n.id === conn.sourceNodeId);
                                                const target = nodes.find(n => n.id === conn.targetNodeId);
                                                if (!source || !target) return null;

                                                const sIdx = source.outputs.findIndex(p => p.id === conn.sourcePortId);
                                                const tIdx = target.inputs.findIndex(p => p.id === conn.targetPortId);

                                                // Dynamic Height Calculation based on Node Type/Structure
                                                const HEADER_H = 32;
                                                const ROW_H = 24;
                                                const EXTRA_UI_H = source.type === 'VAL_NUMBER' || source.type === 'VAL_RANDOM' ? 34 : 0;
                                                
                                                const sy = source.position.y + HEADER_H + 12 + EXTRA_UI_H + (sIdx * ROW_H) + 8;
                                                const sx = source.position.x + 180;

                                                const targetUI = target.type === 'VAL_NUMBER' || target.type === 'VAL_RANDOM' ? 34 : 0;
                                                const ty = target.position.y + HEADER_H + 12 + targetUI + (tIdx * ROW_H) + 8;
                                                const tx = target.position.x;

                                                const cp1x = sx + Math.abs(tx - sx) * 0.5;
                                                const cp2x = tx - Math.abs(tx - sx) * 0.5;

                                                return (
                                                    <path 
                                                        key={conn.id}
                                                        d={`M ${sx} ${sy} C ${cp1x} ${sy}, ${cp2x} ${ty}, ${tx} ${ty}`}
                                                        fill="none"
                                                        stroke={NODE_TYPES[source.type].color.includes('red') ? '#ef4444' : NODE_TYPES[source.type].color.includes('purple') ? '#a855f7' : '#3b82f6'}
                                                        strokeWidth="3"
                                                        className="drop-shadow-md opacity-80"
                                                    />
                                                );
                                            })}
                                            {connecting && (
                                                <path 
                                                    d={`M ${connecting.x} ${connecting.y} C ${connecting.x + 50} ${connecting.y}, ${mousePos.x - 50} ${mousePos.y}, ${mousePos.x} ${mousePos.y}`}
                                                    fill="none"
                                                    stroke="#fff"
                                                    strokeWidth="2"
                                                    strokeDasharray="5,5"
                                                    opacity="0.5"
                                                />
                                            )}
                                        </svg>

                                        {/* Nodes */}
                                        {nodes.map(node => (
                                            <div
                                                key={node.id}
                                                className={`absolute w-[180px] bg-[#1a1a1a] rounded-xl border ${NODE_TYPES[node.type].color} shadow-2xl flex flex-col select-none`}
                                                style={{ left: node.position.x, top: node.position.y }}
                                            >
                                                {/* Header */}
                                                <div 
                                                    className={`h-8 ${NODE_TYPES[node.type].color.replace('border', 'bg').replace('-500', '-500/20')} border-b ${NODE_TYPES[node.type].color} rounded-t-xl px-3 flex items-center justify-between cursor-move touch-none`}
                                                    onMouseDown={(e) => handleStart(e, node.id)}
                                                    onTouchStart={(e) => handleStart(e, node.id)}
                                                >
                                                    <span className="text-[10px] font-bold text-white uppercase">{node.title}</span>
                                                    <button onClick={() => setNodes(nodes.filter(n => n.id !== node.id))} className="text-white/50 hover:text-red-400" onMouseDown={e => e.stopPropagation()} onTouchStart={e => e.stopPropagation()}>
                                                        <X size={12} />
                                                    </button>
                                                </div>

                                                <div className="p-3 space-y-2 relative">
                                                    {node.type === 'VAL_NUMBER' && (
                                                        <input 
                                                            type="number"
                                                            value={node.data.value}
                                                            onChange={(e) => {
                                                                const val = e.target.value;
                                                                setNodes(prev => prev.map(n => n.id === node.id ? { ...n, data: { ...n.data, value: val } } : n));
                                                            }}
                                                            className="w-full bg-black/40 border border-white/10 rounded px-2 py-1 text-xs text-white mb-2"
                                                            onMouseDown={(e) => e.stopPropagation()} 
                                                            onTouchStart={(e) => e.stopPropagation()}
                                                        />
                                                    )}

                                                    {/* Inputs */}
                                                    {node.inputs.map((port, idx) => (
                                                        <div key={port.id} className="flex items-center gap-2 relative h-6">
                                                            <div 
                                                                className="absolute -left-6 w-8 h-8 flex items-center justify-center cursor-crosshair z-50"
                                                                onMouseDown={(e) => handlePortStart(node.id, port.id, true, e)}
                                                                onTouchStart={(e) => handlePortStart(node.id, port.id, true, e)}
                                                                data-port-id={port.id}
                                                                data-node-id={node.id}
                                                                data-is-input="true"
                                                            >
                                                                <div className={`w-3 h-3 rounded-full border transition-colors ${connections.some(c => c.targetNodeId === node.id && c.targetPortId === port.id) ? 'bg-white border-white' : 'bg-neutral-800 border-neutral-500'}`} />
                                                            </div>
                                                            <span className="text-[10px] text-neutral-400 ml-2">{port.name}</span>
                                                        </div>
                                                    ))}

                                                    {/* Outputs */}
                                                    {node.outputs.map((port, idx) => (
                                                        <div key={port.id} className="flex items-center justify-end gap-2 relative h-6">
                                                            <span className="text-[10px] text-neutral-400 mr-2">{port.name}</span>
                                                            <div 
                                                                className="absolute -right-6 w-8 h-8 flex items-center justify-center cursor-crosshair z-50"
                                                                onMouseDown={(e) => handlePortStart(node.id, port.id, false, e)}
                                                                onTouchStart={(e) => handlePortStart(node.id, port.id, false, e)}
                                                                data-port-id={port.id}
                                                                data-node-id={node.id}
                                                                data-is-input="false"
                                                            >
                                                                <div className={`w-3 h-3 rounded-full border transition-colors ${connections.some(c => c.sourceNodeId === node.id && c.sourcePortId === port.id) ? 'bg-white border-white' : 'bg-neutral-800 border-neutral-500'}`} />
                                                            </div>
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </motion.div>
            )}
        </AnimatePresence>
    );
};
