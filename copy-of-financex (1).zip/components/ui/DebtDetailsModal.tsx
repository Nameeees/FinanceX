
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Trash2, Calendar, FileText, ArrowUpRight, ArrowDownRight, Wallet, CheckCircle2, AlertTriangle, History } from 'lucide-react';
import { Debt, DebtType } from '../../types';

interface DebtDetailsModalProps {
  debt: Debt | null;
  onClose: () => void;
  onPay: (debt: Debt) => void;
  onDelete: (id: string) => void;
  onDeletePayment: (debtId: string, paymentId: string) => void;
}

export const DebtDetailsModal: React.FC<DebtDetailsModalProps> = ({ debt, onClose, onPay, onDelete, onDeletePayment }) => {
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    if (debt) {
        setIsDeleting(false);
    }
  }, [debt]);

  if (!debt) return null;

  const isLent = debt.type === DebtType.LENT;
  const progress = Math.min((debt.paidAmount / debt.amount) * 100, 100);
  const isFullyPaid = debt.paidAmount >= debt.amount;
  
  const themeColor = isLent ? 'text-emerald-400' : 'text-rose-400';
  const themeBg = isLent ? 'bg-emerald-500' : 'bg-rose-500';

  return (
    <AnimatePresence>
      {debt && (
        <>
           {/* Backdrop */}
           <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-[2px] z-[60]"
          />

          {/* Modal */}
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed bottom-0 left-0 right-0 z-[70] bg-[#121212] rounded-t-[2.5rem] border-t border-white/10 overflow-hidden shadow-2xl p-6 pb-8 max-h-[90vh] flex flex-col"
          >
             <div className="flex-1 overflow-y-auto no-scrollbar">
                {/* Header */}
                <div className="flex justify-between items-start mb-6">
                    <div className="flex items-center gap-3">
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center text-xl font-bold ${isLent ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'}`}>
                            {debt.person.charAt(0)}
                        </div>
                        <div>
                            <h2 className="text-xl font-bold text-white">{debt.person}</h2>
                            <div className="flex items-center gap-1.5 text-xs text-neutral-400">
                            {isLent ? <ArrowUpRight size={12} className="text-emerald-400"/> : <ArrowDownRight size={12} className="text-rose-400"/>}
                            {isLent ? 'Te debe' : 'Le debes'}
                            </div>
                        </div>
                    </div>
                    <button onClick={onClose} className="p-2 bg-white/5 rounded-full text-neutral-400 hover:text-white">
                        <X size={20} />
                    </button>
                </div>

                {/* Amount Display */}
                <div className="flex flex-col items-center mb-8">
                    <span className="text-neutral-500 text-xs uppercase tracking-wider mb-1">Restante</span>
                    <h2 className={`text-5xl font-bold tracking-tight mb-2 ${themeColor}`}>
                        ${(Math.max(0, debt.amount - debt.paidAmount)).toLocaleString()}
                    </h2>
                    <div className="flex items-center gap-2 text-neutral-400 bg-surface px-3 py-1 rounded-full text-sm border border-white/5">
                        <span>Total original: ${debt.amount.toLocaleString()}</span>
                    </div>
                </div>

                {/* Progress Bar */}
                <div className="mb-8">
                    <div className="flex justify-between text-xs text-neutral-400 mb-2">
                        <span>Progreso</span>
                        <span>{progress.toFixed(0)}%</span>
                    </div>
                    <div className="w-full h-4 bg-surfaceHighlight rounded-full overflow-hidden border border-white/5">
                        <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${progress}%` }}
                            className={`h-full ${themeBg}`}
                        />
                    </div>
                </div>

                {/* Details Box */}
                <div className="grid grid-cols-2 gap-3 mb-8">
                    <div className="bg-surface rounded-2xl p-3 border border-white/5 flex flex-col gap-1">
                        <div className="flex items-center gap-2 text-neutral-400 mb-1">
                            <Calendar size={14} />
                            <span className="text-[10px] uppercase font-bold">Vencimiento</span>
                        </div>
                        <span className="text-white font-medium text-sm">{debt.dueDate || 'No definida'}</span>
                    </div>
                    
                    <div className="bg-surface rounded-2xl p-3 border border-white/5 flex flex-col gap-1">
                        <div className="flex items-center gap-2 text-neutral-400 mb-1">
                            <FileText size={14} />
                            <span className="text-[10px] uppercase font-bold">Nota</span>
                        </div>
                        <span className="text-white font-medium text-sm truncate">{debt.description || '-'}</span>
                    </div>
                </div>

                {/* Payment History */}
                <div className="mb-8">
                    <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-3 flex items-center gap-2">
                        <History size={14} /> Historial de Abonos
                    </h3>
                    <div className="space-y-2">
                        {debt.payments && debt.payments.length > 0 ? (
                            debt.payments.map((payment) => (
                                <div key={payment.id} className="flex items-center justify-between p-3 rounded-xl bg-surface border border-white/5">
                                    <div className="flex flex-col">
                                        <span className="text-white font-bold text-sm">${payment.amount.toLocaleString()}</span>
                                        <span className="text-[10px] text-neutral-500">{new Date(payment.date).toLocaleDateString()}</span>
                                    </div>
                                    <button 
                                        onClick={() => onDeletePayment(debt.id, payment.id)}
                                        className="p-2 text-neutral-500 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
                                    >
                                        <Trash2 size={16} />
                                    </button>
                                </div>
                            ))
                        ) : (
                            <div className="text-center py-4 text-neutral-600 text-xs italic bg-surface/30 rounded-xl">
                                No hay abonos registrados
                            </div>
                        )}
                    </div>
                </div>
             </div>

             {/* Actions */}
             <div className="shrink-0 pt-4 border-t border-white/5">
                <AnimatePresence mode="wait">
                    {!isDeleting ? (
                        <motion.div 
                            key="actions"
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -10 }}
                            className="grid grid-cols-[1fr_auto] gap-3"
                        >
                            {!isFullyPaid ? (
                                <button 
                                    onClick={() => onPay(debt)}
                                    className={`flex items-center justify-center gap-2 py-4 rounded-xl ${themeBg} text-white font-bold transition-all active:scale-95 shadow-lg shadow-${isLent ? 'emerald' : 'rose'}-500/20`}
                                >
                                    <Wallet size={20} />
                                    Abonar
                                </button>
                            ) : (
                                <div className="flex items-center justify-center gap-2 py-4 rounded-xl bg-surfaceHighlight text-emerald-400 font-bold border border-emerald-500/20">
                                    <CheckCircle2 size={20} />
                                    Completado
                                </div>
                            )}
                            
                            <button 
                                onClick={() => setIsDeleting(true)}
                                className="w-16 flex items-center justify-center rounded-xl bg-surface hover:bg-red-500/10 text-neutral-400 hover:text-red-400 transition-colors border border-white/5 hover:border-red-500/20"
                            >
                                <Trash2 size={20} />
                            </button>
                        </motion.div>
                    ) : (
                        <motion.div 
                            key="confirm"
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            className="flex flex-col gap-3"
                        >
                            <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-3 flex items-center gap-3 mb-1">
                                <AlertTriangle size={20} className="text-red-500" />
                                <div className="flex flex-col">
                                    <span className="text-red-200 text-sm font-bold">¿Borrar deuda?</span>
                                    <span className="text-red-300/70 text-xs">Esto también borrará el historial asociado.</span>
                                </div>
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                                <button 
                                    onClick={() => setIsDeleting(false)}
                                    className="py-4 rounded-xl bg-surface hover:bg-surfaceHighlight text-neutral-300 font-semibold transition-colors"
                                >
                                    Cancelar
                                </button>
                                <button 
                                    onClick={() => {
                                        onDelete(debt.id);
                                        onClose();
                                    }}
                                    className="py-4 rounded-xl bg-red-500 text-white font-bold transition-colors shadow-lg shadow-red-500/20"
                                >
                                    Eliminar Todo
                                </button>
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>
             </div>

          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};