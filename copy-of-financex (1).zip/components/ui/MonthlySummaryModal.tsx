
import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronLeft, ChevronRight, TrendingUp, TrendingDown, PieChart, Activity, ArrowUpRight, PiggyBank, AlertCircle, ArrowLeft, Layers } from 'lucide-react';
import { Transaction, TransactionType } from '../../types';
import { TransactionList } from '../TransactionList';

interface MonthlySummaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactions: Transaction[];
  displayCurrency: string;
  userCurrency: string; // Added base currency prop
  currencies: Array<{ code: string; symbol: string; rate: number }>;
}

export const MonthlySummaryModal: React.FC<MonthlySummaryModalProps> = ({ 
  isOpen, 
  onClose, 
  transactions,
  displayCurrency,
  userCurrency,
  currencies
}) => {
  const [targetDate, setTargetDate] = useState(new Date());
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const summary = useMemo(() => {
      const month = targetDate.getMonth();
      const year = targetDate.getFullYear();
      
      const baseCurr = currencies.find(c => c.code === userCurrency) || { rate: 1 };
      const targetCurr = currencies.find(c => c.code === displayCurrency) || { rate: 1, symbol: '$' };

      const convert = (val: number) => (val / baseCurr.rate) * targetCurr.rate;

      // --- CURRENT MONTH DATA ---
      const monthlyTrans = transactions.filter(t => {
          const [y, m, d] = t.date.split('-').map(Number);
          return (m - 1) === month && y === year;
      });

      let income = 0;
      let expense = 0;
      let maxExpenseTx: Transaction | null = null;
      const catMap: Record<string, number> = {};

      monthlyTrans.forEach(t => {
          if (t.type === TransactionType.INCOME) {
              income += t.amount;
          } else {
              expense += t.amount;
              const cat = t.category || 'Otros';
              catMap[cat] = (catMap[cat] || 0) + t.amount;
              
              if (!maxExpenseTx || t.amount > maxExpenseTx.amount) {
                  maxExpenseTx = t;
              }
          }
      });

      // --- PREVIOUS MONTH DATA (For Trends) ---
      const prevDate = new Date(year, month - 1);
      const prevTrans = transactions.filter(t => {
          const [y, m, d] = t.date.split('-').map(Number);
          return (m - 1) === prevDate.getMonth() && y === prevDate.getFullYear();
      });
      const prevExpense = prevTrans.filter(t => t.type === TransactionType.EXPENSE).reduce((a,b) => a + b.amount, 0);
      
      // --- CALCULATIONS ---
      
      // Expense Trend
      let expenseTrend = 0;
      if (prevExpense > 0) {
          expenseTrend = ((expense - prevExpense) / prevExpense) * 100;
      }

      // Daily Average
      const now = new Date();
      const isCurrentMonth = month === now.getMonth() && year === now.getFullYear();
      const daysInMonth = new Date(year, month + 1, 0).getDate();
      const daysPassed = isCurrentMonth ? now.getDate() : daysInMonth;
      const dailyAverage = expense / (daysPassed || 1);

      // Savings Rate
      const savingsRate = income > 0 ? ((income - expense) / income) * 100 : 0;

      const categories = Object.entries(catMap)
          .map(([name, val]) => ({ name, value: val }))
          .sort((a, b) => b.value - a.value);

      let cumulativePercent = 0;
      const chartData = categories.map((cat, i) => {
          const percent = expense > 0 ? (cat.value / expense) * 100 : 0;
          const start = cumulativePercent;
          cumulativePercent += percent;
          return { ...cat, percent, start };
      });

      return {
          monthName: targetDate.toLocaleString('es-ES', { month: 'long', year: 'numeric' }),
          income: convert(income),
          expense: convert(expense),
          balance: convert(income - expense),
          symbol: targetCurr.symbol,
          chartData,
          isEmpty: monthlyTrans.length === 0,
          // Stats
          expenseTrend,
          dailyAverage: convert(dailyAverage),
          maxTxName: maxExpenseTx ? (maxExpenseTx as Transaction).title : '-',
          maxTxAmount: maxExpenseTx ? convert((maxExpenseTx as Transaction).amount) : 0,
          savingsRate,
          // Pass convert function for breakdown
          convert
      };
  }, [transactions, targetDate, displayCurrency, userCurrency, currencies]);

  // Derived state for the detailed view
  const detailedTransactions = useMemo(() => {
      if (!selectedCategory) return [];
      const month = targetDate.getMonth();
      const year = targetDate.getFullYear();

      return transactions
          .filter(t => {
              const [y, m] = t.date.split('-').map(Number);
              const isSameMonth = (m - 1) === month && y === year;
              return isSameMonth && t.category === selectedCategory && t.type === TransactionType.EXPENSE;
          })
          .map(t => ({
              ...t,
              // Convert amount purely for display in this specific view to match the header totals
              amount: summary.convert(t.amount)
          }))
          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [selectedCategory, transactions, targetDate, summary]);

  const changeMonth = (dir: number) => {
      const newDate = new Date(targetDate);
      newDate.setMonth(newDate.getMonth() + dir);
      setTargetDate(newDate);
      setSelectedCategory(null); // Reset detail view when changing month
  };

  const handleBack = () => {
      if (selectedCategory) {
          setSelectedCategory(null);
      } else {
          onClose();
      }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed inset-0 z-[100] bg-[#0a0a0a] flex flex-col overflow-hidden"
        >
            {/* Header */}
            <div className="flex items-center justify-between p-6 shrink-0 border-b border-white/5 bg-[#0a0a0a]">
                <div className="flex items-center gap-3">
                    {selectedCategory ? (
                        <button 
                            onClick={() => setSelectedCategory(null)}
                            className="p-2 rounded-full bg-surface border border-white/5 text-neutral-400 hover:text-white transition-colors"
                        >
                            <ArrowLeft size={20} />
                        </button>
                    ) : (
                        <div className="p-2 rounded-full bg-surface/50 text-primary">
                            <PieChart size={20} />
                        </div>
                    )}
                    <h2 className="text-xl font-bold text-white capitalize">
                        {selectedCategory ? selectedCategory : 'Análisis Mensual'}
                    </h2>
                </div>
                <button onClick={onClose} className="p-2 rounded-full bg-surface text-neutral-400 hover:text-white transition-colors">
                    <X size={20} />
                </button>
            </div>

            {/* Content Switcher */}
            <div className="flex-1 overflow-y-auto no-scrollbar relative">
                <AnimatePresence mode="wait">
                    {!selectedCategory ? (
                        <motion.div 
                            key="overview"
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: -20 }}
                            className="p-6 pb-24"
                        >
                             {/* Month Navigator */}
                            <div className="mb-6 flex items-center justify-between bg-surface rounded-2xl p-2 border border-white/5">
                                <button onClick={() => changeMonth(-1)} className="p-2 rounded-xl hover:bg-white/5 text-neutral-400 hover:text-white transition-colors"><ChevronLeft size={20}/></button>
                                <div className="flex flex-col items-center">
                                    <span className="text-sm font-bold text-white capitalize">{summary.monthName}</span>
                                </div>
                                <button onClick={() => changeMonth(1)} className="p-2 rounded-xl hover:bg-white/5 text-neutral-400 hover:text-white transition-colors"><ChevronRight size={20}/></button>
                            </div>

                            {/* Summary Cards */}
                            <div className="grid grid-cols-2 gap-3 mb-6">
                                <div className="p-4 rounded-3xl bg-surface border border-white/5 flex flex-col gap-2 relative overflow-hidden">
                                    <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider relative z-10">
                                        <TrendingUp size={14} /> Ingresos
                                    </div>
                                    <span className="text-xl font-mono font-bold text-white relative z-10">{summary.symbol}{summary.income.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                                    <div className="absolute -bottom-4 -right-4 w-16 h-16 bg-emerald-500/10 rounded-full blur-xl" />
                                </div>
                                <div className="p-4 rounded-3xl bg-surface border border-white/5 flex flex-col gap-2 relative overflow-hidden">
                                    <div className="flex items-center justify-between relative z-10">
                                        <div className="flex items-center gap-2 text-rose-400 text-xs font-bold uppercase tracking-wider">
                                            <TrendingDown size={14} /> Gastos
                                        </div>
                                        {summary.expenseTrend !== 0 && (
                                            <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${summary.expenseTrend > 0 ? 'bg-red-500/20 text-red-400' : 'bg-green-500/20 text-green-400'}`}>
                                                {summary.expenseTrend > 0 ? '↑' : '↓'} {Math.abs(summary.expenseTrend).toFixed(0)}%
                                            </span>
                                        )}
                                    </div>
                                    <span className="text-xl font-mono font-bold text-white relative z-10">{summary.symbol}{summary.expense.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                                    <div className="absolute -bottom-4 -right-4 w-16 h-16 bg-rose-500/10 rounded-full blur-xl" />
                                </div>
                            </div>

                            {/* Net Balance */}
                            <div className={`p-6 rounded-[2rem] mb-6 text-center border relative overflow-hidden ${summary.balance >= 0 ? 'bg-emerald-500/10 border-emerald-500/20' : 'bg-rose-500/10 border-rose-500/20'}`}>
                                <span className="text-xs font-bold uppercase tracking-widest text-neutral-400 relative z-10">Balance Neto</span>
                                <h1 className={`text-4xl font-bold mt-2 relative z-10 ${summary.balance >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                                    {summary.balance >= 0 ? '+' : ''}{summary.symbol}{summary.balance.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                                </h1>
                                <div className={`absolute top-0 left-0 w-full h-full opacity-20 blur-3xl ${summary.balance >= 0 ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                            </div>

                            {!summary.isEmpty && (
                                <>
                                    {/* KEY METRICS GRID */}
                                    <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-3 px-1">Estadísticas Clave</h3>
                                    <div className="grid grid-cols-3 gap-2 mb-8">
                                        {/* Daily Avg */}
                                        <div className="bg-surface rounded-2xl p-3 border border-white/5 flex flex-col items-center text-center">
                                            <Activity size={16} className="text-blue-400 mb-2" />
                                            <span className="text-[10px] text-neutral-500 font-bold uppercase">Prom. Diario</span>
                                            <span className="text-sm font-bold text-white mt-1">{summary.symbol}{summary.dailyAverage.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                                        </div>
                                        
                                        {/* Biggest Spend */}
                                        <div className="bg-surface rounded-2xl p-3 border border-white/5 flex flex-col items-center text-center">
                                            <ArrowUpRight size={16} className="text-orange-400 mb-2" />
                                            <span className="text-[10px] text-neutral-500 font-bold uppercase">Mayor Gasto</span>
                                            <span className="text-sm font-bold text-white mt-1">{summary.symbol}{summary.maxTxAmount.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                                            <span className="text-[9px] text-neutral-600 truncate w-full mt-0.5">{summary.maxTxName}</span>
                                        </div>

                                        {/* Savings Rate */}
                                        <div className="bg-surface rounded-2xl p-3 border border-white/5 flex flex-col items-center text-center">
                                            <PiggyBank size={16} className="text-purple-400 mb-2" />
                                            <span className="text-[10px] text-neutral-500 font-bold uppercase">Ahorro</span>
                                            <span className={`text-sm font-bold mt-1 ${summary.savingsRate > 20 ? 'text-green-400' : (summary.savingsRate > 0 ? 'text-yellow-400' : 'text-red-400')}`}>
                                                {summary.savingsRate.toFixed(0)}%
                                            </span>
                                        </div>
                                    </div>

                                    {/* Chart Section */}
                                    <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-4 px-1">Distribución</h3>
                                    <div className="flex flex-col items-center justify-center mb-8 relative">
                                        <div className="w-64 h-64 relative">
                                            {/* CSS Conic Gradient Chart */}
                                            <div 
                                                style={{
                                                    width: '100%', height: '100%',
                                                    borderRadius: '50%',
                                                    background: `conic-gradient(${
                                                        summary.chartData.map((cat, i, arr) => {
                                                            const prev = arr.slice(0, i).reduce((a,c) => a + c.percent, 0);
                                                            const palette = ['#ef4444', '#f97316', '#eab308', '#22c55e', '#3b82f6', '#a855f7', '#ec4899'];
                                                            const catColor = palette[i % palette.length];
                                                            return `${catColor} 0 ${prev + cat.percent}%`;
                                                        }).join(', ')
                                                    })`
                                                }}
                                                className="transform -rotate-90 shadow-2xl"
                                            />
                                            
                                            {/* Hole */}
                                            <div className="absolute inset-4 rounded-full bg-[#0a0a0a] flex items-center justify-center flex-col shadow-inner">
                                                <span className="text-neutral-500 text-xs font-bold uppercase tracking-wider">Total Gastado</span>
                                                <span className="text-2xl font-bold text-white mt-1">{summary.symbol}{summary.expense.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Breakdown List (Clickable) */}
                                    <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-4 px-1">Desglose por Categoría</h3>
                                    <div className="space-y-3">
                                        {summary.chartData.map((cat, i) => {
                                            const palette = ['bg-red-500', 'bg-orange-500', 'bg-yellow-500', 'bg-green-500', 'bg-blue-500', 'bg-purple-500', 'bg-pink-500'];
                                            const colorClass = palette[i % palette.length];
                                            const convertedVal = summary.convert(cat.value);

                                            return (
                                                <button 
                                                    key={i} 
                                                    onClick={() => setSelectedCategory(cat.name)}
                                                    className="w-full flex items-center gap-4 p-3 rounded-2xl bg-surface border border-white/5 hover:bg-surfaceHighlight hover:border-white/20 active:scale-[0.98] transition-all text-left group"
                                                >
                                                    <div className={`w-2 h-10 rounded-full ${colorClass}`} />
                                                    <div className="flex-1">
                                                        <div className="flex justify-between items-center mb-1">
                                                            <div className="flex items-center gap-2">
                                                                <span className="font-bold text-sm text-white capitalize">{cat.name}</span>
                                                                <ChevronRight size={14} className="text-neutral-600 opacity-0 group-hover:opacity-100 transition-opacity" />
                                                            </div>
                                                            <span className="font-mono text-sm text-white">{summary.symbol}{convertedVal.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                                                        </div>
                                                        <div className="w-full h-1.5 bg-neutral-800 rounded-full overflow-hidden">
                                                            <div className={`h-full ${colorClass}`} style={{ width: `${cat.percent}%` }} />
                                                        </div>
                                                    </div>
                                                    <div className="text-right min-w-[3rem]">
                                                        <span className="text-xs text-neutral-400 font-bold">{cat.percent.toFixed(1)}%</span>
                                                    </div>
                                                </button>
                                            );
                                        })}
                                    </div>
                                    <p className="text-center text-[10px] text-neutral-600 mt-4 mb-2">Toca una categoría para ver detalles.</p>
                                </>
                            ) : (
                                <div className="flex flex-col items-center justify-center py-20 opacity-50">
                                    <div className="w-20 h-20 bg-surface rounded-full flex items-center justify-center mb-4">
                                        <AlertCircle size={32} className="text-neutral-500" />
                                    </div>
                                    <p className="text-neutral-400 font-medium">Sin datos en este periodo.</p>
                                    <p className="text-neutral-600 text-xs mt-1">Registra transacciones para ver estadísticas.</p>
                                </div>
                            )}
                        </motion.div>
                    ) : (
                        <motion.div
                            key="detail"
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: 20 }}
                            className="p-6 h-full flex flex-col"
                        >
                             <div className="mb-6">
                                 <span className="text-xs font-bold text-neutral-500 uppercase tracking-wider block mb-1">Total Categoría</span>
                                 <div className="flex items-end gap-2">
                                     <h3 className="text-3xl font-bold text-white">
                                         {summary.symbol}{detailedTransactions.reduce((acc, t) => acc + t.amount, 0).toLocaleString(undefined, { maximumFractionDigits: 2 })}
                                     </h3>
                                     <span className="text-sm text-neutral-500 mb-1.5 font-medium bg-surface px-2 py-0.5 rounded-lg border border-white/5">
                                         {detailedTransactions.length} movs
                                     </span>
                                 </div>
                             </div>

                             <div className="flex-1 overflow-y-auto no-scrollbar -mx-6 px-6 pb-24">
                                 {detailedTransactions.length > 0 ? (
                                    <TransactionList 
                                        transactions={detailedTransactions} 
                                        title={`Movimientos de ${selectedCategory}`}
                                        showViewAll={false}
                                    />
                                 ) : (
                                     <div className="text-center py-10 text-neutral-500">No hay movimientos.</div>
                                 )}
                             </div>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
