
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, Globe, Github, ArrowRight, Loader2, Key, Search } from 'lucide-react';

interface OnboardingModalProps {
  isOpen: boolean;
  onComplete: (currencyCode: string, timezone: string) => void;
  onLoginWithToken?: (token: string) => Promise<boolean>;
  currencies: Array<{ code: string; name: string; symbol: string; flag: string; rate: number; timezone?: string }>;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({ isOpen, onComplete, onLoginWithToken, currencies }) => {
  const [step, setStep] = useState<'welcome' | 'currency' | 'login'>('welcome');
  const [selectedCurrency, setSelectedCurrency] = useState('USD');
  const [token, setToken] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  // Reset step to welcome every time modal opens to fix "back button bug"
  useEffect(() => {
    if (isOpen) {
        setStep('welcome');
        setLoginError('');
        setToken('');
        setSearchTerm('');
    }
  }, [isOpen]);

  // Ensure selected currency exists in the list (fallback to first if not)
  const initialSelection = currencies.find(c => c.code === 'USD') ? 'USD' : currencies[0]?.code;
  
  useEffect(() => {
    if (!selectedCurrency && initialSelection) {
        setSelectedCurrency(initialSelection);
    }
  }, [initialSelection]);

  if (!isOpen) return null;

  const handleLogin = async () => {
      if (!token || !onLoginWithToken) return;
      setIsLoggingIn(true);
      setLoginError('');
      
      const success = await onLoginWithToken(token.trim());
      
      if (!success) {
          setLoginError('Token inválido o sin datos de respaldo.');
          setIsLoggingIn(false);
      }
      // If success, parent will handle closing/redirect
  };

  const handleComplete = () => {
      const currencyObj = currencies.find(c => c.code === selectedCurrency);
      const timezone = currencyObj?.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone;
      onComplete(selectedCurrency, timezone);
  };

  const filteredCurrencies = currencies.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-xl">
       <motion.div 
         key={step}
         initial={{ opacity: 0, scale: 0.9 }}
         animate={{ opacity: 1, scale: 1 }}
         exit={{ opacity: 0, scale: 0.9 }}
         className="w-full max-w-sm px-6 h-full max-h-screen flex flex-col justify-center py-6"
       >
          {/* LOGO (Only on welcome or login, smaller on list) */}
          {step !== 'currency' && (
              <div className="flex justify-center mb-8 shrink-0">
                <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-primary to-blue-600 flex items-center justify-center shadow-[0_0_40px_rgba(109,40,217,0.5)]">
                    <Globe className="text-white w-10 h-10" />
                </div>
              </div>
          )}

          {step === 'welcome' && (
              <>
                <h1 className="text-3xl font-bold text-white text-center mb-2">Nexo Finance</h1>
                <p className="text-neutral-400 text-center mb-8 text-sm px-4">
                    Tu control financiero personal, seguro y sincronizado.
                </p>

                <div className="space-y-3">
                    <button
                        onClick={() => setStep('currency')}
                        className="w-full py-4 rounded-2xl bg-white text-black font-bold text-lg shadow-xl active:scale-95 transition-transform flex items-center justify-center gap-2"
                    >
                        Empezar de cero <ArrowRight size={20}/>
                    </button>
                    
                    <button
                        onClick={() => setStep('login')}
                        className="w-full py-4 rounded-2xl bg-surfaceHighlight border border-white/10 text-white font-bold text-lg active:scale-95 transition-transform flex items-center justify-center gap-2"
                    >
                        <Github size={20} /> Ya tengo cuenta
                    </button>
                </div>
              </>
          )}

          {step === 'login' && (
              <>
                 <h2 className="text-xl font-bold text-white text-center mb-2">Acceso con GitHub</h2>
                 <p className="text-neutral-400 text-center mb-6 text-xs px-4">
                    Pega tu Token de GitHub (Classic) para restaurar tus datos y activar la sincronización automática.
                 </p>

                 <div className="space-y-4">
                     <div>
                        <div className="bg-surface rounded-xl flex items-center px-4 py-3 border border-white/5 focus-within:border-primary/50 transition-colors">
                            <Key size={18} className="text-neutral-500 mr-3 shrink-0" />
                            <input 
                                type="text" 
                                value={token}
                                onChange={(e) => setToken(e.target.value)}
                                placeholder="ghp_xxxxxxxxxxxx"
                                className="bg-transparent border-none outline-none text-white w-full placeholder:text-neutral-600 font-mono text-sm"
                            />
                        </div>
                        {loginError && <p className="text-red-400 text-xs mt-2 text-center">{loginError}</p>}
                     </div>

                     <button
                        onClick={handleLogin}
                        disabled={isLoggingIn || token.length < 10}
                        className="w-full py-4 rounded-2xl bg-primary text-white font-bold text-lg shadow-xl active:scale-95 transition-transform disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                        {isLoggingIn ? <Loader2 className="animate-spin" /> : 'Entrar y Sincronizar'}
                    </button>
                    
                    <button
                        onClick={() => setStep('welcome')}
                        disabled={isLoggingIn}
                        className="w-full py-2 text-neutral-500 text-sm"
                    >
                        Volver
                    </button>
                 </div>
              </>
          )}

          {step === 'currency' && (
              <div className="flex flex-col h-full max-h-[80vh]">
                <div className="shrink-0">
                    <h1 className="text-2xl font-bold text-white text-center mb-2">Elige tu moneda</h1>
                    <p className="text-neutral-400 text-center mb-6 text-sm">
                        Selecciona tu país para configurar moneda y zona horaria.
                    </p>
                    
                    <div className="relative mb-4">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-500" size={18} />
                        <input 
                            type="text"
                            placeholder="Buscar país o moneda..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full bg-surface border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white outline-none focus:border-primary/50 transition-colors placeholder:text-neutral-600"
                        />
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto no-scrollbar space-y-3 mb-4 pr-1">
                    {filteredCurrencies.length > 0 ? (
                        filteredCurrencies.map((curr) => (
                            <button
                                key={curr.code}
                                onClick={() => setSelectedCurrency(curr.code)}
                                className={`w-full p-4 rounded-2xl flex items-center justify-between transition-all duration-200 border ${
                                    selectedCurrency === curr.code 
                                    ? 'bg-surfaceHighlight border-primary/50 shadow-lg' 
                                    : 'bg-surface/50 border-white/5 hover:bg-surfaceHighlight/50'
                                }`}
                            >
                                <div className="flex items-center gap-3">
                                    <span className="text-2xl">{curr.flag}</span>
                                    <div className="text-left">
                                        <span className="block text-white font-bold text-sm">{curr.code}</span>
                                        <span className="block text-neutral-500 text-xs">{curr.name}</span>
                                    </div>
                                </div>
                                {selectedCurrency === curr.code && (
                                    <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center">
                                        <Check size={14} className="text-white" />
                                    </div>
                                )}
                            </button>
                        ))
                    ) : (
                        <div className="text-center py-8 text-neutral-600">
                            <p>No se encontraron resultados.</p>
                        </div>
                    )}
                </div>

                <div className="shrink-0 space-y-3 pt-2">
                    <button
                        onClick={handleComplete}
                        className="w-full py-4 rounded-2xl bg-white text-black font-bold text-lg shadow-xl active:scale-95 transition-transform"
                    >
                        Comenzar
                    </button>
                    <button
                        onClick={() => setStep('welcome')}
                        className="w-full py-2 text-neutral-500 text-sm"
                    >
                        Atrás
                    </button>
                </div>
              </div>
          )}
       </motion.div>
    </div>
  );
};
