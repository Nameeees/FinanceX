
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Check, Delete, Wallet } from 'lucide-react';
import { Debt, DebtType } from '../../types';

interface PayDebtModalProps {
  isOpen: boolean;
  debt: Debt | null;
  onClose: () => void;
  onSave: (amount: number) => void;
}

export const PayDebtModal: React.FC<PayDebtModalProps> = ({ isOpen, debt, onClose, onSave }) => {
  const [amount, setAmount] = useState('0');

  if (!debt) return null;

  const remaining = debt.amount - debt.paidAmount;
  const isLent = debt.type === DebtType.LENT;
  const themeColor = isLent ? 'text-emerald-400' : 'text-rose-400';
  const themeBg = isLent ? 'bg-emerald-500' : 'bg-rose-500';

  const formatNumberString = (value: string) => {
    const parts = value.split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return parts.join('.');
  };

  const handleNumberPress = (num: string) => {
    let rawValue = amount.replace(/,/g, '');
    if (num === '.') {
      if (rawValue.includes('.')) return;
      rawValue += '.';
    } else {
      if (rawValue === '0') rawValue = num;
      else {
        if (rawValue.replace('.', '').length >= 12) return;
        rawValue += num;
      }
    }
    
    // Check if exceeds remaining
    const val = parseFloat(rawValue);
    if (val > remaining) {
        // Optional: Shake animation or toast could go here
        return; 
    }

    setAmount(formatNumberString(rawValue));
  };

  const handleDelete = () => {
    let rawValue = amount.replace(/,/g, '');
    if (rawValue.length <= 1) setAmount('0');
    else {
      rawValue = rawValue.slice(0, -1);
      if (rawValue === '') rawValue = '0';
      setAmount(formatNumberString(rawValue));
    }
  };

  const handleSave = () => {
    const val = parseFloat(amount.replace(/,/g, ''));
    if (val > 0) {
        onSave(val);
        setAmount('0');
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[80]"
          />

          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed bottom-0 left-0 right-0 z-[90] bg-[#0f0f0f] rounded-t-[2.5rem] border-t border-white/10 overflow-hidden shadow-2xl h-[85vh] flex flex-col"
          >
            <div className="px-6 pt-6 pb-2 shrink-0">
              <div className="flex justify-between items-center mb-6">
                <div>
                    <h3 className="text-white font-medium text-lg tracking-tight">Abonar a Deuda</h3>
                    <p className="text-neutral-500 text-xs">A: {debt.person}</p>
                </div>
                <button onClick={onClose} className="p-2 rounded-full bg-surface text-neutral-400 hover:text-white transition-colors">
                  <X size={20} />
                </button>
              </div>
            </div>

            <div className="shrink-0 flex flex-col items-center justify-center py-4 flex-1">
              <span className="text-neutral-500 mb-2 font-medium tracking-widest text-xs uppercase">Cantidad a Abonar</span>
              <div className="flex items-baseline gap-1 px-4 mb-2">
                <span className={`text-3xl font-light ${themeColor}`}>$</span>
                <span className={`text-6xl font-bold tracking-tighter ${themeColor} break-all text-center`}>
                  {amount}
                </span>
              </div>
              <div className="bg-surfaceHighlight px-3 py-1 rounded-full border border-white/5">
                <span className="text-xs text-neutral-400">Restante actual: ${remaining.toLocaleString()}</span>
              </div>
            </div>

            <div className="bg-surface/50 backdrop-blur-md pb-8 pt-4 px-6 rounded-t-[2.5rem] border-t border-white/5">
              <div className="grid grid-cols-3 gap-3 mb-4 h-[220px]">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9, '.', 0].map((num) => (
                  <button
                    key={num}
                    onClick={() => handleNumberPress(num.toString())}
                    className="h-full rounded-2xl bg-surface active:bg-surfaceHighlight text-white text-2xl font-medium active:scale-95 flex items-center justify-center shadow-sm border border-white/5 outline-none"
                    style={{ WebkitTapHighlightColor: 'transparent' }}
                  >
                    {num}
                  </button>
                ))}
                <button
                  onClick={handleDelete}
                  className="h-full rounded-2xl bg-surface active:bg-red-500/20 text-neutral-300 active:text-red-400 active:scale-95 flex items-center justify-center border border-white/5 outline-none"
                  style={{ WebkitTapHighlightColor: 'transparent' }}
                >
                  <Delete size={24} />
                </button>
              </div>

              <button
                onClick={handleSave}
                className={`w-full h-14 rounded-2xl ${themeBg} text-white text-lg font-bold flex items-center justify-center gap-2 shadow-[0_0_30px_-10px_rgba(0,0,0,0.5)] active:scale-95 outline-none`}
              >
                <Check size={24} strokeWidth={3} />
                Confirmar Abono
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
