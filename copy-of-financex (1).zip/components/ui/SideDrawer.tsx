import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, FileSpreadsheet, ChevronRight, PieChart } from 'lucide-react';
import { UserProfile, Transaction } from '../../types';

interface SideDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenSpreadsheet: () => void;
  onOpenMonthlySummary: () => void;
  user: UserProfile;
  transactions?: Transaction[]; 
  displayCurrency?: string;
  currencies?: any[];
}

export const SideDrawer: React.FC<SideDrawerProps> = ({ 
  isOpen, 
  onClose, 
  onOpenSpreadsheet,
  onOpenMonthlySummary, 
  user
}) => {

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/40 backdrop-blur-[2px] z-[90]"
          />
          
          {/* Drawer Panel */}
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: '-100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300, mass: 0.8 }}
            className="fixed top-0 left-0 bottom-0 w-[85%] max-w-[320px] bg-[#0f0f0f]/90 backdrop-blur-2xl border-r border-white/10 z-[100] shadow-[10px_0_40px_rgba(0,0,0,0.5)] rounded-r-[2.5rem] overflow-hidden flex flex-col"
          >
            {/* Background Effects */}
            <div className="absolute top-0 left-0 w-full h-[200px] bg-gradient-to-b from-primary/10 to-transparent pointer-events-none" />
            <div className="absolute top-[-50px] right-[-50px] w-32 h-32 bg-blue-500/20 rounded-full blur-[60px] pointer-events-none" />

            {/* User Header */}
            <div className="p-8 pb-6 relative z-10">
                <div className="flex justify-between items-start mb-6">
                    <div className="relative">
                        <div className="w-16 h-16 rounded-[1.2rem] p-[2px] bg-gradient-to-br from-primary via-purple-500 to-blue-500 shadow-lg shadow-primary/20">
                            <img src={user.avatarUrl} alt={user.name} className="w-full h-full rounded-[1rem] object-cover border-2 border-[#121212] bg-[#121212]" />
                        </div>
                    </div>
                    <button onClick={onClose} className="p-2 rounded-full bg-surface border border-white/5 text-neutral-400 hover:text-white transition-colors">
                        <X size={20} />
                    </button>
                </div>
                
                <h2 className="text-2xl font-bold text-white leading-tight mb-1">{user.name}</h2>
                <p className="text-neutral-500 text-sm">{user.email}</p>
            </div>

            {/* Navigation Links */}
            <div className="px-6 py-2 flex-1 overflow-y-auto">
                <div className="space-y-3">
                    <button 
                        onClick={() => { onOpenMonthlySummary(); onClose(); }}
                        className="w-full p-4 rounded-2xl bg-surface border border-white/5 hover:bg-surfaceHighlight hover:border-white/10 transition-all group flex items-center justify-between"
                    >
                        <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center group-hover:bg-purple-500 group-hover:text-white transition-colors">
                                <PieChart size={20} />
                            </div>
                            <div className="text-left">
                                <span className="block text-neutral-200 font-bold text-sm">Resumen Mensual</span>
                                <span className="block text-neutral-500 text-xs">Estadísticas y gráficas</span>
                            </div>
                        </div>
                        <ChevronRight size={18} className="text-neutral-600 group-hover:text-white transition-colors" />
                    </button>

                    <button 
                        onClick={() => { onOpenSpreadsheet(); onClose(); }}
                        className="w-full p-4 rounded-2xl bg-surface border border-white/5 hover:bg-surfaceHighlight hover:border-white/10 transition-all group flex items-center justify-between"
                    >
                        <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center group-hover:bg-emerald-500 group-hover:text-white transition-colors">
                                <FileSpreadsheet size={20} />
                            </div>
                            <div className="text-left">
                                <span className="block text-neutral-200 font-bold text-sm">Nexo Sheets</span>
                                <span className="block text-neutral-500 text-xs">Hojas de cálculo</span>
                            </div>
                        </div>
                        <ChevronRight size={18} className="text-neutral-600 group-hover:text-white transition-colors" />
                    </button>
                </div>

                <div className="mt-8 pt-8 border-t border-white/5">
                     <p className="text-neutral-600 text-xs text-center mb-4">Nexo Finance v3.0</p>
                </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
