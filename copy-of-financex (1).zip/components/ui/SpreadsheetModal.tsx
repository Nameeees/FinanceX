
import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { motion, AnimatePresence, LayoutGroup } from 'framer-motion';
import { X, LayoutTemplate, Trash2, Grid3X3, ArrowLeft, Plus, Edit3, Sigma, Divide, ArrowUpFromLine, FunctionSquare, FileSpreadsheet, Loader2, Sparkles } from 'lucide-react';
import { Sheet } from '../../types';

interface SpreadsheetModalProps {
  isOpen: boolean;
  onClose: () => void;
  sheets: Sheet[];
  onUpdateSheets: (sheets: Sheet[]) => void;
}

// --- CONFIGURATION ---
const TOTAL_ROWS = 2000;
const ROW_HEIGHT = 32;
const HEADER_HEIGHT = 32;
const VISIBLE_BUFFER = 10;
const COL_HEADERS = Array.from({ length: 26 }, (_, i) => String.fromCharCode(65 + i));
const TOTAL_COLS = COL_HEADERS.length;
const COL_WIDTH = 96; // w-24 = 96px
const ROW_HEADER_WIDTH = 40; // w-10 = 40px

// Pre-defined Templates
const TEMPLATES = [
  {
    id: 'budget',
    name: 'Presupuesto',
    data: {
      '0-0': 'CATEGORÍA', '0-1': 'PRESUPUESTO', '0-2': 'GASTADO', '0-3': 'RESTANTE',
      '1-0': 'Comida', '1-1': '300', '1-2': '0', '1-3': '=B2-C2',
      '2-0': 'Transporte', '2-1': '100', '2-2': '0', '2-3': '=B3-C3',
      '3-0': 'Ocio', '3-1': '150', '3-2': '0', '3-3': '=B4-C4',
      '4-0': 'TOTAL', '4-1': '=SUMA(B2:B4)', '4-2': '=SUMA(C2:C4)', '4-3': '=SUMA(D2:D4)'
    }
  },
  {
    id: 'savings',
    name: 'Ahorro',
    data: {
      '0-0': 'META', '0-1': 'COSTO', '0-2': 'AHORRADO', '0-3': 'FALTA',
      '1-0': 'Coche', '1-1': '5000', '1-2': '1200', '1-3': '=B2-C2',
      '2-0': 'Viaje', '2-1': '1500', '2-2': '300', '2-3': '=B3-C3',
      '3-0': 'TOTAL', '3-1': '=SUMA(B2:B3)', '3-2': '=SUMA(C2:C3)', '3-3': '=SUMA(D2:D3)'
    }
  }
];

const GRADIENTS = [
  'from-blue-500 to-cyan-500',
  'from-emerald-500 to-green-500',
  'from-purple-500 to-pink-500',
  'from-orange-500 to-red-500',
  'from-indigo-500 to-purple-500',
];

export const SpreadsheetModal: React.FC<SpreadsheetModalProps> = ({ isOpen, onClose, sheets, onUpdateSheets }) => {
  // --- STATE ---
  const [activeSheetId, setActiveSheetId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'LIST' | 'GRID'>('LIST');
  const [isCreating, setIsCreating] = useState(false);

  // Grid State
  const [selectedCell, setSelectedCell] = useState<{r: number, c: number} | null>(null);
  const [editingValue, setEditingValue] = useState<string>('');
  const [showTemplates, setShowTemplates] = useState(false);
  const [sheetNameEditing, setSheetNameEditing] = useState('');
  
  // Virtualization
  const [scrollTop, setScrollTop] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // --- HELPERS ---
  const getCellKey = (r: number, c: number) => `${r}-${c}`;
  const getCellId = (r: number, c: number) => `${COL_HEADERS[c]}${r + 1}`;

  const parseCellId = (id: string) => {
      const colChar = id.charAt(0).toUpperCase();
      const rowStr = id.slice(1);
      const c = colChar.charCodeAt(0) - 65;
      const r = parseInt(rowStr) - 1;
      return { r, c };
  };

  // --- FORMULA ENGINE ---
  const evaluateCell = useCallback((val: string, currentData: Record<string, string>, visited: Set<string> = new Set()): string => {
      if (!val?.startsWith('=')) return val;
      if (visited.has(val)) return '#CIRCULAR';

      let formula = val.substring(1).toUpperCase();
      const newVisited = new Set(visited).add(val);

      // Ranges
      const rangeRegex = /(SUM|SUMA|AVG|PROMEDIO|MAX|MAXIMO|MIN|MINIMO)\(([A-Z])([0-9]+):([A-Z])([0-9]+)\)/g;
      formula = formula.replace(rangeRegex, (_, func, c1, r1, c2, r2) => {
          const start = parseCellId(`${c1}${r1}`);
          const end = parseCellId(`${c2}${r2}`);
          const minR = Math.min(start.r, end.r);
          const maxR = Math.max(start.r, end.r);
          const minC = Math.min(start.c, end.c);
          const maxC = Math.max(start.c, end.c);

          const values: number[] = [];
          for(let r = minR; r <= maxR; r++) {
              for(let c = minC; c <= maxC; c++) {
                  const cellRaw = currentData[getCellKey(r, c)] || '0';
                  const evaluated = evaluateCell(cellRaw, currentData, newVisited);
                  const num = parseFloat(evaluated);
                  if (!isNaN(num)) values.push(num);
              }
          }

          if (values.length === 0) return '0';
          if (['SUM', 'SUMA'].includes(func)) return values.reduce((a, b) => a + b, 0).toString();
          if (['AVG', 'PROMEDIO'].includes(func)) return (values.reduce((a, b) => a + b, 0) / values.length).toString();
          if (['MAX', 'MAXIMO'].includes(func)) return Math.max(...values).toString();
          if (['MIN', 'MINIMO'].includes(func)) return Math.min(...values).toString();
          return '0';
      });

      // Single Cells
      const cellRegex = /([A-Z])([0-9]+)/g;
      formula = formula.replace(cellRegex, (match) => {
          const { r, c } = parseCellId(match);
          if (r < 0 || r >= TOTAL_ROWS || c < 0 || c >= TOTAL_COLS) return '0';
          const cellRaw = currentData[getCellKey(r, c)] || '0';
          const evaluated = evaluateCell(cellRaw, currentData, newVisited);
          const num = parseFloat(evaluated);
          return isNaN(num) ? '0' : num.toString();
      });

      // Math
      try {
          const cleanMath = formula.replace(/[^0-9+\-*/().]/g, '');
          // eslint-disable-next-line no-eval
          const result = eval(cleanMath);
          if (isNaN(result)) return '#ERROR';
          return Number.isInteger(result) ? result.toString() : result.toFixed(2);
      } catch (e) { return '#ERROR'; }
  }, []);

  // --- SHEET MANAGEMENT ---
  const saveSheets = (newSheets: Sheet[]) => {
      onUpdateSheets(newSheets);
  };

  const handleCreateSheet = async () => {
      if (isCreating) return;
      setIsCreating(true);
      
      // Simulate "processing" time for animation impact
      await new Promise(resolve => setTimeout(resolve, 800));

      const newSheet: Sheet = {
          id: Math.random().toString(36).substr(2, 9),
          name: `Hoja ${sheets.length + 1}`,
          data: {},
          lastModified: new Date().toISOString(),
          color: GRADIENTS[sheets.length % GRADIENTS.length]
      };
      
      const updated = [...sheets, newSheet];
      saveSheets(updated);
      setIsCreating(false);
  };

  const deleteSheet = (id: string, e: React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      
      if (window.confirm('¿Eliminar esta hoja permanentemente?')) {
          const updated = sheets.filter(s => s.id !== id);
          saveSheets(updated);
          // If we are deleting the currently active sheet, go back to list
          if (activeSheetId === id) {
             setActiveSheetId(null); 
             setViewMode('LIST');
          }
      }
  };

  const openSheet = (id: string) => {
      const sheet = sheets.find(s => s.id === id);
      if (sheet) {
          setActiveSheetId(id);
          setSheetNameEditing(sheet.name);
          setViewMode('GRID');
          setSelectedCell(null);
          setEditingValue('');
      }
  };

  // --- GRID OPERATIONS ---
  const activeSheet = sheets.find(s => s.id === activeSheetId);
  const activeData = activeSheet?.data || {};

  const updateCell = (r: number, c: number, value: string) => {
      if (!activeSheetId) return;
      const newData = { ...activeData };
      if (value === '') delete newData[getCellKey(r, c)];
      else newData[getCellKey(r, c)] = value;

      const updatedSheets = sheets.map(s => 
          s.id === activeSheetId 
          ? { ...s, data: newData, lastModified: new Date().toISOString() } 
          : s
      );
      saveSheets(updatedSheets);
  };

  const updateSheetName = (name: string) => {
      if (!activeSheetId) return;
      const updatedSheets = sheets.map(s => 
          s.id === activeSheetId 
          ? { ...s, name } 
          : s
      );
      saveSheets(updatedSheets);
  };

  const loadTemplate = (templateData: Record<string, string>) => {
      if (!activeSheetId) return;
      const updatedSheets = sheets.map(s => 
        s.id === activeSheetId 
        ? { ...s, data: { ...s.data, ...templateData }, lastModified: new Date().toISOString() } 
        : s
      );
      saveSheets(updatedSheets);
      setShowTemplates(false);
  };

  const clearSheet = () => {
      if (!activeSheetId) return;
      if (window.confirm('¿Borrar todo el contenido?')) {
        const updatedSheets = sheets.map(s => 
            s.id === activeSheetId 
            ? { ...s, data: {}, lastModified: new Date().toISOString() } 
            : s
        );
        saveSheets(updatedSheets);
      }
  };

  // --- VIRTUALIZATION ---
  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
      setScrollTop(e.currentTarget.scrollTop);
  };

  const virtualRows = useMemo(() => {
      const containerHeight = containerRef.current?.clientHeight || 600;
      const startRow = Math.floor(scrollTop / ROW_HEIGHT);
      const endRow = Math.min(TOTAL_ROWS, startRow + Math.ceil(containerHeight / ROW_HEIGHT) + VISIBLE_BUFFER);
      const rows = [];
      for (let i = startRow; i < endRow; i++) rows.push(i);
      return { rows, startRow };
  }, [scrollTop, activeSheetId]);

  // --- INTERACTIONS ---
  const handleSelect = (r: number, c: number) => {
      if (selectedCell) updateCell(selectedCell.r, selectedCell.c, editingValue);
      setSelectedCell({ r, c });
      setEditingValue(activeData[getCellKey(r, c)] || '');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
      if (!selectedCell) return;
      if (e.key === 'Enter') {
          updateCell(selectedCell.r, selectedCell.c, editingValue);
          if (selectedCell.r < TOTAL_ROWS - 1) handleSelect(selectedCell.r + 1, selectedCell.c);
      }
  };

  const handleBlur = () => {
      if (selectedCell) updateCell(selectedCell.r, selectedCell.c, editingValue);
  };

  const insertFunction = (fnName: string) => {
      if (!selectedCell) return;
      const newVal = `=${fnName}()`;
      setEditingValue(newVal);
      updateCell(selectedCell.r, selectedCell.c, newVal);
  };

  useEffect(() => {
      if (selectedCell && inputRef.current) setTimeout(() => inputRef.current?.focus(), 10);
  }, [selectedCell]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="fixed inset-0 z-[100] bg-[#0a0a0a] flex flex-col"
          onClick={() => {
              if (viewMode === 'GRID' && selectedCell) {
                  updateCell(selectedCell.r, selectedCell.c, editingValue);
                  setSelectedCell(null);
              }
          }}
        >
          {viewMode === 'LIST' ? (
              // --- LIST VIEW ---
              <div className="flex flex-col h-full safe-top">
                  <div className="p-6 border-b border-white/10 flex justify-between items-center bg-[#121212]">
                      <div>
                          <h2 className="text-xl font-bold text-white flex items-center gap-2">
                              <Grid3X3 className="text-primary" /> Mis Hojas
                          </h2>
                          <p className="text-neutral-500 text-xs">Espacios de trabajo libres</p>
                      </div>
                      <button onClick={onClose} className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-neutral-400">
                          <X size={24} />
                      </button>
                  </div>

                  <div className="flex-1 overflow-y-auto p-6 content-start">
                    <LayoutGroup id="sheets">
                      <div className="grid grid-cols-2 gap-4">
                        {/* Create New Card */}
                        <motion.button 
                            layout
                            onClick={handleCreateSheet}
                            disabled={isCreating}
                            whileHover={!isCreating ? { scale: 1.02, boxShadow: "0 10px 30px -10px rgba(109, 40, 217, 0.3)" } : {}}
                            whileTap={!isCreating ? { scale: 0.98 } : {}}
                            className={`aspect-square rounded-2xl border-2 border-dashed flex flex-col items-center justify-center gap-2 transition-all group relative overflow-hidden ${isCreating ? 'border-primary/50 bg-primary/5' : 'border-white/10 hover:border-primary/50 hover:bg-white/5'}`}
                        >
                            {isCreating && (
                                <motion.div 
                                    initial={{ opacity: 0 }}
                                    animate={{ opacity: 1 }}
                                    className="absolute inset-0 bg-primary/10 flex items-center justify-center"
                                >
                                    <div className="absolute inset-0 border-4 border-primary/20 rounded-xl animate-pulse" />
                                </motion.div>
                            )}
                            
                            <div className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${isCreating ? 'bg-transparent' : 'bg-primary/10 text-primary group-hover:scale-110 group-hover:rotate-90'}`}>
                                {isCreating ? <Loader2 className="animate-spin text-primary" size={24} /> : <Plus size={24} />}
                            </div>
                            <span className={`text-sm font-bold transition-colors ${isCreating ? 'text-primary' : 'text-neutral-400 group-hover:text-white'}`}>
                                {isCreating ? 'Creando...' : 'Nueva Hoja'}
                            </span>
                        </motion.button>

                        {/* Sheet Cards */}
                        <AnimatePresence mode="popLayout">
                            {sheets.map(sheet => (
                                <motion.div
                                    key={sheet.id}
                                    layout
                                    initial={{ opacity: 0, scale: 0.8, filter: 'blur(10px)', y: 20 }}
                                    animate={{ opacity: 1, scale: 1, filter: 'blur(0px)', y: 0 }}
                                    exit={{ opacity: 0, scale: 0.5, filter: 'blur(10px)', transition: { duration: 0.2 } }}
                                    transition={{ type: "spring", bounce: 0.3, duration: 0.6 }}
                                    onClick={() => openSheet(sheet.id)}
                                    whileHover={{ y: -5, transition: { duration: 0.2 } }}
                                    whileTap={{ scale: 0.95 }}
                                    className="aspect-square rounded-2xl bg-surface border border-white/5 relative overflow-hidden group text-left p-4 flex flex-col justify-between hover:border-white/20 transition-all shadow-lg cursor-pointer"
                                >
                                    {/* Flash Effect on Entry */}
                                    <motion.div 
                                        initial={{ opacity: 0.5 }}
                                        animate={{ opacity: 0 }}
                                        transition={{ duration: 0.8, ease: "easeOut" }}
                                        className="absolute inset-0 bg-white pointer-events-none z-20"
                                    />

                                    {/* Top Bar Gradient */}
                                    <div className={`absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r ${sheet.color || 'from-neutral-700 to-neutral-500'} z-10`} />
                                    
                                    {/* Abstract background shine */}
                                    <div className={`absolute -right-8 -top-8 w-24 h-24 bg-gradient-to-br ${sheet.color} opacity-10 blur-2xl rounded-full group-hover:opacity-20 transition-opacity`} />

                                    <div className="flex justify-between items-start relative z-10">
                                        <div className="p-2 rounded-lg bg-white/5 group-hover:bg-white/10 transition-colors">
                                           <FileSpreadsheet size={20} className="text-neutral-300 group-hover:text-white transition-colors" />
                                        </div>
                                        <button 
                                            type="button"
                                            className="p-2 rounded-lg bg-black/40 hover:bg-red-500/20 text-neutral-400 hover:text-red-400 transition-colors cursor-pointer relative z-30 border border-white/5"
                                            onClick={(e) => deleteSheet(sheet.id, e)}
                                            onMouseDown={(e) => e.stopPropagation()} // Prevent parent click
                                        >
                                            <Trash2 size={16} />
                                        </button>
                                    </div>

                                    <div className="relative z-10">
                                        <h3 className="text-white font-bold text-lg leading-tight mb-1 line-clamp-2">{sheet.name}</h3>
                                        <p className="text-[10px] text-neutral-500 flex items-center gap-1">
                                            <Sparkles size={10} className="text-primary/50" />
                                            {new Date(sheet.lastModified).toLocaleDateString()}
                                        </p>
                                    </div>
                                </motion.div>
                            ))}
                        </AnimatePresence>
                      </div>
                    </LayoutGroup>
                  </div>
              </div>
          ) : (
              // --- GRID VIEW ---
              <div className="flex flex-col h-full safe-top">
                   {/* TOOLBAR */}
                   <div className="bg-[#121212] border-b border-white/10 p-2 flex flex-col gap-2 shadow-md z-[60] shrink-0" onClick={(e) => e.stopPropagation()}>
                        <div className="flex justify-between items-center px-2">
                            <div className="flex items-center gap-2 flex-1 min-w-0">
                                <button onClick={() => setViewMode('LIST')} className="p-2 -ml-2 rounded-full hover:bg-white/10 text-neutral-400 hover:text-white transition-colors shrink-0">
                                    <ArrowLeft size={20} />
                                </button>
                                <div className="flex items-center gap-2 group flex-1 min-w-0">
                                    <input 
                                        type="text"
                                        value={sheetNameEditing}
                                        onChange={(e) => {
                                            setSheetNameEditing(e.target.value);
                                            updateSheetName(e.target.value);
                                        }}
                                        className="bg-transparent text-sm font-bold text-white outline-none w-full border-b border-transparent focus:border-primary/50 transition-colors truncate"
                                    />
                                    <Edit3 size={12} className="text-neutral-600 opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
                                </div>
                            </div>

                            <div className="flex items-center gap-2 shrink-0">
                                <div className="relative">
                                    <button onClick={() => setShowTemplates(!showTemplates)} className="p-2 rounded-lg hover:bg-white/10 text-neutral-400 hover:text-white transition-colors">
                                        <LayoutTemplate size={18} />
                                    </button>
                                    <AnimatePresence>
                                        {showTemplates && (
                                            <motion.div initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} exit={{opacity:0}} className="absolute top-full right-0 mt-2 w-48 bg-[#1a1a1a] border border-white/10 rounded-xl shadow-2xl overflow-hidden z-[70]">
                                                <div className="p-2">
                                                    {TEMPLATES.map(t => (
                                                        <button key={t.id} onClick={() => loadTemplate(t.data)} className="w-full text-left px-3 py-2.5 rounded-lg hover:bg-white/10 text-neutral-300 text-xs font-medium">{t.name}</button>
                                                    ))}
                                                    <div className="h-px bg-white/5 my-1" />
                                                    <button onClick={() => { clearSheet(); setShowTemplates(false); }} className="w-full text-left px-3 py-2.5 rounded-lg hover:bg-red-500/10 text-red-400 text-xs font-medium flex items-center gap-2"><Trash2 size={14}/> Limpiar Hoja</button>
                                                </div>
                                            </motion.div>
                                        )}
                                    </AnimatePresence>
                                </div>
                            </div>
                        </div>

                        {/* Mobile Scrollable Toolbar Row */}
                        <div className="flex gap-2 items-center px-2 overflow-x-auto no-scrollbar">
                            <div className="flex gap-1 shrink-0">
                                <button onClick={() => insertFunction('SUMA')} className="px-2 py-1 bg-surface border border-white/5 rounded text-[10px] text-neutral-400 hover:text-white hover:bg-surfaceHighlight transition-colors"><Sigma size={10}/></button>
                                <button onClick={() => insertFunction('PROMEDIO')} className="px-2 py-1 bg-surface border border-white/5 rounded text-[10px] text-neutral-400 hover:text-white hover:bg-surfaceHighlight transition-colors"><Divide size={10}/></button>
                                <button onClick={() => insertFunction('MAXIMO')} className="px-2 py-1 bg-surface border border-white/5 rounded text-[10px] text-neutral-400 hover:text-white hover:bg-surfaceHighlight transition-colors"><ArrowUpFromLine size={10}/></button>
                            </div>
                            <div className="flex-1 min-w-[150px] bg-black/40 border border-white/5 rounded-lg px-2 py-1.5 flex items-center gap-2 focus-within:border-primary/50 transition-colors">
                                <FunctionSquare size={14} className="text-primary opacity-50 shrink-0"/>
                                <input 
                                    type="text"
                                    value={selectedCell ? editingValue : ''}
                                    onChange={(e) => setEditingValue(e.target.value)}
                                    onBlur={handleBlur}
                                    onKeyDown={handleKeyDown}
                                    placeholder={selectedCell ? 'Fórmula o valor...' : 'Selecciona celda'}
                                    disabled={!selectedCell}
                                    className="bg-transparent border-none outline-none text-white text-xs w-full font-mono placeholder:text-neutral-700"
                                />
                            </div>
                        </div>
                   </div>

                   {/* GRID CONTAINER */}
                   <div 
                        className="flex-1 overflow-auto bg-[#0f0f0f] relative no-scrollbar"
                        ref={containerRef}
                        onScroll={handleScroll}
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div style={{ height: TOTAL_ROWS * ROW_HEIGHT + HEADER_HEIGHT, minWidth: TOTAL_COLS * COL_WIDTH + ROW_HEADER_WIDTH }} className="relative">
                            
                            {/* Sticky Column Headers */}
                            <div className="sticky top-0 z-40 flex h-8 bg-[#1a1a1a] shadow-sm min-w-max border-b border-white/10">
                                {/* The Dead Corner - Fixed to Top Left */}
                                <div className="w-10 border-r border-white/10 bg-[#1a1a1a] shrink-0 sticky left-0 z-50 flex items-center justify-center">
                                    <div className="w-full h-full bg-[#1a1a1a]" />
                                </div> 
                                {COL_HEADERS.map((col, i) => (
                                    <div key={i} className="w-24 border-r border-white/10 flex items-center justify-center text-[10px] font-bold text-neutral-500 shrink-0 bg-[#1a1a1a]">
                                        {col}
                                    </div>
                                ))}
                            </div>

                            {virtualRows.rows.map(rIndex => (
                                <div 
                                    key={rIndex} 
                                    className="absolute left-0 right-0 flex h-8 min-w-max"
                                    style={{ top: rIndex * ROW_HEIGHT + HEADER_HEIGHT }}
                                >
                                    {/* Sticky Row Number */}
                                    <div className="w-10 bg-[#1a1a1a] border-r border-b border-white/10 flex items-center justify-center text-[10px] font-mono text-neutral-600 shrink-0 sticky left-0 z-30 select-none">
                                        {rIndex + 1}
                                    </div>

                                    {COL_HEADERS.map((_, cIndex) => {
                                        const isSelected = selectedCell?.r === rIndex && selectedCell?.c === cIndex;
                                        const cellKey = getCellKey(rIndex, cIndex);
                                        const rawValue = activeData[cellKey] || '';
                                        const displayValue = isSelected ? editingValue : evaluateCell(rawValue, activeData);
                                        const isFormula = rawValue.startsWith('=');
                                        const isNumber = !isNaN(parseFloat(displayValue)) && displayValue !== '';

                                        return (
                                            <div 
                                                key={`${rIndex}-${cIndex}`} 
                                                className={`w-24 h-8 border-r border-b border-white/5 relative shrink-0 cursor-cell ${isSelected ? 'z-20 bg-black ring-2 ring-primary ring-inset' : 'z-0'}`}
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    handleSelect(rIndex, cIndex);
                                                }}
                                            >
                                                {isSelected ? (
                                                    <input
                                                        ref={inputRef}
                                                        type="text"
                                                        className="w-full h-full bg-transparent text-white px-2 text-xs font-mono outline-none border-none p-0 m-0"
                                                        style={{ lineHeight: '32px' }}
                                                        value={editingValue}
                                                        onChange={(e) => setEditingValue(e.target.value)}
                                                        onBlur={handleBlur}
                                                        onKeyDown={handleKeyDown}
                                                        autoFocus
                                                    />
                                                ) : (
                                                    <div className={`w-full h-full flex items-center px-2 text-xs font-mono truncate whitespace-nowrap overflow-hidden ${isNumber ? 'justify-end text-emerald-400' : 'text-neutral-300'}`}>
                                                        {displayValue}
                                                        {isFormula && <div className="absolute top-0 right-0 w-1.5 h-1.5 bg-primary rounded-bl-sm opacity-50" />}
                                                    </div>
                                                )}
                                            </div>
                                        )
                                    })}
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* STATUS BAR */}
                    <div className="bg-[#121212] border-t border-white/10 px-4 py-2 text-[10px] text-neutral-600 flex justify-between safe-pb shrink-0" onClick={(e) => e.stopPropagation()}>
                        <span className="font-mono">{selectedCell ? `${getCellId(selectedCell.r, selectedCell.c)}` : 'Listo'}</span>
                        <span>{activeSheet?.name}</span>
                    </div>
              </div>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
};
