
import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Search, Calendar, Calculator, Filter, Check, TrendingUp, TrendingDown, ArrowRight } from 'lucide-react';
import { Transaction, TransactionType } from '../../types';
import { TransactionList } from '../TransactionList';

interface TransactionAnalyzerModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactions: Transaction[];
}

type DateFilter = 'ALL' | 'WEEK' | 'MONTH' | 'YEAR' | 'CUSTOM';

export const TransactionAnalyzerModal: React.FC<TransactionAnalyzerModalProps> = ({ 
  isOpen, 
  onClose, 
  transactions 
}) => {
  // State
  const [dateFilter, setDateFilter] = useState<DateFilter>('MONTH');
  const [customDateStart, setCustomDateStart] = useState('');
  const [customDateEnd, setCustomDateEnd] = useState('');
  const [selectedType, setSelectedType] = useState<'ALL' | 'INCOME' | 'EXPENSE'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);

  // Derived Data: Categories list
  const allCategories = useMemo(() => {
      const cats = new Set(transactions.map(t => t.category));
      return Array.from(cats).sort();
  }, [transactions]);

  // Filtering Logic
  const filteredData = useMemo(() => {
      const now = new Date();
      now.setHours(0,0,0,0);
      
      const startOfWeek = new Date(now);
      startOfWeek.setDate(now.getDate() - now.getDay()); // Sunday as start
      
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const startOfYear = new Date(now.getFullYear(), 0, 1);

      return transactions.filter(t => {
          const tDate = new Date(t.date + 'T00:00:00');

          // 1. Date Filter
          if (dateFilter === 'WEEK' && tDate < startOfWeek) return false;
          if (dateFilter === 'MONTH' && tDate < startOfMonth) return false;
          if (dateFilter === 'YEAR' && tDate < startOfYear) return false;
          if (dateFilter === 'CUSTOM') {
              if (customDateStart && t.date < customDateStart) return false;
              if (customDateEnd && t.date > customDateEnd) return false;
          }

          // 2. Type Filter
          if (selectedType !== 'ALL' && t.type !== selectedType) return false;

          // 3. Search (Title, Note)
          if (searchQuery) {
              const q = searchQuery.toLowerCase();
              const match = t.title.toLowerCase().includes(q) || (t.description && t.description.toLowerCase().includes(q));
              if (!match) return false;
          }

          // 4. Categories
          if (selectedCategories.length > 0 && !selectedCategories.includes(t.category)) return false;

          return true;
      });
  }, [transactions, dateFilter, customDateStart, customDateEnd, selectedType, searchQuery, selectedCategories]);

  // Totals
  const totalIncome = filteredData.filter(t => t.type === TransactionType.INCOME).reduce((acc, t) => acc + t.amount, 0);
  const totalExpense = filteredData.filter(t => t.type === TransactionType.EXPENSE).reduce((acc, t) => acc + t.amount, 0);
  const netTotal = totalIncome - totalExpense;

  // Toggle Category Selection
  const toggleCategory = (cat: string) => {
      setSelectedCategories(prev => 
          prev.includes(cat) ? prev.filter(c => c !== cat) : [...prev, cat]
      );
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed inset-0 z-[100] bg-[#0a0a0a] flex flex-col"
        >
            {/* Header */}
            <div className="flex items-center justify-between p-6 shrink-0 bg-[#0a0a0a] border-b border-white/5">
                <div className="flex items-center gap-3">
                    <div className="p-2 rounded-full bg-primary/20 text-primary">
                        <Calculator size={20} />
                    </div>
                    <div>
                        <h2 className="text-xl font-bold text-white">Calculadora</h2>
                        <p className="text-xs text-neutral-500">Suma personalizada</p>
                    </div>
                </div>
                <button onClick={onClose} className="p-2 rounded-full bg-surface text-neutral-400 hover:text-white transition-colors">
                    <X size={20} />
                </button>
            </div>

            {/* Main Content */}
            <div className="flex-1 overflow-y-auto no-scrollbar p-6">
                
                {/* Result Hero Card */}
                <div className="bg-surface/50 border border-white/5 rounded-[2rem] p-6 mb-6 text-center relative overflow-hidden">
                    <div className="relative z-10">
                        <span className="text-xs font-bold text-neutral-500 uppercase tracking-widest">Resultado Total</span>
                        <div className="flex items-center justify-center gap-2 mt-2">
                            {selectedType === 'ALL' && netTotal !== 0 && (
                                <span className="text-2xl text-neutral-500 font-medium">Neto:</span>
                            )}
                            <span className={`text-5xl font-bold tracking-tight ${
                                selectedType === 'INCOME' ? 'text-emerald-400' : 
                                selectedType === 'EXPENSE' ? 'text-rose-400' : 
                                (netTotal >= 0 ? 'text-white' : 'text-rose-400')
                            }`}>
                                {selectedType !== 'ALL' ? '$' : (netTotal >= 0 ? '+$' : '-$')}
                                {selectedType === 'INCOME' ? totalIncome.toLocaleString() : 
                                 selectedType === 'EXPENSE' ? totalExpense.toLocaleString() : 
                                 Math.abs(netTotal).toLocaleString()}
                            </span>
                        </div>
                        <p className="text-xs text-neutral-500 mt-2">
                            {filteredData.length} transacciones encontradas
                        </p>
                    </div>
                    {/* Background Blur */}
                    <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 rounded-full blur-[60px] opacity-20 ${
                         selectedType === 'INCOME' ? 'bg-emerald-500' : 
                         selectedType === 'EXPENSE' ? 'bg-rose-500' : 
                         (netTotal >= 0 ? 'bg-blue-500' : 'bg-rose-500')
                    }`} />
                </div>

                {/* Filters Section */}
                <div className="space-y-5 mb-8">
                    
                    {/* Time Filter */}
                    <div>
                        <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider mb-2 block px-1">Periodo</span>
                        <div className="bg-surface p-1 rounded-xl flex overflow-x-auto no-scrollbar border border-white/5">
                            {[
                                { id: 'WEEK', label: 'Esta Semana' },
                                { id: 'MONTH', label: 'Este Mes' },
                                { id: 'YEAR', label: 'Este Año' },
                                { id: 'ALL', label: 'Todo' },
                                { id: 'CUSTOM', label: 'Custom' }
                            ].map((opt) => (
                                <button
                                    key={opt.id}
                                    onClick={() => setDateFilter(opt.id as DateFilter)}
                                    className={`px-4 py-2 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${
                                        dateFilter === opt.id 
                                        ? 'bg-white text-black shadow-md' 
                                        : 'text-neutral-500 hover:text-white'
                                    }`}
                                >
                                    {opt.label}
                                </button>
                            ))}
                        </div>
                        {dateFilter === 'CUSTOM' && (
                            <div className="grid grid-cols-2 gap-3 mt-3 animate-in fade-in slide-in-from-top-2">
                                <div className="bg-surface rounded-xl flex items-center px-3 py-2 border border-white/5">
                                    <input type="date" value={customDateStart} onChange={e => setCustomDateStart(e.target.value)} className="bg-transparent text-white text-xs w-full outline-none date-input-invert" />
                                </div>
                                <div className="bg-surface rounded-xl flex items-center px-3 py-2 border border-white/5">
                                    <input type="date" value={customDateEnd} onChange={e => setCustomDateEnd(e.target.value)} className="bg-transparent text-white text-xs w-full outline-none date-input-invert" />
                                </div>
                            </div>
                        )}
                    </div>

                    {/* Type Filter */}
                    <div className="grid grid-cols-3 gap-2">
                        <button onClick={() => setSelectedType('ALL')} className={`py-3 rounded-xl text-xs font-bold border transition-all ${selectedType === 'ALL' ? 'bg-surfaceHighlight border-white text-white' : 'bg-surface border-white/5 text-neutral-500'}`}>Todos</button>
                        <button onClick={() => setSelectedType('INCOME')} className={`py-3 rounded-xl text-xs font-bold border transition-all ${selectedType === 'INCOME' ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400' : 'bg-surface border-white/5 text-neutral-500'}`}>Ingresos</button>
                        <button onClick={() => setSelectedType('EXPENSE')} className={`py-3 rounded-xl text-xs font-bold border transition-all ${selectedType === 'EXPENSE' ? 'bg-rose-500/20 border-rose-500 text-rose-400' : 'bg-surface border-white/5 text-neutral-500'}`}>Gastos</button>
                    </div>

                    {/* Search & Categories */}
                    <div>
                        <div className="bg-surface rounded-xl flex items-center px-4 py-3 border border-white/5 mb-3 focus-within:border-primary/50 transition-colors">
                            <Search size={16} className="text-neutral-500 mr-2" />
                            <input 
                                type="text" 
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                placeholder="Filtrar por nombre, nota..."
                                className="bg-transparent border-none outline-none text-white w-full placeholder:text-neutral-600 text-sm"
                            />
                        </div>

                        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
                            {allCategories.map(cat => {
                                const isSelected = selectedCategories.includes(cat);
                                return (
                                    <button
                                        key={cat}
                                        onClick={() => toggleCategory(cat)}
                                        className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap border transition-all flex items-center gap-1 ${
                                            isSelected
                                            ? 'bg-primary text-white border-primary'
                                            : 'bg-surface text-neutral-400 border-white/5 hover:border-white/20'
                                        }`}
                                    >
                                        {isSelected && <Check size={10} />}
                                        {cat}
                                    </button>
                                );
                            })}
                        </div>
                    </div>
                </div>
                
                {/* List of included transactions */}
                <div className="border-t border-white/5 pt-4">
                     <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-4 px-1">Detalle</h3>
                     {filteredData.length > 0 ? (
                        <TransactionList 
                            transactions={filteredData} 
                            title="" 
                            showViewAll={false} 
                        />
                     ) : (
                         <p className="text-center text-neutral-600 text-sm py-8">No hay transacciones con estos filtros.</p>
                     )}
                </div>

            </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
