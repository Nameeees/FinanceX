
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Edit2, Trash2, Calendar, FileText, ArrowUpRight, ArrowDownRight, AlertTriangle } from 'lucide-react';
import { Transaction, TransactionType } from '../../types';
import { CATEGORY_COLORS } from '../../constants';

interface TransactionDetailsModalProps {
  transaction: Transaction | null;
  onClose: () => void;
  onEdit: (transaction: Transaction) => void;
  onDelete: (id: string) => void;
}

export const TransactionDetailsModal: React.FC<TransactionDetailsModalProps> = ({ transaction, onClose, onEdit, onDelete }) => {
  const [isDeleting, setIsDeleting] = useState(false);

  // Reset deleting state when modal opens/closes or transaction changes
  useEffect(() => {
    if (transaction) {
      setIsDeleting(false);
    }
  }, [transaction]);
  
  if (!transaction) return null;

  const isIncome = transaction.type === TransactionType.INCOME;
  const categoryKey = Object.keys(CATEGORY_COLORS).find(k => k.toLowerCase() === transaction.category.toLowerCase()) || 'Default';
  const colorClass = CATEGORY_COLORS[categoryKey];
  const bgColorClass = colorClass.split(' ')[0]; 

  return (
    <AnimatePresence>
      {transaction && (
        <>
           {/* Backdrop */}
           <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-[2px] z-[60]"
          />

          {/* Modal */}
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed bottom-0 left-0 right-0 z-[70] bg-[#121212] rounded-t-[2.5rem] border-t border-white/10 overflow-hidden shadow-2xl p-6"
          >
             {/* Header */}
             <div className="flex justify-end mb-4">
                <button onClick={onClose} className="p-2 bg-white/5 rounded-full text-neutral-400 hover:text-white">
                    <X size={20} />
                </button>
             </div>

             {/* Content */}
             <div className="flex flex-col items-center mb-8">
                <div className={`w-20 h-20 rounded-3xl flex items-center justify-center mb-4 ${bgColorClass} ring-4 ring-[#121212] shadow-xl`}>
                    {isIncome ? <ArrowUpRight size={40} className="text-income" /> : <ArrowDownRight size={40} className="text-expense" />}
                </div>
                
                <h2 className="text-4xl font-bold text-white tracking-tight mb-1">
                    {isIncome ? '+' : '-'}${transaction.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </h2>
                <p className="text-neutral-400 font-medium text-lg capitalize">{transaction.title}</p>
             </div>

             {/* Details Box */}
             <div className="bg-surface rounded-2xl p-1 mb-8 border border-white/5">
                 <div className="flex items-center gap-3 p-3 border-b border-white/5">
                    <div className="p-2 bg-white/5 rounded-lg text-neutral-400">
                        <Calendar size={18} />
                    </div>
                    <div className="flex flex-col">
                        <span className="text-[10px] uppercase tracking-wider text-neutral-500 font-semibold">Fecha</span>
                        <span className="text-sm text-neutral-200">{transaction.date}</span>
                    </div>
                 </div>
                 
                 {transaction.description && (
                    <div className="flex items-center gap-3 p-3">
                        <div className="p-2 bg-white/5 rounded-lg text-neutral-400">
                            <FileText size={18} />
                        </div>
                        <div className="flex flex-col">
                            <span className="text-[10px] uppercase tracking-wider text-neutral-500 font-semibold">Nota</span>
                            <span className="text-sm text-neutral-200">{transaction.description}</span>
                        </div>
                    </div>
                 )}
             </div>

             {/* Actions */}
             <AnimatePresence mode="wait">
               {!isDeleting ? (
                 <motion.div 
                    key="actions"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="grid grid-cols-2 gap-3 mb-4"
                 >
                    <button 
                        onClick={() => {
                            onEdit(transaction);
                            onClose();
                        }}
                        className="flex items-center justify-center gap-2 py-4 rounded-xl bg-surfaceHighlight hover:bg-white/10 text-white font-semibold transition-colors border border-white/5"
                    >
                        <Edit2 size={18} />
                        Editar
                    </button>
                    <button 
                        onClick={() => setIsDeleting(true)}
                        className="flex items-center justify-center gap-2 py-4 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 font-semibold transition-colors border border-red-500/10"
                    >
                        <Trash2 size={18} />
                        Eliminar
                    </button>
                 </motion.div>
               ) : (
                 <motion.div 
                    key="confirm"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="flex flex-col gap-3 mb-4"
                 >
                    <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-3 flex items-center gap-3 mb-1">
                        <AlertTriangle size={20} className="text-red-500" />
                        <span className="text-red-200 text-sm">¿Estás seguro de eliminar esto?</span>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                        <button 
                            onClick={() => setIsDeleting(false)}
                            className="py-4 rounded-xl bg-surface hover:bg-surfaceHighlight text-neutral-300 font-semibold transition-colors"
                        >
                            Cancelar
                        </button>
                        <button 
                            onClick={() => {
                                onDelete(transaction.id);
                                onClose();
                            }}
                            className="py-4 rounded-xl bg-red-500 text-white font-bold transition-colors shadow-lg shadow-red-500/20"
                        >
                            Sí, eliminar
                        </button>
                    </div>
                 </motion.div>
               )}
             </AnimatePresence>

          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
