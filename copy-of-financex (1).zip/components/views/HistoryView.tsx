
import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Filter, X, Search, Calendar, DollarSign, SortAsc, SortDesc, Tag, Calculator } from 'lucide-react';
import { TransactionList } from '../TransactionList';
import { Transaction, TransactionType } from '../../types';
import { CalendarModal } from '../ui/CalendarModal';
import { TransactionAnalyzerModal } from '../ui/TransactionAnalyzerModal';

interface HistoryViewProps {
  transactions: Transaction[];
  onBack: () => void;
  onTransactionClick: (t: Transaction) => void;
}

type SortOption = 'DATE_DESC' | 'DATE_ASC' | 'AMOUNT_DESC' | 'AMOUNT_ASC';
type FilterType = 'ALL' | 'INCOME' | 'EXPENSE';

export const HistoryView: React.FC<HistoryViewProps> = ({
  transactions,
  onBack,
  onTransactionClick
}) => {
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [isAnalyzerOpen, setIsAnalyzerOpen] = useState(false);
  
  // --- FILTER STATES ---
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOption, setSortOption] = useState<SortOption>('DATE_DESC');
  const [filterType, setFilterType] = useState<FilterType>('ALL');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [dateRange, setDateRange] = useState({ start: '', end: '' });
  const [amountRange, setAmountRange] = useState({ min: '', max: '' });

  // --- CALENDAR MODAL STATE ---
  const [calendarTarget, setCalendarTarget] = useState<'start' | 'end' | null>(null);

  // --- DERIVED DATA ---
  // Extract unique categories from transactions for the filter list
  const availableCategories = useMemo(() => {
    const cats = new Set(transactions.map(t => t.category));
    return Array.from(cats).sort();
  }, [transactions]);

  // --- FILTERING LOGIC ---
  const filteredTransactions = useMemo(() => {
    return transactions.filter(t => {
        // 1. Text Search
        const query = searchQuery.toLowerCase();
        const matchesSearch = t.title.toLowerCase().includes(query) || 
                              (t.description && t.description.toLowerCase().includes(query));
        if (!matchesSearch) return false;

        // 2. Type Filter
        if (filterType !== 'ALL' && t.type !== filterType) return false;

        // 3. Category Filter
        if (selectedCategory && t.category !== selectedCategory) return false;

        // 4. Date Range
        if (dateRange.start && t.date < dateRange.start) return false;
        if (dateRange.end && t.date > dateRange.end) return false;

        // 5. Amount Range
        const min = amountRange.min ? parseFloat(amountRange.min) : -Infinity;
        const max = amountRange.max ? parseFloat(amountRange.max) : Infinity;
        if (t.amount < min || t.amount > max) return false;

        return true;
    }).sort((a, b) => {
        // 6. Sorting
        switch (sortOption) {
            case 'DATE_DESC': return new Date(b.date).getTime() - new Date(a.date).getTime();
            case 'DATE_ASC': return new Date(a.date).getTime() - new Date(b.date).getTime();
            case 'AMOUNT_DESC': return b.amount - a.amount;
            case 'AMOUNT_ASC': return a.amount - b.amount;
            default: return 0;
        }
    });
  }, [transactions, searchQuery, sortOption, filterType, selectedCategory, dateRange, amountRange]);

  const activeFilterCount = [
      filterType !== 'ALL',
      selectedCategory !== null,
      dateRange.start !== '',
      dateRange.end !== '',
      amountRange.min !== '',
      amountRange.max !== ''
  ].filter(Boolean).length;

  const clearFilters = () => {
      setSearchQuery('');
      setFilterType('ALL');
      setSelectedCategory(null);
      setDateRange({ start: '', end: '' });
      setAmountRange({ min: '', max: '' });
      setSortOption('DATE_DESC');
  };

  const handleDateSelect = (date: string) => {
      if (calendarTarget === 'start') {
          setDateRange(prev => ({ ...prev, start: date }));
      } else if (calendarTarget === 'end') {
          setDateRange(prev => ({ ...prev, end: date }));
      }
      setCalendarTarget(null);
  };

  return (
    <>
      <motion.div 
        key="history" 
        initial={{ opacity: 0, x: 20 }} 
        animate={{ opacity: 1, x: 0 }} 
        exit={{ opacity: 0, x: 20 }} 
        transition={{ duration: 0.2 }} 
        className="flex-1 flex flex-col pt-4 pb-24 h-full"
      >
         {/* HEADER */}
         <div className="px-6 mb-4 flex items-center justify-between">
           <div className="flex items-center gap-4">
              <button 
                  onClick={onBack} 
                  className="w-10 h-10 rounded-full bg-surface border border-white/5 flex items-center justify-center text-neutral-400 hover:text-white hover:bg-surfaceHighlight transition-colors"
              >
                  <ArrowLeft size={20} />
              </button>
              <div>
                  <h1 className="text-2xl font-bold text-white mb-0 leading-none">Historial</h1>
                  <p className="text-neutral-500 text-xs mt-1">
                      {filteredTransactions.length} movimientos
                  </p>
              </div>
           </div>
           
           <div className="flex gap-2">
               <button 
                  onClick={() => setIsAnalyzerOpen(true)}
                  className="w-10 h-10 rounded-full bg-surface border border-white/5 flex items-center justify-center text-neutral-400 hover:text-white hover:bg-surfaceHighlight transition-colors"
               >
                  <Calculator size={20} />
               </button>
               <button 
                  onClick={() => setIsFilterOpen(!isFilterOpen)}
                  className={`w-10 h-10 rounded-full border flex items-center justify-center transition-all ${
                      isFilterOpen || activeFilterCount > 0
                      ? 'bg-primary text-white border-primary shadow-[0_0_15px_rgba(109,40,217,0.4)]' 
                      : 'bg-surface text-neutral-400 border-white/5 hover:text-white'
                  }`}
               >
                  {isFilterOpen ? <X size={20} /> : <Filter size={20} />}
               </button>
           </div>
         </div>

         {/* SEARCH BAR (Always Visible) */}
         <div className="px-6 mb-4">
             <div className="bg-surface rounded-xl flex items-center px-4 py-3 border border-white/5 focus-within:border-primary/50 transition-colors">
                  <Search size={18} className="text-neutral-500 mr-3 shrink-0" />
                  <input 
                      type="text" 
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Buscar por nombre o nota..."
                      className="bg-transparent border-none outline-none text-white w-full placeholder:text-neutral-600 font-medium text-sm"
                  />
                  {searchQuery && (
                      <button onClick={() => setSearchQuery('')} className="p-1 bg-white/10 rounded-full text-neutral-400">
                          <X size={12} />
                      </button>
                  )}
             </div>
         </div>

         {/* FILTERS PANEL */}
         <AnimatePresence>
           {isFilterOpen && (
               <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden bg-[#121212] border-b border-white/5 shadow-xl z-30"
               >
                  <div className="px-6 pb-6 space-y-5">
                      
                      {/* 1. Sorting */}
                      <div>
                          <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider mb-2 block">Ordenar por</span>
                          <div className="grid grid-cols-2 gap-2">
                               <button 
                                  onClick={() => setSortOption(sortOption === 'DATE_DESC' ? 'DATE_ASC' : 'DATE_DESC')}
                                  className={`flex items-center justify-center gap-2 py-2 rounded-xl text-xs font-medium border transition-all ${sortOption.includes('DATE') ? 'bg-surfaceHighlight border-white/20 text-white' : 'bg-surface border-white/5 text-neutral-500'}`}
                               >
                                   <Calendar size={14} /> 
                                   Fecha {sortOption === 'DATE_DESC' ? '(Reciente)' : '(Antiguo)'}
                               </button>
                               <button 
                                  onClick={() => setSortOption(sortOption === 'AMOUNT_DESC' ? 'AMOUNT_ASC' : 'AMOUNT_DESC')}
                                  className={`flex items-center justify-center gap-2 py-2 rounded-xl text-xs font-medium border transition-all ${sortOption.includes('AMOUNT') ? 'bg-surfaceHighlight border-white/20 text-white' : 'bg-surface border-white/5 text-neutral-500'}`}
                               >
                                   <DollarSign size={14} /> 
                                   Monto {sortOption === 'AMOUNT_DESC' ? '(Mayor)' : '(Menor)'}
                               </button>
                          </div>
                      </div>

                      {/* 2. Type */}
                      <div>
                          <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider mb-2 block">Tipo</span>
                          <div className="flex bg-surface rounded-xl p-1 border border-white/5">
                              {(['ALL', 'INCOME', 'EXPENSE'] as const).map(type => (
                                  <button
                                      key={type}
                                      onClick={() => setFilterType(type)}
                                      className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
                                          filterType === type 
                                          ? 'bg-primary text-white shadow-md' 
                                          : 'text-neutral-500 hover:text-neutral-300'
                                      }`}
                                  >
                                      {type === 'ALL' ? 'Todos' : type === 'INCOME' ? 'Ingresos' : 'Gastos'}
                                  </button>
                              ))}
                          </div>
                      </div>

                      {/* 3. Date Range (Custom Calendar Buttons) */}
                      <div>
                          <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider mb-2 block">Rango de Fecha</span>
                          <div className="grid grid-cols-2 gap-3">
                              <button 
                                onClick={() => setCalendarTarget('start')}
                                className={`bg-surface rounded-xl flex items-center justify-between px-3 py-3 border transition-colors ${dateRange.start ? 'border-primary/50 bg-primary/10' : 'border-white/5'}`}
                              >
                                  <span className={`text-xs ${dateRange.start ? 'text-white font-medium' : 'text-neutral-600'}`}>
                                      {dateRange.start || 'Fecha Inicio'}
                                  </span>
                                  {dateRange.start ? (
                                      <div 
                                        onClick={(e) => { e.stopPropagation(); setDateRange(p => ({...p, start: ''})); }}
                                        className="p-1 rounded-full bg-white/10 text-white"
                                      >
                                          <X size={10} />
                                      </div>
                                  ) : <Calendar size={14} className="text-neutral-600"/>}
                              </button>

                              <button 
                                onClick={() => setCalendarTarget('end')}
                                className={`bg-surface rounded-xl flex items-center justify-between px-3 py-3 border transition-colors ${dateRange.end ? 'border-primary/50 bg-primary/10' : 'border-white/5'}`}
                              >
                                  <span className={`text-xs ${dateRange.end ? 'text-white font-medium' : 'text-neutral-600'}`}>
                                      {dateRange.end || 'Fecha Fin'}
                                  </span>
                                  {dateRange.end ? (
                                      <div 
                                        onClick={(e) => { e.stopPropagation(); setDateRange(p => ({...p, end: ''})); }}
                                        className="p-1 rounded-full bg-white/10 text-white"
                                      >
                                          <X size={10} />
                                      </div>
                                  ) : <Calendar size={14} className="text-neutral-600"/>}
                              </button>
                          </div>
                      </div>

                      {/* 4. Amount Range */}
                       <div>
                          <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider mb-2 block">Rango de Monto</span>
                          <div className="grid grid-cols-2 gap-3">
                              <div className="bg-surface rounded-xl flex items-center px-3 py-2 border border-white/5">
                                  <span className="text-neutral-500 mr-1 text-xs">$</span>
                                  <input 
                                      type="number" 
                                      placeholder="Min"
                                      value={amountRange.min}
                                      onChange={(e) => setAmountRange({...amountRange, min: e.target.value})}
                                      className="bg-transparent text-white text-xs w-full outline-none"
                                  />
                              </div>
                              <div className="bg-surface rounded-xl flex items-center px-3 py-2 border border-white/5">
                                  <span className="text-neutral-500 mr-1 text-xs">$</span>
                                  <input 
                                      type="number" 
                                      placeholder="Max"
                                      value={amountRange.max}
                                      onChange={(e) => setAmountRange({...amountRange, max: e.target.value})}
                                      className="bg-transparent text-white text-xs w-full outline-none"
                                  />
                              </div>
                          </div>
                      </div>

                      {/* 5. Categories */}
                      <div>
                           <div className="flex justify-between items-center mb-2">
                               <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider">Categorías</span>
                               {selectedCategory && (
                                   <button onClick={() => setSelectedCategory(null)} className="text-[10px] text-primary">Limpiar</button>
                               )}
                           </div>
                           <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
                               {availableCategories.map(cat => (
                                   <button
                                      key={cat}
                                      onClick={() => setSelectedCategory(selectedCategory === cat ? null : cat)}
                                      className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap border transition-all ${
                                          selectedCategory === cat
                                          ? 'bg-white text-black border-white'
                                          : 'bg-surface text-neutral-400 border-white/5 hover:border-white/20'
                                      }`}
                                   >
                                       {cat}
                                   </button>
                               ))}
                               {availableCategories.length === 0 && <span className="text-xs text-neutral-600 italic">No hay categorías disponibles</span>}
                           </div>
                      </div>

                      {/* ACTIONS */}
                      <div className="pt-2 flex gap-3">
                          <button 
                              onClick={clearFilters}
                              className="flex-1 py-3 rounded-xl border border-white/10 text-neutral-400 text-xs font-bold hover:bg-white/5 transition-colors"
                          >
                              Restablecer
                          </button>
                          <button 
                              onClick={() => setIsFilterOpen(false)}
                              className="flex-[2] py-3 rounded-xl bg-surfaceHighlight text-white text-xs font-bold hover:bg-white/10 transition-colors"
                          >
                              Ver {filteredTransactions.length} Resultados
                          </button>
                      </div>

                  </div>
               </motion.div>
           )}
         </AnimatePresence>

         {/* RESULTS LIST */}
         <div className="flex-1 overflow-y-auto no-scrollbar bg-[#050505] pt-4 relative">
              <div className="absolute top-0 left-0 w-full h-6 bg-gradient-to-b from-[#050505] to-transparent z-10 pointer-events-none" />
              
              {filteredTransactions.length > 0 ? (
                  <TransactionList 
                      transactions={filteredTransactions} 
                      title="" 
                      showViewAll={false} 
                      onTransactionClick={onTransactionClick} 
                  />
              ) : (
                  <div className="flex flex-col items-center justify-center h-64 text-center px-6">
                      <div className="w-16 h-16 rounded-full bg-surface border border-white/5 flex items-center justify-center mb-4">
                          <Search size={24} className="text-neutral-500" />
                      </div>
                      <h3 className="text-white font-bold mb-1">Sin resultados</h3>
                      <p className="text-neutral-500 text-sm">Intenta ajustar tus filtros de búsqueda.</p>
                      <button onClick={clearFilters} className="mt-4 text-primary text-sm font-bold">Limpiar filtros</button>
                  </div>
              )}
         </div>
      </motion.div>

      {/* Calendar Picker Modal */}
      <CalendarModal 
        isOpen={calendarTarget !== null}
        onClose={() => setCalendarTarget(null)}
        onSelect={handleDateSelect}
        title={calendarTarget === 'start' ? 'Fecha de Inicio' : 'Fecha de Fin'}
        initialDate={calendarTarget === 'start' ? dateRange.start : dateRange.end}
      />

      <TransactionAnalyzerModal 
        isOpen={isAnalyzerOpen}
        onClose={() => setIsAnalyzerOpen(false)}
        transactions={transactions}
      />
    </>
  );
};
