
import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { BalanceHeader } from '../BalanceHeader';
import { QuickActions } from '../QuickActions';
import { TransactionList } from '../TransactionList';
import { Transaction, QuickAction } from '../../types';
import { TrendingUp, Target } from 'lucide-react';

interface HomeViewProps {
  balance: number;
  income: number;
  expense: number;
  userCurrency: string;
  displayCurrency: string;
  currencies: any[];
  quickActions: QuickAction[];
  transactions: Transaction[];
  onOpenConverter: () => void;
  onExecuteQuickAction: (action: QuickAction) => void;
  onAddQuickAction: () => void;
  onEditQuickAction: (action: QuickAction) => void;
  onViewHistory: () => void;
  onTransactionClick: (t: Transaction) => void;
  cloudStatus?: 'disconnected' | 'syncing' | 'synced' | 'error';
  userName?: string;
  onOpenMenu: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  balance,
  income,
  expense,
  userCurrency,
  displayCurrency,
  currencies,
  quickActions,
  transactions,
  onOpenConverter,
  onExecuteQuickAction,
  onAddQuickAction,
  onEditQuickAction,
  onViewHistory,
  onTransactionClick,
  cloudStatus = 'disconnected',
  userName,
  onOpenMenu
}) => {
  
  // Calcular estadísticas simples para el dashboard visual
  const stats = useMemo(() => {
    const total = income + expense; // Evitar división por cero
    // Porcentaje de gasto respecto al ingreso (Max 100%)
    const burnRate = income > 0 ? Math.min((expense / income) * 100, 100) : (expense > 0 ? 100 : 0);
    const savingsRate = income > 0 ? Math.max(((income - expense) / income) * 100, 0) : 0;
    
    return { burnRate, savingsRate };
  }, [income, expense]);

  return (
    <motion.div 
      key="home" 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }} 
      transition={{ duration: 0.3 }} 
      className="flex-1 flex flex-col relative"
    >
      {/* Background Ambient Glow */}
      <div className="absolute top-0 left-0 w-full h-[500px] overflow-hidden pointer-events-none z-0">
         <div className="absolute top-[-10%] left-[-20%] w-[400px] h-[400px] bg-primary/20 rounded-full blur-[100px] animate-blob" />
         <div className="absolute top-[10%] right-[-20%] w-[350px] h-[350px] bg-blue-600/10 rounded-full blur-[100px] animate-blob animation-delay-2000" />
      </div>

      {/* Header Section */}
      <div className="relative z-10 pb-4">
        <BalanceHeader 
          totalBalance={balance} 
          income={income} 
          expense={expense} 
          baseCurrencyCode={userCurrency} 
          displayCurrencyCode={displayCurrency} 
          currencies={currencies} 
          onOpenConverter={onOpenConverter} 
          cloudStatus={cloudStatus}
          userName={userName}
          onOpenMenu={onOpenMenu}
        />

        {/* Financial Pulse Cards */}
        <div className="px-5 mb-2">
            <div className="grid grid-cols-2 gap-3">
                {/* Burn Rate Card */}
                <motion.div 
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.1 }}
                    className="bg-white/5 backdrop-blur-md border border-white/5 rounded-2xl p-3 relative overflow-hidden group"
                >
                    <div className="flex items-center gap-2 mb-2 text-neutral-400">
                        <div className="p-1.5 rounded-lg bg-orange-500/20 text-orange-400">
                            <Target size={14} />
                        </div>
                        <span className="text-[10px] font-bold uppercase tracking-wider">Uso Ingresos</span>
                    </div>
                    
                    <div className="flex items-end justify-between mb-1">
                        <span className="text-lg font-bold text-neutral-200">{stats.burnRate.toFixed(0)}%</span>
                        <span className="text-[10px] text-neutral-500 mb-1">del total</span>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full h-1.5 bg-neutral-800/50 rounded-full overflow-hidden">
                        <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${stats.burnRate}%` }}
                            transition={{ duration: 1, ease: "easeOut" }}
                            className={`h-full rounded-full ${stats.burnRate > 90 ? 'bg-red-500' : 'bg-orange-500'}`}
                        />
                    </div>
                </motion.div>

                {/* Savings Rate Card */}
                <motion.div 
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.2 }}
                    className="bg-white/5 backdrop-blur-md border border-white/5 rounded-2xl p-3 relative overflow-hidden group"
                >
                     <div className="flex items-center gap-2 mb-2 text-neutral-400">
                        <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400">
                            <TrendingUp size={14} />
                        </div>
                        <span className="text-[10px] font-bold uppercase tracking-wider">Ahorro</span>
                    </div>
                    
                    <div className="flex items-end justify-between mb-1">
                        <span className="text-lg font-bold text-neutral-200">{stats.savingsRate.toFixed(0)}%</span>
                        <span className="text-[10px] text-neutral-500 mb-1">margen</span>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full h-1.5 bg-neutral-800/50 rounded-full overflow-hidden">
                        <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${stats.savingsRate}%` }}
                            transition={{ duration: 1, ease: "easeOut" }}
                            className="h-full rounded-full bg-emerald-500"
                        />
                    </div>
                </motion.div>
            </div>
        </div>
      </div>

      {/* Main Content Sheet */}
      <motion.div 
         initial={{ y: 50, opacity: 0 }}
         animate={{ y: 0, opacity: 1 }}
         transition={{ delay: 0.3, type: "spring", stiffness: 100, damping: 20 }}
         className="flex-1 bg-surface/50 border-t border-white/5 backdrop-blur-xl rounded-t-[2.5rem] relative z-20 shadow-[0_-10px_40px_rgba(0,0,0,0.5)] flex flex-col pt-2 overflow-hidden"
      >
          {/* Handle Bar */}
          <div className="w-full flex justify-center pt-3 pb-1 opacity-20">
              <div className="w-12 h-1 bg-white rounded-full" />
          </div>

          <div className="flex-1 overflow-y-auto no-scrollbar pb-24">
              
              {/* Quick Actions in Sheet */}
              <div className="mt-1">
                 <QuickActions 
                    actions={quickActions} 
                    onExecute={onExecuteQuickAction} 
                    onAdd={onAddQuickAction} 
                    onEdit={onEditQuickAction} 
                 />
              </div>

              {/* Transactions List */}
              <div className="mt-2">
                 <TransactionList 
                    transactions={transactions} 
                    limit={10} 
                    title="Actividad Reciente"
                    showViewAll={true} 
                    onViewAllClick={onViewHistory} 
                    onTransactionClick={onTransactionClick} 
                 />
              </div>
          </div>
      </motion.div>
    </motion.div>
  );
};
