
import { useState, useEffect, useRef } from 'react';
import { UserProfile, Transaction, Debt, QuickAction, Sheet } from '../types';
import { syncDataToCloud, sanitizeKey, verifyApiKey, findExistingBackup, restoreDataFromCloud } from '../services/cloudService';

interface UseCloudIntegrationProps {
    userProfile: UserProfile;
    transactions: Transaction[];
    debts: Debt[];
    customCategories: any[];
    quickActions: QuickAction[];
    sheets: Sheet[];
    userCurrency: string;
    onUpdateProfile: (p: UserProfile) => void;
    onImportData: (data: any) => void;
    showToast: (msg: string, type?: 'success'|'error') => void;
    setHasOnboarded: (val: boolean) => void;
}

export const useCloudIntegration = ({
    userProfile,
    transactions,
    debts,
    customCategories,
    quickActions,
    sheets,
    userCurrency,
    onUpdateProfile,
    onImportData,
    showToast,
    setHasOnboarded
}: UseCloudIntegrationProps) => {
    
  const [isSyncing, setIsSyncing] = useState(false);
  const [cloudStatus, setCloudStatus] = useState<'disconnected' | 'syncing' | 'synced' | 'error'>('disconnected');
  const saveTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isFirstLoad = useRef(true);

  // Keep a ref of the full data for the actual sync function to access
  const dataRef = useRef({
      userProfile,
      transactions,
      debts,
      customCategories,
      quickActions,
      sheets,
      userCurrency
  });

  useEffect(() => {
      dataRef.current = {
          userProfile,
          transactions,
          debts,
          customCategories,
          quickActions,
          sheets,
          userCurrency
      };
  }, [userProfile, transactions, debts, customCategories, quickActions, sheets, userCurrency]);

  useEffect(() => {
    if (userProfile.cloudConfig?.apiKey) {
        setCloudStatus('synced');
    }
    const t = setTimeout(() => { isFirstLoad.current = false; }, 1500);
    return () => clearTimeout(t);
  }, []);

  // CRITICAL FIX: Infinite Loop Prevention
  // We deconstruct the dependencies to avoid triggering sync when 'lastSync' updates.
  useEffect(() => {
    if (isFirstLoad.current) return;
    if (!userProfile.cloudConfig?.apiKey) {
        setCloudStatus('disconnected');
        return;
    }

    if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    
    setCloudStatus('syncing');

    saveTimeoutRef.current = setTimeout(async () => {
       await performSilentCloudSync();
    }, 2000);

    return () => {
        if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    };
  }, [
      // Data dependencies
      transactions, 
      debts, 
      customCategories, 
      quickActions, 
      userCurrency, 
      sheets,
      // Profile dependencies (EXCLUDING lastSync to prevent loops)
      userProfile.name,
      userProfile.email,
      userProfile.avatarUrl,
      userProfile.monthlyGoal,
      userProfile.security.enabled,
      userProfile.security.method,
      userProfile.security.value,
      userProfile.cloudConfig?.apiKey,
      userProfile.cloudConfig?.binId,
      userProfile.cloudConfig?.provider
  ]);


  const performSilentCloudSync = async () => {
      const currentData = dataRef.current;
      const apiKey = sanitizeKey(currentData.userProfile.cloudConfig?.apiKey || '');
      const binId = sanitizeKey(currentData.userProfile.cloudConfig?.binId || '');
      const provider = currentData.userProfile.cloudConfig?.provider || 'GITHUB';
      
      if (!apiKey) return;

      const rawData = {
          userProfile: currentData.userProfile, 
          transactions: currentData.transactions, 
          debts: currentData.debts, 
          customCategories: currentData.customCategories, 
          quickActions: currentData.quickActions, 
          userCurrency: currentData.userCurrency,
          sheets: currentData.sheets, 
          updatedAt: new Date().toISOString()
      };

      const result = await syncDataToCloud(apiKey, binId, rawData, provider);

      if (result.success) {
          setCloudStatus('synced');
          
          // Only update profile if binId changed (first sync) to avoid unnecessary re-renders
          if (result.newBinId && result.newBinId !== binId) {
             onUpdateProfile({
                 ...currentData.userProfile,
                 cloudConfig: { 
                     ...currentData.userProfile.cloudConfig!, 
                     binId: result.newBinId, 
                     lastSync: new Date().toISOString() 
                 }
             });
          } else {
             // Just update lastSync in memory/local storage if needed
             onUpdateProfile({
                 ...currentData.userProfile,
                 cloudConfig: { 
                     ...currentData.userProfile.cloudConfig!, 
                     lastSync: new Date().toISOString() 
                 }
             });
          }
      } else {
          setCloudStatus('error');
          console.error("Auto-sync failed:", result.message);
      }
  };

  const handleCloudSetup = async (key: string, provider: 'GITHUB' | 'JSONBIN' = 'GITHUB', existingBinId?: string) => {
    const sanitizedKey = sanitizeKey(key);
    if (!sanitizedKey) return;
    if (!navigator.onLine) { showToast('Sin conexión a internet', 'error'); return; }

    setIsSyncing(true);
    // Add small delay to allow UI to update to loading state
    await new Promise(r => setTimeout(r, 100));
    
    const verification = await verifyApiKey(sanitizedKey, provider);
    
    if (verification.success) {
        let foundId = existingBinId || '';
        
        if (!foundId && provider === 'GITHUB') {
             try {
                showToast('Buscando respaldo existente...');
                const found = await findExistingBackup(sanitizedKey, provider);
                if (found) foundId = found;
            } catch(e) {}
        }

        // --- NEW LOGIC: Restore data immediately if backup found ---
        if (foundId) {
            showToast('Respaldo encontrado. Restaurando...', 'success');
            const restoreResult = await restoreDataFromCloud(sanitizedKey, foundId, provider);
            
            if (restoreResult.success && restoreResult.data) {
                // We need to inject the NEW cloud config into the RESTORED profile
                // Otherwise the restored profile might have old/empty config or a different key
                const restoredData = restoreResult.data;
                const mergedProfile = {
                    ...restoredData.userProfile,
                    cloudConfig: {
                        enabled: true,
                        provider: provider,
                        apiKey: sanitizedKey,
                        binId: foundId,
                        lastSync: new Date().toISOString()
                    }
                };
                
                // Update the data object before importing
                restoredData.userProfile = mergedProfile;
                
                // Import everything
                onImportData(restoredData);
                
                setCloudStatus('synced');
                setIsSyncing(false);
                showToast('Datos restaurados correctamente', 'success');
                return; // Exit early, onImportData handles the state update
            }
        }

        // Fallback: If no backup found, just setup the config for a new backup
        const updatedProfile = {
            ...userProfile,
            cloudConfig: {
                enabled: true,
                provider: provider,
                apiKey: sanitizedKey,
                binId: foundId // Empty or new
            }
        };
        onUpdateProfile(updatedProfile);
        setCloudStatus('synced');
        showToast(`Conectado a ${provider === 'GITHUB' ? 'GitHub' : 'JSONBin'} (Nuevo Respaldo)`, 'success');
    } else {
        showToast(verification.message || 'Error de conexión', 'error');
    }
    setIsSyncing(false);
  };

  const handleLoginWithToken = async (token: string): Promise<boolean> => {
      // Logic managed in App.tsx typically
      return true;
  };

  const handleManualSync = async () => {
      if (!navigator.onLine) { showToast('No tienes conexión a internet', 'error'); return; }
      setIsSyncing(true);
      setCloudStatus('syncing');
      await performSilentCloudSync();
      setIsSyncing(false);
      showToast('Respaldo guardado', 'success');
  };

  const handleManualRestore = async () => {
      // Logic handled in App.tsx
  };

  return {
      isSyncing,
      cloudStatus,
      setCloudStatus,
      handleCloudSetup,
      handleLoginWithToken,
      handleManualSync,
      handleManualRestore
  };
};
