
import { useState, useEffect } from 'react';
import { CustomTracker, TrackerLog, TrackerType, ResetFrequency, WidgetLayout, Blueprint } from '../types';

export const useCustomTrackers = () => {
  const [trackers, setTrackers] = useState<CustomTracker[]>([]);

  // Load and Check Auto-Reset Logic
  useEffect(() => {
    const savedTrackers = localStorage.getItem('nexo_trackers');
    if (savedTrackers) {
      try {
        let parsed: CustomTracker[] = JSON.parse(savedTrackers);
        
        // Auto Reset Logic
        const now = new Date();
        const todayStr = now.toISOString().split('T')[0];
        
        const updated = parsed.map(t => {
            // STREAK & NO_SPEND Logic: Check for breaks
            if (t.type === 'STREAK') {
                const lastDateStr = t.lastUpdated.split('T')[0];
                const diffTime = Math.abs(now.getTime() - new Date(lastDateStr).getTime());
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
                
                if (diffDays > 1 && lastDateStr !== todayStr) {
                    return { ...t, currentValue: 0, lastUpdated: now.toISOString() };
                }
                return t;
            }

            if (t.resetSchedule === 'NEVER') return t;

            const lastDate = new Date(t.lastUpdated);
            const lastDateStr = t.lastUpdated.split('T')[0];
            let shouldReset = false;

            if (t.resetSchedule === 'DAILY') {
                shouldReset = lastDateStr !== todayStr;
            } else if (t.resetSchedule === 'WEEKLY') {
                // Reset if it's a new week (Monday) and last update was previous week
                const diffTime = Math.abs(now.getTime() - lastDate.getTime());
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                shouldReset = diffDays >= 7 || (now.getDay() === 1 && lastDate.getDay() !== 1);
            } else if (t.resetSchedule === 'MONTHLY') {
                shouldReset = now.getMonth() !== lastDate.getMonth();
            }

            if (shouldReset) {
                // For DECREMENT/DAILY_BUDGET, reset to TARGET/BUDGET. For others, reset to 0.
                const resetValue = (t.type === 'DECREMENT' || t.type === 'DAILY_BUDGET') ? (t.target || t.config?.monthlyBudget || 0) : 0;
                return { ...t, currentValue: resetValue, lastUpdated: now.toISOString() };
            }
            return t;
        });

        setTrackers(updated);
        // Save the reset state back immediately
        localStorage.setItem('nexo_trackers', JSON.stringify(updated));

      } catch (e) {
        console.error("Failed to load trackers", e);
      }
    }
  }, []);

  const saveToLocal = (data: CustomTracker[]) => {
    setTrackers(data);
    localStorage.setItem('nexo_trackers', JSON.stringify(data));
  };

  const addTracker = (
      name: string, 
      type: TrackerType, 
      config: any, 
      icon: string, 
      color: string, 
      target: number,
      unit: string = '',
      resetSchedule: ResetFrequency = 'NEVER',
      layout: WidgetLayout = 'SQUARE',
      blueprint?: Blueprint // V5: Added Blueprint Support
  ) => {
    const newTracker: CustomTracker = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      type,
      config,
      icon,
      color,
      target,
      unit,
      resetSchedule,
      layout,
      blueprint, // Save blueprint
      // DECREMENT starts at target, others start at 0
      currentValue: (type === 'DECREMENT' || type === 'DAILY_BUDGET') ? (target || config?.monthlyBudget || 0) : 0, 
      lastUpdated: new Date().toISOString(),
      logs: []
    };
    saveToLocal([...trackers, newTracker]);
  };

  const updateTracker = (id: string, updates: Partial<CustomTracker>) => {
    const updated = trackers.map(t => t.id === id ? { ...t, ...updates } : t);
    saveToLocal(updated);
  };

  const deleteTracker = (id: string) => {
    saveToLocal(trackers.filter(t => t.id !== id));
  };

  const addLog = (trackerId: string, value: number, note?: string) => {
    const updated = trackers.map(t => {
      if (t.id === trackerId) {
        const newLog: TrackerLog = {
          id: Math.random().toString(36).substr(2, 9),
          date: new Date().toISOString(),
          value,
          note
        };
        
        let newValue = t.currentValue;

        switch (t.type) {
            case 'COUNTER':
            case 'MANUAL':
            case 'TIMER':
            case 'MULTIPLIER':
            case 'HOUR_BANK':
            case 'POMODORO':
            case 'LIQUID':
            case 'PROGRESS':
            case 'IMPULSE_SAVED':
            case 'ASSET_VALUE':
            case 'SUBSCRIPTION':
            case 'DEBT_SNOWBALL':
            case 'CREDIT_GAUGE':
            case 'ROI_CALC':
            case 'SAVINGS_BINGO':
            case 'BLUEPRINT': // Handle blueprint logic if simple additive
                newValue = t.currentValue + value; 
                // For Manual/Asset/ROI, user might want to SET value, but here we add. 
                // Actually for ASSET/ROI usually you set current value.
                if (t.type === 'ASSET_VALUE' || t.type === 'ROI_CALC') newValue = value; // Direct set
                break;
            
            case 'TAX_RESERVE':
                // Value coming in is Income amount. We calc tax and add to reserve.
                const taxAmount = value * ((t.config?.taxRate || 0) / 100);
                newValue = t.currentValue + taxAmount;
                // We log the tax amount, not the income
                newLog.value = taxAmount; 
                newLog.note = `De ingreso: $${value}`;
                break;

            case 'NET_SCORE':
                newValue = t.currentValue + value;
                break;

            case 'DECREMENT':
            case 'DAILY_BUDGET':
                newValue = t.currentValue - value;
                break;

            case 'RANGE':
            case 'CHECKLIST':
            case 'BILL':
            case 'EMOJI':
            case 'RATING':
            case 'BINARY':
                newValue = value; // Set absolute value
                break;

            case 'STREAK':
                newValue = t.currentValue + 1;
                break;
            
            case 'NO_SPEND':
                // Value 1 = Success (No Spend), -1 = Fail (Spend)
                // We just track total successful days in currentValue
                if (value > 0) newValue = t.currentValue + 1;
                break;

            case 'COUNTDOWN_DATE':
                break;
        }

        return {
          ...t,
          currentValue: newValue,
          lastUpdated: new Date().toISOString(),
          logs: [newLog, ...t.logs]
        };
      }
      return t;
    });
    saveToLocal(updated);
  };
  
  const resetTrackerValue = (trackerId: string) => {
      const updated = trackers.map(t => {
          if (t.id === trackerId) {
              const resetVal = (t.type === 'DECREMENT' || t.type === 'DAILY_BUDGET') ? (t.target || t.config?.monthlyBudget || 0) : 0;
              return { ...t, currentValue: resetVal, lastUpdated: new Date().toISOString() };
          }
          return t;
      });
      saveToLocal(updated);
  };

  return {
    trackers,
    setTrackers,
    addTracker,
    updateTracker,
    deleteTracker,
    addLog,
    resetTrackerValue
  };
};
