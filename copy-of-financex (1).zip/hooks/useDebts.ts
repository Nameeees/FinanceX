

import { useState, useEffect } from 'react';
import { Debt, DebtType, DebtPayment } from '../types';
import { MOCK_DEBTS } from '../constants';

export const useDebts = () => {
  const [debts, setDebts] = useState<Debt[]>(MOCK_DEBTS);

  useEffect(() => {
    const savedDebts = localStorage.getItem('nexo_debts');
    if (savedDebts) { 
        try { 
            // Migration for old debts that don't have payments array
            const parsed = JSON.parse(savedDebts);
            const migrated = parsed.map((d: any) => ({
                ...d,
                payments: d.payments || []
            }));
            setDebts(migrated); 
        } catch (e) {} 
    }
  }, []);

  useEffect(() => { localStorage.setItem('nexo_debts', JSON.stringify(debts)); }, [debts]);

  const handleSaveDebt = (
      amount: number, 
      type: DebtType, 
      person: string, 
      dueDate: string, 
      description: string,
      initialTransactionId?: string
  ) => {
      const newDebt: Debt = { 
          id: Math.random().toString(36).substr(2, 9), 
          person, 
          amount, 
          paidAmount: 0, 
          type, 
          dueDate, 
          description,
          initialTransactionId,
          payments: []
      };
      setDebts(prev => [newDebt, ...prev]);
  };

  const handleDeleteDebt = (id: string) => { 
      setDebts(prev => prev.filter(d => d.id !== id)); 
  };

  const handlePayDebt = (amount: number, selectedDebtId: string, transactionId?: string) => {
      const newPayment: DebtPayment = {
          id: Math.random().toString(36).substr(2, 9),
          amount,
          date: new Date().toISOString(),
          transactionId
      };

      setDebts(prev => prev.map(d => {
          if (d.id === selectedDebtId) {
              return {
                  ...d,
                  paidAmount: d.paidAmount + amount,
                  payments: [...(d.payments || []), newPayment]
              };
          }
          return d;
      }));
  };

  const handleDeletePayment = (debtId: string, paymentId: string) => {
      setDebts(prev => prev.map(d => {
          if (d.id === debtId) {
              const paymentToRemove = d.payments.find(p => p.id === paymentId);
              if (!paymentToRemove) return d;

              return {
                  ...d,
                  paidAmount: d.paidAmount - paymentToRemove.amount,
                  payments: d.payments.filter(p => p.id !== paymentId)
              };
          }
          return d;
      }));
  };

  return {
      debts,
      setDebts,
      handleSaveDebt,
      handleDeleteDebt,
      handlePayDebt,
      handleDeletePayment
  };
};