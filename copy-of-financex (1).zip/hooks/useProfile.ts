import { useState, useEffect } from 'react';
import { UserProfile } from '../types';
import { MOCK_USER, SUPPORTED_CURRENCIES } from '../constants';

export const useProfile = () => {
  const [userProfile, setUserProfile] = useState<UserProfile>(MOCK_USER);
  const [hasOnboarded, setHasOnboarded] = useState(true);
  const [userCurrency, setUserCurrency] = useState('USD');
  const [displayCurrency, setDisplayCurrency] = useState('USD');
  const [currencyList, setCurrencyList] = useState(SUPPORTED_CURRENCIES);
  const [isAppLocked, setIsAppLocked] = useState(false);

  useEffect(() => {
    const savedCurrency = localStorage.getItem('nexo_currency');
    const savedProfile = localStorage.getItem('nexo_user_profile');

    let loadedProfile = MOCK_USER;

    if (savedProfile) {
        try {
            loadedProfile = JSON.parse(savedProfile);
            if (!loadedProfile.security) loadedProfile.security = { enabled: false, method: 'PIN', value: '' };
            setUserProfile(loadedProfile);
        } catch (e) { console.error("Failed to load profile", e); }
    }

    if (loadedProfile.security?.enabled) setIsAppLocked(true);

    if (!savedCurrency) {
      setHasOnboarded(false);
    } else {
      setUserCurrency(savedCurrency);
      setDisplayCurrency(savedCurrency);
      setHasOnboarded(true);
    }

    const fetchRates = async () => {
      try {
        if (!navigator.onLine) return;
        const response = await fetch('https://api.exchangerate-api.com/v4/latest/USD');
        const data = await response.json();
        if (data && data.rates) {
          setCurrencyList(prevList => prevList.map(currency => {
             const newRate = data.rates[currency.code];
             return newRate ? { ...currency, rate: newRate } : currency;
          }));
        }
      } catch (error) {}
    };
    fetchRates();
  }, []);

  const handleOnboardingComplete = (currencyCode: string, timezone: string) => {
    localStorage.setItem('nexo_currency', currencyCode);
    setUserCurrency(currencyCode);
    setDisplayCurrency(currencyCode);
    
    const updatedProfile = { ...userProfile, timezone };
    setUserProfile(updatedProfile);
    localStorage.setItem('nexo_user_profile', JSON.stringify(updatedProfile));
    
    setHasOnboarded(true);
  };

  const handleUpdateProfile = (updatedProfile: UserProfile) => {
    setUserProfile(updatedProfile);
    localStorage.setItem('nexo_user_profile', JSON.stringify(updatedProfile));
  };

  const handleLogout = () => {
    localStorage.removeItem('nexo_currency');
    const cleanProfile = { ...userProfile, cloudConfig: { apiKey: '', binId: '' } };
    setUserProfile(cleanProfile);
    localStorage.setItem('nexo_user_profile', JSON.stringify(cleanProfile));
    
    setHasOnboarded(false);
    setIsAppLocked(false);
  };

  return {
    userProfile,
    setUserProfile,
    userCurrency,
    setUserCurrency,
    displayCurrency,
    setDisplayCurrency,
    currencyList,
    hasOnboarded,
    setHasOnboarded,
    isAppLocked,
    setIsAppLocked,
    handleOnboardingComplete,
    handleUpdateProfile,
    handleLogout
  };
};