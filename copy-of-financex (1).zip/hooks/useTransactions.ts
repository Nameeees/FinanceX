

import { useState, useEffect } from 'react';
import { Transaction, TransactionType, QuickAction } from '../types';
import { MOCK_TRANSACTIONS, MOCK_QUICK_ACTIONS } from '../constants';

export const useTransactions = () => {
  const [transactions, setTransactions] = useState<Transaction[]>(MOCK_TRANSACTIONS);
  const [quickActions, setQuickActions] = useState<QuickAction[]>(MOCK_QUICK_ACTIONS);
  const [customCategories, setCustomCategories] = useState<{id: string, name: string, icon: string, type: TransactionType}[]>([]);

  useEffect(() => {
    const savedQuickActions = localStorage.getItem('nexo_quick_actions');
    const savedTransactions = localStorage.getItem('nexo_transactions');
    const savedCategories = localStorage.getItem('nexo_categories');

    if (savedQuickActions) { try { setQuickActions(JSON.parse(savedQuickActions)); } catch (e) {} }
    if (savedTransactions) { try { setTransactions(JSON.parse(savedTransactions)); } catch (e) {} }
    if (savedCategories) { try { setCustomCategories(JSON.parse(savedCategories)); } catch (e) {} }
  }, []);

  useEffect(() => { localStorage.setItem('nexo_transactions', JSON.stringify(transactions)); }, [transactions]);
  useEffect(() => { localStorage.setItem('nexo_categories', JSON.stringify(customCategories)); }, [customCategories]);

  const handleSaveTransaction = (amount: number, type: TransactionType, categoryId: string, categoryName: string, description: string, idOrNewId?: string) => {
    // Construct local date YYYY-MM-DD manually to avoid UTC offset issues
    const d = new Date();
    const localDate = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

    setTransactions(prev => {
        // Determine if we are updating an existing transaction
        const existingIndex = idOrNewId ? prev.findIndex(t => t.id === idOrNewId) : -1;
        const isUpdate = existingIndex !== -1;

        if (isUpdate) {
            // EDIT: ID exists in the list, so we update it
            const updated = [...prev];
            updated[existingIndex] = {
                ...updated[existingIndex],
                amount,
                type,
                category: categoryId,
                title: categoryName,
                description
            };
            return updated;
        } else {
            // CREATE: ID is null OR ID is provided (by Debt system) but doesn't exist yet in the list
            const newTransaction: Transaction = { 
                id: idOrNewId || Math.random().toString(36).substr(2, 9), 
                title: categoryName, 
                amount: amount, 
                type: type, 
                category: categoryId, 
                date: localDate, 
                icon: 'star', 
                description: description 
            };
            return [newTransaction, ...prev];
        }
    });
  };

  const handleDeleteTransaction = (id: string) => { 
      setTransactions(prev => prev.filter(t => t.id !== id)); 
  };

  const handleCreateCategory = (name: string, icon: string, type: TransactionType) => {
    const newCat = { id: name.toLowerCase().replace(/\s+/g, '-'), name, icon, type };
    setCustomCategories(prev => [...prev, newCat]);
  };

  const handleSaveQuickAction = (actionData: Omit<QuickAction, 'id'>, id?: string) => {
    let updated: QuickAction[];
    if (id) updated = quickActions.map(qa => qa.id === id ? { ...actionData, id } : qa);
    else updated = [...quickActions, { ...actionData, id: Math.random().toString(36).substr(2, 9) }];
    setQuickActions(updated);
    localStorage.setItem('nexo_quick_actions', JSON.stringify(updated));
  };

  const handleDeleteQuickAction = (id: string) => {
    const updated = quickActions.filter(a => a.id !== id);
    setQuickActions(updated);
    localStorage.setItem('nexo_quick_actions', JSON.stringify(updated));
  };

  return {
      transactions,
      setTransactions,
      quickActions,
      setQuickActions,
      customCategories,
      setCustomCategories,
      handleSaveTransaction,
      handleDeleteTransaction,
      handleCreateCategory,
      handleSaveQuickAction,
      handleDeleteQuickAction
  };
};
