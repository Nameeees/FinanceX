
import LZString from 'lz-string';
import { UserProfile, Transaction, Debt, TransactionType, QuickAction, Sheet, CloudProvider } from '../types';

interface BackupData {
    userProfile: UserProfile;
    transactions: Transaction[];
    debts: Debt[];
    customCategories: {id: string, name: string, icon: string, type: TransactionType}[];
    quickActions: QuickAction[];
    userCurrency: string;
    updatedAt: string;
    sheets?: Sheet[];
}

export const sanitizeKey = (key: string) => {
    if (!key) return '';
    return key.replace(/[\s\n\r"']/g, '').trim();
};

const GITHUB_API_URL = 'https://api.github.com';
const JSONBIN_API_URL = 'https://api.jsonbin.io/v3';
const BACKUP_FILENAME = 'nexo_finance_backup.txt'; 
const LEGACY_BACKUP_FILENAME = 'nexo_backup.json'; 

// Helper to retry fetch on network failure
const fetchWithRetry = async (url: string, options: RequestInit, retries = 3, backoff = 1000): Promise<Response> => {
    const safeOptions = {
        ...options,
        cache: 'no-store' as RequestCache,
        referrerPolicy: 'no-referrer' as ReferrerPolicy
    };

    for (let i = 0; i < retries; i++) {
        try {
            const res = await fetch(url, safeOptions);
            // Don't retry on 4xx errors (client errors), except maybe 429 (rate limit)
            if (!res.ok && res.status >= 400 && res.status < 500 && res.status !== 429) {
                return res; 
            }
            return res;
        } catch (err: any) {
            if (i === retries - 1) throw err;
            await new Promise(r => setTimeout(r, backoff * (i + 1))); 
        }
    }
    throw new Error('Fetch failed after retries');
};

export const verifyApiKey = async (token: string, provider: CloudProvider = 'GITHUB'): Promise<{ success: boolean; status?: number; message?: string }> => {
    try {
        if (provider === 'GITHUB') {
            const response = await fetchWithRetry(`${GITHUB_API_URL}/user`, {
                method: 'GET',
                headers: {
                    'Authorization': `token ${token}`,
                    'Accept': 'application/vnd.github.v3+json'
                }
            });

            if (response.ok) {
                const data = await response.json();
                const scopes = response.headers.get('x-oauth-scopes');
                if (scopes && !scopes.includes('gist')) {
                    return { success: false, status: 403, message: 'El token necesita permiso de "gist"' };
                }
                return { success: true, status: 200, message: `Conectado como ${data.login}` };
            }
            return { success: false, status: response.status, message: 'Token de GitHub inválido' };
        } else {
            // JSONBin Verification FIX: Use GET /b (list bins) instead of POST to verify key without creating junk data
            const response = await fetchWithRetry(`${JSONBIN_API_URL}/b`, {
                method: 'GET', 
                headers: {
                    'X-Master-Key': token
                }
            });

            if (response.ok) {
                return { success: true, status: 200, message: 'Conectado a JSONBin' };
            }
            return { success: false, status: response.status, message: 'Key de JSONBin inválida o sin permisos' };
        }
    } catch (error: any) {
        console.error("Verification failed", error);
        return { success: false, message: error.name === 'TypeError' ? 'Error de conexión' : error.message };
    }
};

export const findExistingBackup = async (token: string, provider: CloudProvider = 'GITHUB'): Promise<string | null> => {
    if (provider === 'GITHUB') {
        let page = 1;
        let foundId = null;
        const PER_PAGE = 30; 
        const MAX_PAGES = 10; // Reduced to prevent excessive API calls

        while (page <= MAX_PAGES && !foundId) {
            const response = await fetchWithRetry(`${GITHUB_API_URL}/gists?per_page=${PER_PAGE}&page=${page}&t=${Date.now()}`, {
                method: 'GET',
                headers: {
                    'Authorization': `token ${token}`,
                    'Accept': 'application/vnd.github.v3+json'
                }
            });

            if (!response.ok) return null;

            const gists = await response.json();
            if (gists.length === 0) break; 

            const backupGist = gists.find((gist: any) => 
                gist.files && (gist.files[BACKUP_FILENAME] || gist.files[LEGACY_BACKUP_FILENAME])
            );

            if (backupGist) foundId = backupGist.id;
            else page++;
        }
        return foundId;
    } else {
        // JSONBin does not support searching easily by file content or metadata in standard plan
        return null; 
    }
};

export const syncDataToCloud = async (
    token: string, 
    binId: string, 
    data: BackupData,
    provider: CloudProvider = 'GITHUB'
): Promise<{ success: boolean; newBinId?: string; message?: string; isAuthError?: boolean }> => {
    
    const jsonString = JSON.stringify(data);
    const compressedData = LZString.compressToUTF16(jsonString);

    try {
        if (provider === 'GITHUB') {
            const payload = {
                description: "Nexo Finance Backup (Encrypted & Compressed)",
                public: false, 
                files: { [BACKUP_FILENAME]: { content: compressedData } }
            };

            const headers = {
                'Authorization': `token ${token}`,
                'Accept': 'application/vnd.github.v3+json',
                'Content-Type': 'application/json'
            };

            let url = `${GITHUB_API_URL}/gists`;
            let method = 'POST';

            // If we have a binId, try to update it.
            if (binId && binId.length > 5) {
               url = `${GITHUB_API_URL}/gists/${binId}`;
               method = 'PATCH';
            }

            let response = await fetchWithRetry(url, { method, headers, body: JSON.stringify(payload) });

            // If PATCH fails with 404 (Gist deleted remotely), fallback to POST (Create new)
            if (!response.ok && method === 'PATCH' && response.status === 404) {
               url = `${GITHUB_API_URL}/gists`;
               method = 'POST';
               response = await fetchWithRetry(url, { method, headers, body: JSON.stringify(payload) });
            }

            const result = await response.json();

            if (response.ok) return { success: true, newBinId: result.id };
            else return { success: false, message: result.message, isAuthError: response.status === 401 || response.status === 403 };

        } else {
            // JSONBin Implementation
            const headers = {
                'Content-Type': 'application/json',
                'X-Master-Key': token,
                'X-Bin-Private': 'true'
            };

            let url = `${JSONBIN_API_URL}/b`;
            let method = 'POST';

            if (binId && binId.length > 10) {
                url = `${JSONBIN_API_URL}/b/${binId}`;
                method = 'PUT';
            }

            // JSONBin stores JSON directly. We wrap the compressed string in a JSON object.
            const payload = { content: compressedData, _meta: "Nexo Backup", timestamp: Date.now() };

            const response = await fetchWithRetry(url, { method, headers, body: JSON.stringify(payload) });
            const result = await response.json();

            if (response.ok) return { success: true, newBinId: result.metadata?.id };
            else return { success: false, message: result.message, isAuthError: response.status === 401 };
        }

    } catch (error: any) {
        console.error("Cloud Sync Error", error);
        return { success: false, message: error.name === 'TypeError' ? 'Error de conexión.' : 'Error inesperado.' };
    }
};

export const restoreDataFromCloud = async (
    token: string, 
    binId: string,
    provider: CloudProvider = 'GITHUB'
): Promise<{ success: boolean; data?: any; message?: string }> => {
    
    try {
        let fileContent = '';

        if (provider === 'GITHUB') {
            const response = await fetchWithRetry(`${GITHUB_API_URL}/gists/${binId}?t=${Date.now()}`, {
                method: 'GET',
                headers: { 'Authorization': `token ${token}`, 'Accept': 'application/vnd.github.v3+json' }
            });

            const result = await response.json();
            
            if (response.ok && result.files) {
                const fileObj = result.files[BACKUP_FILENAME] || result.files[LEGACY_BACKUP_FILENAME];
                if (!fileObj || !fileObj.content) return { success: false, message: "Respaldo vacío." };
                fileContent = fileObj.content;
            } else {
                return { success: false, message: 'Gist no encontrado.' };
            }
        } else {
            // JSONBin Restore
            const response = await fetchWithRetry(`${JSONBIN_API_URL}/b/${binId}/latest`, {
                method: 'GET',
                headers: { 'X-Master-Key': token }
            });
            
            const result = await response.json();
            if (response.ok && result.record) {
                fileContent = result.record.content;
            } else {
                return { success: false, message: 'Bin no encontrado.' };
            }
        }

        try {
            // Attempt decompression
            const decompressedString = LZString.decompressFromUTF16(fileContent);
            if (decompressedString) {
                return { success: true, data: JSON.parse(decompressedString) };
            } else {
                // Fallback to raw JSON for legacy backups or uncompressed data
                return { success: true, data: JSON.parse(fileContent) };
            }
        } catch (e) {
             console.error("Decompression failed, trying raw parse", e);
             try {
                 return { success: true, data: JSON.parse(fileContent) };
             } catch (e2) {
                 return { success: false, message: "Error al leer datos del respaldo." };
             }
        }
            
    } catch (error: any) {
         console.error("Cloud Restore Error", error);
         return { success: false, message: 'Error de conexión.' };
    }
};
